#!/usr/bin/env python3
"""Shot-level NumPy simulation of rac_ibm_experiment.py (identical settings, gate sequence and output format).

Noise model per round t (all optional):
  depolarizing strength p_dep (applied after preparation), coherent over-rotation of the preparation angle
  theta -> theta (1 + eps(t)) with slow drift eps(t) = eps0 * sin(2 pi t / T), asymmetric readout flips
  e01 = P(read 1 | 0), e10 = P(read 0 | 1), and error bursts: with rate r_burst a burst of length L_burst
  starts during which p_dep is raised to p_burst (temporally clustered errors).
Writes <out>/settings.csv, <out>/rounds.csv and <out>/meta.json in the same format as the hardware script.
"""
import argparse, json, os, sys, hashlib
import numpy as np
import pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rac_ibm_experiment import draw_settings  # noqa: E402


def ry(t):
    return np.array([[np.cos(t / 2), -np.sin(t / 2)], [np.sin(t / 2), np.cos(t / 2)]], complex)


def rz(p):
    return np.diag([np.exp(-1j * p / 2), np.exp(1j * p / 2)])


def p0_after(theta_p, phi_p, theta_m, phi_m, p_dep):
    psi = rz(phi_p) @ ry(theta_p) @ np.array([1, 0], complex)
    rho = np.outer(psi, psi.conj())
    rho = (1 - p_dep) * rho + p_dep * np.eye(2) / 2
    U = ry(-theta_m) @ rz(-phi_m)
    rho = U @ rho @ U.conj().T
    return float(np.real(rho[0, 0]))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=3)
    ap.add_argument("--rounds", type=int, default=20000)
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--noise-seed", type=int, default=7)
    ap.add_argument("--p-dep", type=float, default=0.01)
    ap.add_argument("--eps0", type=float, default=0.0)
    ap.add_argument("--drift-period", type=float, default=5000)
    ap.add_argument("--e01", type=float, default=0.01)
    ap.add_argument("--e10", type=float, default=0.02)
    ap.add_argument("--r-burst", type=float, default=0.0)
    ap.add_argument("--L-burst", type=int, default=50)
    ap.add_argument("--p-burst", type=float, default=0.6)
    ap.add_argument("--calib-shots", type=int, default=4096)
    ap.add_argument("--out", type=str, required=True)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    df = draw_settings(a.n, a.rounds, a.seed)
    df.to_csv(os.path.join(a.out, "settings.csv"), index=False)
    digest = hashlib.sha256(open(os.path.join(a.out, "settings.csv"), "rb").read()).hexdigest()
    rng = np.random.default_rng(a.noise_seed)
    burst_left = 0
    out = np.zeros(len(df), np.uint8)
    for t, r in enumerate(df.itertuples(index=False)):
        if burst_left == 0 and rng.random() < a.r_burst:
            burst_left = a.L_burst
        p = a.p_burst if burst_left > 0 else a.p_dep
        burst_left = max(0, burst_left - 1)
        eps = a.eps0 * np.sin(2 * np.pi * t / a.drift_period)
        p0 = p0_after(r.theta_p * (1 + eps), r.phi_p, r.theta_m, r.phi_m, p)
        b = 0 if rng.random() < p0 else 1
        if b == 0 and rng.random() < a.e01:
            b = 1
        elif b == 1 and rng.random() < a.e10:
            b = 0
        out[t] = b
    df["outcome"] = out
    df["win"] = (df["outcome"] == df["target"]).astype(int)
    df.to_csv(os.path.join(a.out, "rounds.csv"), index=False)
    n1_0 = rng.binomial(a.calib_shots, a.e01); n0_1 = rng.binomial(a.calib_shots, a.e10)
    meta = dict(n=a.n, rounds=a.rounds, seed=a.seed, settings_sha256=digest, backend="numpy-simulation",
                noise=vars(a), calibration_counts={"prep0": {"0": a.calib_shots - n1_0, "1": n1_0},
                                                   "prep1": {"0": n0_1, "1": a.calib_shots - n0_1}},
                mean_win=float(df["win"].mean()))
    json.dump(meta, open(os.path.join(a.out, "meta.json"), "w"), indent=2)
    print(f"simulated {len(df)} rounds, mean win {df['win'].mean():.4f} -> {a.out}")


if __name__ == "__main__":
    main()
