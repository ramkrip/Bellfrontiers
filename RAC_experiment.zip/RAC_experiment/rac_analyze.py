#!/usr/bin/env python3
"""Certificates for a randomized, shot-ordered RAC run (hardware or simulation).

Inputs: <run>/rounds.csv (from rac_ibm_experiment.py or rac_simulate.py), <run>/meta.json, rac_theory.json.
Reports (all one-sided, level alpha):
  * S_hat and its exact Clopper-Pearson LCB (valid if rounds are i.i.d.: settings drawn i.i.d. uniform and a
    stationary device);
  * the Azuma-Hoeffding LCB of Theorem 5(i) (valid with memory and adaptively chosen dependence, provided
    inputs are fresh and revealed sequentially -- an assumption, not enforced on a single processor);
  * eta_req certificate = LCB - 3/4 (exact for RACs: input-transitive, Corollary 1), converted into Hall's M
    and the minimal mutual information using the exact tables in rac_theory.json;
  * block (product) certificates from consecutive rounds via Theorem 5(ii) + Azuma on block indicators;
  * diagnostics: setting uniformity, per-question win rates, win rate in time windows, lag-1 autocorrelation,
    and a readout-mitigated plug-in score (sensitivity only).
"""
import argparse, json, os
import numpy as np
import pandas as pd
from scipy.stats import beta, chisquare


def cp_lcb(k, n, a):
    return 0.0 if k == 0 else float(beta.ppf(a, k, n - k + 1))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run")
    ap.add_argument("--theory", required=True)
    ap.add_argument("--alpha", type=float, default=0.05)
    ap.add_argument("--windows", type=int, default=20)
    a = ap.parse_args()
    df = pd.read_csv(os.path.join(a.run, "rounds.csv"))
    meta = json.load(open(os.path.join(a.run, "meta.json")))
    n = int(meta["n"]); th = json.load(open(a.theory))[f"rac{n}1"]
    S0 = th["omega_c"]; Sq = th["quantum"]
    W = df["win"].to_numpy(); N = len(W); K = int(W.sum()); S = K / N
    res = dict(run=a.run, n=n, rounds=N, S_hat=S, S0=S0, S_quantum_ideal=Sq)
    # settings uniformity
    xs = df[[f"x{i}" for i in range(n)]].astype(str).agg("".join, axis=1) + "|" + df["y"].astype(str)
    res["settings_uniformity_p"] = float(chisquare(xs.value_counts().to_numpy()).pvalue)
    res["win_by_question"] = {int(y): float(g["win"].mean()) for y, g in df.groupby("y")}
    # certificates
    L_cp = cp_lcb(K, N, a.alpha)
    L_az = S - np.sqrt(np.log(1 / a.alpha) / (2 * N))
    res["LCB_clopper_pearson"] = L_cp
    res["LCB_azuma_sequential"] = L_az
    res["eta_cert_iid"] = max(0.0, L_cp - S0)
    res["eta_cert_sequential"] = max(0.0, L_az - S0)
    # Exact unrestricted-RAC conversions. Linear interpolation of a convex
    # information curve can overstate the information lower bound.
    def information_cost(score):
        if score <= S0:
            return 0.0
        if score >= 1.0:
            return float(-np.log2(S0))
        return float(score * np.log2(score / S0) + (1 - score) * np.log2((1 - score) / (1 - S0)))
    for tag, Lv in (("iid", L_cp), ("sequential", L_az)):
        res[f"hall_M_cert_{tag}"] = float((8.0 / 3.0) * max(0.0, Lv - S0))
        res[f"I_bits_cert_{tag}"] = information_cost(Lv)
    # block certificates (consecutive rounds), Theorem 5(ii); Azuma on block indicators
    res["blocks"] = {}
    for b in (2, 3, 5):
        nb = N // b
        Q = W[: nb * b].reshape(nb, b).all(1).astype(float)
        Qh = Q.mean()
        L_iid = cp_lcb(int(Q.sum()), nb, a.alpha)
        L_seq = Qh - np.sqrt(np.log(1 / a.alpha) / (2 * nb))
        res["blocks"][b] = dict(blocks=nb, Q_hat=float(Qh), Q_hat_root=float(Qh ** (1 / b)),
                                iid_independent_prediction=float(S ** b),
                                eta_cert_iid=max(0.0, L_iid ** (1 / b) - S0) if L_iid > 0 else 0.0,
                                eta_cert_sequential=max(0.0, max(L_seq, 0) ** (1 / b) - S0))
    # temporal diagnostics
    edges = np.linspace(0, N, a.windows + 1).astype(int)
    res["window_win_rates"] = [float(W[edges[i]:edges[i + 1]].mean()) for i in range(a.windows)]
    w0 = W - W.mean()
    res["lag1_autocorrelation"] = float((w0[1:] * w0[:-1]).mean() / w0.var()) if w0.var() > 0 else 0.0
    res["lag1_autocorr_null_sd"] = float(1 / np.sqrt(N))
    # readout-mitigated plug-in (sensitivity only)
    cal = meta.get("calibration_counts")
    if cal:
        c0, c1 = cal["prep0"], cal["prep1"]
        e01 = c0.get("1", 0) / max(1, sum(c0.values())); e10 = c1.get("0", 0) / max(1, sum(c1.values()))
        A = np.array([[1 - e01, e10], [e01, 1 - e10]])
        Ainv = np.linalg.inv(A)
        mit = []
        for (y, tgt), gdf in df.groupby(["y", "target"]):
            p = np.array([(gdf.outcome == 0).mean(), (gdf.outcome == 1).mean()])
            pm = np.clip(Ainv @ p, 0, None); pm /= pm.sum()
            mit.append((len(gdf), pm[tgt]))
        res["readout_e01_e10"] = [e01, e10]
        res["S_mitigated_plugin"] = float(sum(nn * v for nn, v in mit) / sum(nn for nn, _ in mit))
    json.dump(res, open(os.path.join(a.run, "analysis.json"), "w"), indent=2)
    print(json.dumps({k: v for k, v in res.items() if k not in ("window_win_rates",)}, indent=2))


if __name__ == "__main__":
    main()
