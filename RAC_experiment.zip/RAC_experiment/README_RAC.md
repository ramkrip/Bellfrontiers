# Proposed qubit random-access-code protocol and offline simulations

The `2→1` and `3→1` tasks have classical value `S0=3/4` for a one-bit
channel with shared randomness. Their fixed qubit preparation/measurement
rules have ideal values `0.8535533906` and `0.7886751346`, respectively.
The channel-capacity restriction is part of the declared model.

This package contains fresh **software simulations** and a proposed IBM
submission script. The IBM script was not submitted, fetched, or tested
against a live service in the v6 audit. The simulations do not constitute a
hardware experiment or evidence of a registered experimental protocol.

## Reproduce offline

The full driver performs the LP calculations and all four scenarios:

```bash
python analysis_scripts/reproduce.py
```

After the theory output exists, rerun only the simulations with:

```bash
python analysis_scripts/reproduce.py --stages rac
```

The commands above are run from the package root; the driver can also be
called by absolute path from another working directory. See
`analysis_scripts/README.md` for dependencies and the complete numerical
reproduction protocol.

One explicit stationary scenario can be generated separately:

```bash
python RAC_experiment/rac_simulate.py --n 3 --rounds 20000 --seed 2026 --noise-seed 7 --p-dep 0.01 --e01 0.01 --e10 0.025 --out verification/reproduced/rac/rac31_noisy
python RAC_experiment/rac_analyze.py verification/reproduced/rac/rac31_noisy --theory verification/reproduced/rac_theory.json
```

Every scenario writes `settings.csv`, `rounds.csv`, `meta.json`, and
`analysis.json`. The metadata contain all noise parameters and the SHA-256
of the ordered settings file. Outcomes retain their round indices.

## Fully specified v6 simulations

All scenarios use settings seed **2026**, noise seed **7**, and 4,096
readout-calibration shots. The noiseless case sets depolarization and both
readout errors to zero. The stationary-noise case uses depolarization
`p_dep=0.01`, `e01=0.01`, and `e10=0.025`.

The drift/burst case uses that same stationary background, sinusoidal
preparation-angle modulation `eps0=0.10` with period 5,000 rounds, burst
start probability `r_burst=0.002` per eligible round, burst length 50, and
depolarization strength 0.6 during a burst. These parameters were specified
without tuning to recreate earlier displayed results.

| Scenario | Code | Rounds | Mean win | 95% sequential certificate |
|---|---|---:|---:|---:|
| Noiseless | 3→1 | 40,000 | 0.79010 | 0.033981 |
| Stationary noise | 3→1 | 20,000 | 0.77660 | 0.017946 |
| Same background, drift and bursts | 3→1 | 20,000 | 0.75605 | 0 |
| Stationary noise | 2→1 | 20,000 | 0.83645 | 0.077796 |

The drift/burst run has lag-1 win autocorrelation `0.0157774`. The
approximate iid reference scale `1/sqrt(20000)` is `0.0070711`. This is a
descriptive diagnostic, not a significance guarantee under arbitrary
serial dependence. The prior v5 figures `0.757`, `0.837`, and lag-1
correlation `0.029` cannot be identified with these fully specified runs:
the v5 shot files and complete drift/burst arguments were not supplied.

## Analysis and interpretation

The unrestricted shared-resource threat allows dependence on the complete
instance `(x,y)`. Its frontier is `min(1,3/4+eta)`. The question-only and
sender-only threats have different slopes, as documented in the manuscript
and `rac_threat_models.py`; they must not be interchanged.

`rac_analyze.py` reports the raw score, an iid Clopper–Pearson lower bound,
the sequential Hoeffding–Azuma lower bound, block diagnostics, per-question
and time-window scores, lag-1 autocorrelation, and a readout-mitigated
plug-in score. The latter is a sensitivity estimate. The exact unrestricted
conversions are evaluated analytically:

- `M=(8/3) max(0,L-3/4)`;
- `I=D_binary(L || 3/4)` bits for `L>3/4`, and zero otherwise.

These replace linear interpolation of a convex information curve, which
could slightly overstate an information lower bound.

The sequential certificate is conditional on fresh, sequentially revealed
inputs and the declared classical model. A compiled whole-setting list
allows the processor to know future settings, so the proposed single-chip
implementation does not enforce that assumption against an adversarial
device. Neither randomization nor shot ordering independently establishes
channel capacity or input independence.

## Proposed hardware script

`rac_ibm_experiment.py` draws and hashes settings before submission and
contains the proposed SamplerV2 workflow, calibration circuits, and later
result-fetching code. Its offline settings-only path can be inspected with:

```bash
python RAC_experiment/rac_ibm_experiment.py --n 3 --rounds 20000 --seed 2026 --out rac_settings_preview --dry-run
```

The full numerical driver never invokes this file as a program. The
simulator imports only its local settings-generator function. Qiskit and
IBM credentials are unnecessary for the offline reproduction. The live
API, backend selection, transpilation, BitArray layout, job ordering, and
physical execution timing remain unvalidated by this package's audit.
