#!/usr/bin/env python3
"""Randomized, shot-ordered n->1 qubit random access code (RAC) on an IBM Quantum backend.

Protocol (one round = one shot):
  * inputs x in {0,1}^n (sender) and y in {0..n-1} (receiver) are drawn i.i.d. uniformly from a seeded RNG,
    written to disk *before* submission (with a SHA-256 digest that can be quoted in the paper);
  * the sender prepares the qubit state with Bloch vector r(x) = ((-1)^{x_1}, (-1)^{x_2}, (-1)^{x_0}) / sqrt(n)
    restricted to the first n axes (n=2: xz-plane; n=3: all three axes);
  * the receiver rotates measurement axis a(y) to z and measures; outcome b is the guess for x_y.
Ideal success: 1/2 (1 + 1/sqrt(n)) = 0.8536 (n=2), 0.7887 (n=3). Classical one-bit value: 3/4 for both.

One parametric circuit, one parameter binding and ONE SHOT per round; the bindings are submitted in the
pre-drawn order and results are returned in that order, so every round keeps its index.

Usage
  python rac_ibm_experiment.py --n 3 --rounds 20000 --backend ibm_kingston --seed 2026 --out run_rac31
  python rac_ibm_experiment.py --n 3 --rounds 20000 --backend ibm_kingston --seed 2026 --out run_rac31 --dry-run
  python rac_ibm_experiment.py --fetch <JOB_ID> --out run_rac31        # retrieve results later

Requires: qiskit >= 1.2, qiskit-ibm-runtime >= 0.30 (SamplerV2), numpy, pandas.
Credentials: QiskitRuntimeService() must find a saved account (do not hard-code tokens).

Note on interpretation (state this in the paper): the whole setting list is compiled into the job, so the
device has, in principle, access to all settings in advance. Randomization and shot ordering make the
analysis robust to drift and to non-adversarial temporal correlations of the noise; they do NOT enforce
input independence or sequential revelation against an adversarial device. Execution order of bindings
within a PUB is the submission order as returned by the Sampler; physical execution timing is not exposed.
"""
import argparse, hashlib, json, os, sys, time
import numpy as np
import pandas as pd

AXES = {0: (0.0, 0.0), 1: (np.pi / 2, 0.0), 2: (np.pi / 2, np.pi / 2)}  # y -> (theta_m, phi_m): z, x, y axes


def bloch_vector(x, n):
    s = [(-1) ** int(b) for b in x]
    if n == 2:   # (sx, sy, sz) = (x1, 0, x0)/sqrt2  -> y=0 reads z, y=1 reads x
        v = np.array([s[1], 0.0, s[0]]) / np.sqrt(2)
    elif n == 3:  # (sx, sy, sz) = (x1, x2, x0)/sqrt3 -> y=0 reads z, y=1 reads x, y=2 reads y
        v = np.array([s[1], s[2], s[0]]) / np.sqrt(3)
    else:
        raise ValueError("n must be 2 or 3")
    return v


def prep_angles(v):
    theta = float(np.arccos(np.clip(v[2], -1, 1)))
    phi = float(np.arctan2(v[1], v[0]))
    return theta, phi


def draw_settings(n, rounds, seed):
    rng = np.random.default_rng(seed)
    X = rng.integers(0, 2, size=(rounds, n))
    Y = rng.integers(0, n, size=rounds)
    rows = []
    for t in range(rounds):
        th, ph = prep_angles(bloch_vector(X[t], n))
        tm, pm = AXES[int(Y[t])]
        rows.append(dict(round=t, **{f"x{i}": int(X[t, i]) for i in range(n)}, y=int(Y[t]),
                         target=int(X[t, Y[t]]), theta_p=th, phi_p=ph, theta_m=tm, phi_m=pm))
    return pd.DataFrame(rows)


def build_circuit():  # requires qiskit
    from qiskit import QuantumCircuit
    from qiskit.circuit import Parameter
    tp, pp, tm, pm = Parameter("theta_p"), Parameter("phi_p"), Parameter("theta_m"), Parameter("phi_m")
    qc = QuantumCircuit(1, 1, name="rac_round")
    qc.ry(tp, 0)          # Bloch vector (sin tp, 0, cos tp)
    qc.rz(pp, 0)          # rotate azimuth -> (sin tp cos pp, sin tp sin pp, cos tp)
    qc.barrier()          # marks the sender/receiver boundary (prevents merging prep and measurement rotations)
    qc.rz(-pm, 0)         # receiver: rotate measurement axis a(y) to z
    qc.ry(-tm, 0)
    qc.measure(0, 0)
    return qc


def calibration_circuits():
    from qiskit import QuantumCircuit
    c0 = QuantumCircuit(1, 1, name="cal0"); c0.measure(0, 0)
    c1 = QuantumCircuit(1, 1, name="cal1"); c1.x(0); c1.measure(0, 0)
    return [c0, c1]


def bits_from_bitarray(ba):
    """BitArray with one classical bit -> uint8 array over the PUB shape (shots=1)."""
    arr = np.asarray(ba.array)            # shape (*pub_shape, num_shots, num_bytes)
    return (arr[..., 0, -1] & 1).astype(np.uint8)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=3)
    ap.add_argument("--rounds", type=int, default=20000)
    ap.add_argument("--backend", type=str, default=None)
    ap.add_argument("--qubit", type=int, default=None, help="physical qubit (optional initial layout)")
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--chunk", type=int, default=5000, help="bindings per PUB")
    ap.add_argument("--calib-shots", type=int, default=4096)
    ap.add_argument("--out", type=str, required=True)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--fetch", type=str, default=None, help="job id to retrieve")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    settings_path = os.path.join(a.out, "settings.csv")

    if a.fetch is None:
        df = draw_settings(a.n, a.rounds, a.seed)
        df.to_csv(settings_path, index=False)
        digest = hashlib.sha256(open(settings_path, "rb").read()).hexdigest()
        meta = dict(n=a.n, rounds=a.rounds, seed=a.seed, settings_sha256=digest, created=time.strftime("%Y-%m-%dT%H:%M:%S%z"))
        print(f"settings written: {settings_path}\nSHA-256: {digest}")
        if a.dry_run:
            try:
                print(build_circuit().draw(output="text"))
            except ImportError:
                print("(qiskit not installed: circuit = RY(theta_p) RZ(phi_p) | barrier | RZ(-phi_m) RY(-theta_m) MEASURE)")
            print(df.head(8).to_string(index=False))
            json.dump(meta, open(os.path.join(a.out, "meta.json"), "w"), indent=2)
            return
        qc = build_circuit()
        from qiskit.transpiler.preset_passmanagers import generate_preset_pass_manager
        from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2 as Sampler
        service = QiskitRuntimeService()
        backend = service.backend(a.backend) if a.backend else service.least_busy(operational=True, simulator=False)
        pm = generate_preset_pass_manager(optimization_level=1, backend=backend,
                                          initial_layout=[a.qubit] if a.qubit is not None else None)
        isa = pm.run(qc)
        cals = [pm.run(c) for c in calibration_circuits()]
        # parameter values in the transpiled circuit's parameter order
        names = [p.name for p in isa.parameters]
        vals = df[names].to_numpy(dtype=float)
        pubs = [(isa, vals[i:i + a.chunk], 1) for i in range(0, len(vals), a.chunk)]
        pubs += [(cals[0], None, a.calib_shots), (cals[1], None, a.calib_shots)]
        sampler = Sampler(mode=backend)
        job = sampler.run(pubs)
        layout = isa.layout.final_index_layout() if isa.layout is not None else None
        meta.update(backend=backend.name, job_id=job.job_id(), physical_qubits=layout,
                    n_data_pubs=len(pubs) - 2, chunk=a.chunk, parameter_order=names)
        json.dump(meta, open(os.path.join(a.out, "meta.json"), "w"), indent=2)
        print("submitted job", job.job_id())
    else:
        from qiskit_ibm_runtime import QiskitRuntimeService
        service = QiskitRuntimeService()
        job = service.job(a.fetch)
        meta = json.load(open(os.path.join(a.out, "meta.json")))
        df = pd.read_csv(settings_path)

    result = job.result()
    nd = meta["n_data_pubs"]
    bits = np.concatenate([bits_from_bitarray(result[k].data.c) for k in range(nd)])
    assert len(bits) == len(df), (len(bits), len(df))
    df["outcome"] = bits
    df["win"] = (df["outcome"] == df["target"]).astype(int)
    df.to_csv(os.path.join(a.out, "rounds.csv"), index=False)
    cal = {}
    for k, prep in ((nd, 0), (nd + 1, 1)):
        counts = result[k].data.c.get_counts()
        cal[f"prep{prep}"] = {str(key): int(v) for key, v in counts.items()}
    meta["calibration_counts"] = cal
    meta["mean_win"] = float(df["win"].mean())
    json.dump(meta, open(os.path.join(a.out, "meta.json"), "w"), indent=2)
    print(f"rounds: {len(df)}  mean win: {df['win'].mean():.4f}  -> {os.path.join(a.out, 'rounds.csv')}")


if __name__ == "__main__":
    main()
