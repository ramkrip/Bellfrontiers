"""Construction-knowledge premium of a hand-picked quantum encoding over a pre-registered, data-only selection.

Data: Havlicek-style ad hoc labels generated with the ZZ map (reps=2, alpha=2) and a Haar-random generator V.
Quantum learner: exact fidelity-kernel SVM (classically simulable here; the point is the accounting, not an advantage).
  * oracle: uses the generating map (construction knowledge, i.e. benchmark-dependent design);
  * pre-registered: picks the map from a declared family by training-only cross-validation (design depends on
    the public data only, so it carries no benchmark dependence by construction).
Classical generic baseline: Gaussian-kernel SVM with training-only CV over the bandwidth.
Output: mean scores and the paired premium (oracle - pre-registered) with 95% bootstrap intervals,
for several training-set sizes and two declared families.
"""
import sys, json, itertools
import numpy as np
from sklearn.svm import SVC
from sklearn.model_selection import StratifiedKFold, GridSearchCV
from scipy.linalg import qr

H = np.array([[1, 1], [1, -1]]) / np.sqrt(2)
bits = np.array([[(k >> 0) & 1, (k >> 1) & 1] for k in range(4)])


def a1(psi, U, q):
    psi = psi.reshape(2, 2); psi = psi @ U.T if q == 0 else U @ psi; return psi.reshape(4)


def state(x, reps, alpha):
    psi = np.zeros(4, complex); psi[0] = 1
    for _ in range(reps):
        psi = a1(psi, H, 0); psi = a1(psi, H, 1)
        for i in range(2):
            psi = psi * np.exp(1j * alpha * x[i] * bits[:, i])
        psi = psi * np.exp(1j * alpha * (np.pi - x[0]) * (np.pi - x[1]) * (bits[:, 0] ^ bits[:, 1]))
    return psi


def haar(rng):
    z = (rng.normal(size=(4, 4)) + 1j * rng.normal(size=(4, 4))) / np.sqrt(2); q, r = qr(z); d = np.diag(r); return q * (d / abs(d))


FAM6 = [(1, 2.0), (2, 2.0), (3, 2.0), (4, 2.0), (2, 1.0), (2, 3.0)]
FAM12 = [(r, a) for r in (1, 2, 3, 4) for a in (1.0, 2.0, 3.0)]
TRUE = (2, 2.0)
G = np.linspace(0, 2 * np.pi, 45, endpoint=False); XG = np.array(np.meshgrid(G, G, indexing='ij')).reshape(2, -1).T
S = {f: np.array([state(x, *f) for x in XG]) for f in set(FAM6 + FAM12)}
K = {f: np.abs(S[f].conj() @ S[f].T) ** 2 for f in S}
D2 = ((XG[:, None, :] - XG[None, :, :]) ** 2).sum(-1)
ZP = np.diag([1., -1, -1, 1])


def fit(Ktr, ytr, Kte, seed):
    k = int(min(3, np.bincount(ytr).min()))
    cv = StratifiedKFold(k, shuffle=True, random_state=seed)
    g = GridSearchCV(SVC(kernel='precomputed'), {'C': [0.1, 1, 10, 100]}, cv=cv, scoring='balanced_accuracy').fit(Ktr, ytr)
    return g.predict(Kte), g.best_score_


def run(ntr, family, NT):
    rec = {'oracle': [], 'prereg': [], 'rbf': [], 'correct_pick': []}
    for t in range(NT):
        rng = np.random.default_rng(50000 + t); V = haar(rng); O = V.conj().T @ ZP @ V
        g = np.real(np.einsum('ni,ij,nj->n', S[TRUE].conj(), O, S[TRUE]))
        pos, neg = np.where(g > 0.25)[0], np.where(g < -0.25)[0]
        if len(pos) < ntr + 20 or len(neg) < ntr + 20:
            continue
        ip, ineg = rng.choice(pos, ntr + 20, replace=False), rng.choice(neg, ntr + 20, replace=False)
        tr = np.r_[ip[:ntr], ineg[:ntr]]; te = np.r_[ip[ntr:], ineg[ntr:]]
        ytr = np.r_[np.ones(ntr, int), np.zeros(ntr, int)]; yte = np.r_[np.ones(20, int), np.zeros(20, int)]
        p, _ = fit(K[TRUE][np.ix_(tr, tr)], ytr, K[TRUE][np.ix_(te, tr)], t)
        rec['oracle'].append(np.mean(p == yte))
        best = (-1, None, None)
        for f in family:
            p, cvs = fit(K[f][np.ix_(tr, tr)], ytr, K[f][np.ix_(te, tr)], t)
            if cvs > best[0] + 1e-12:
                best = (cvs, f, np.mean(p == yte))
        rec['prereg'].append(best[2]); rec['correct_pick'].append(float(best[1] == TRUE))
        bestr = (-1, None)
        for gam in (0.1, 0.3, 1, 3, 10):
            Kr_tr = np.exp(-gam * D2[np.ix_(tr, tr)])
            Kr_te = np.exp(-gam * D2[np.ix_(te, tr)])
            p, cvs = fit(Kr_tr, ytr, Kr_te, t)
            if cvs > bestr[0]:
                bestr = (cvs, np.mean(p == yte))
        rec['rbf'].append(bestr[1])
    o, pr = np.array(rec['oracle']), np.array(rec['prereg'])
    d = o - pr
    rng = np.random.default_rng(1)
    boots = [rng.choice(d, len(d)).mean() for _ in range(4000)]
    return dict(train_per_class=ntr, family_size=len(family), tasks=len(d),
                oracle=float(o.mean()), prereg=float(pr.mean()), rbf=float(np.mean(rec['rbf'])),
                correct_pick=float(np.mean(rec['correct_pick'])),
                premium=float(d.mean()), premium_ci95=[float(np.quantile(boots, 0.025)), float(np.quantile(boots, 0.975))])


if __name__ == '__main__':
    from analysis_paths import output_parser, prepare_output
    parser = output_parser(__doc__, "premium_fixed.json")
    parser.add_argument("--tasks", type=int, default=200)
    parser.add_argument("--families", default="6,12")
    args = parser.parse_args()
    OUT = prepare_output(args.out)
    NT = args.tasks
    out = []
    fams = {"6": FAM6, "12": FAM12}
    for fam in [fams[k] for k in args.families.split(",")]:
        for ntr in (3, 5, 8, 15, 30):
            r = run(ntr, fam, NT); out.append(r); print(r, flush=True)
    json.dump(out, open(OUT, 'w'), indent=1)
