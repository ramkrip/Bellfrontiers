Historical manuscript-rewrite utilities, preserved only for provenance
====================================================================

fill_v3.py.disabled and fill_resource_sm.py.disabled are obsolete authoring
utilities from an earlier workstation. They contain hard-coded paths and
replace manuscript prose using old formulas and old numerical results.
They are not analysis programs and must not be used to reproduce v6.

They have deliberately been renamed so that Python script discovery does not
execute them. The v6 offline reproduction driver never calls them. Current
tables are generated as separate output artifacts for review; no analysis
program rewrites main.tex or supplement.tex.
