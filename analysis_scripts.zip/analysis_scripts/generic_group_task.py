"""HISTORICAL MIDPOINT SIMULATION: not the certified v6 learner.
The optional BSGS part counts only group operations and treats equality comparisons as free;
it is not a verification of the manuscript theorem under total-query accounting.

Worked learning construction: interval concepts on the exponents of a prime-order cyclic group.

Instance: s, a_1..a_m, a ~ U(Z_N); labels y_i = f_s(a_i), y = f_s(a), f_s(t) = 1[(t - s) mod N < K], K = (N-1)/2.
Public data: handles of g, g^{a_i} (with labels), g^a; group accessed generically.

(1) Ideal quantum learner (Shor-based): discrete logs of all points are computed exactly (verified), then
    s is estimated by the midpoint of the set of interval positions consistent with the training labels,
    and the test label is predicted. We simulate it classically by reading the exponents directly.
(2) Historical group-operation-only diagnostic plotted against B = 1/2 + [1 + (k)(k-1)]/(2N), k = q + m + 2:
    a classical generic learner handed the concept s and the training logs (allowed: independent of a)
    runs baby-step giant-step with q equality-producing group operations on the test handle.
"""
import json, sys, math
import numpy as np

def consistent_arc(N, K, a_tr, y_tr):
    """Return (lo, length) of the arc of s values consistent with labels (s in [lo, lo+length) mod N)."""
    pos = a_tr[y_tr == 1]; neg = a_tr[y_tr == 0]
    # s consistent iff all positives in [s, s+K) and all negatives in [s+K, s+N).
    # Equivalently s in intersection over positives p of (p-K, p] and over negatives n of (n, n+N-K] ... do by scanning candidates
    # Work on the circle: s must lie in (n_prev, p_first] and s+K-1 >= p_last etc. Use brute-force on sorted points.
    pts = np.sort(np.concatenate([pos, neg]))
    lab = {int(p): 1 for p in pos}; lab.update({int(n): 0 for n in neg})
    return pts, lab

def predict_quantum(N, K, a_tr, y_tr, a_te, rng):
    pos = np.sort(a_tr[y_tr == 1]); neg = np.sort(a_tr[y_tr == 0])
    if len(pos) == 0 or len(neg) == 0:
        return int(rng.integers(2))
    # positives occupy a circular arc of length <= K; find the "first" positive: the positive whose predecessor (circularly) among all points is a negative
    allp = np.sort(np.concatenate([pos, neg])); is_pos = np.isin(allp, pos)
    n = len(allp)
    first = [i for i in range(n) if is_pos[i] and not is_pos[i - 1]]
    last = [i for i in range(n) if is_pos[i] and not is_pos[(i + 1) % n]]
    i0, i1 = first[0], last[0]
    p_first, n_before = allp[i0], allp[i0 - 1]
    p_last, n_after = allp[i1], allp[(i1 + 1) % n]
    # constraints: s in (n_before, p_first], s+K-1 in [p_last, n_after)  =>  s in [p_last-K+1, n_after-K]
    def arc(lo, hi):  # inclusive arc lo..hi mod N, as set of offsets from lo
        return lo % N, (hi - lo) % N + 1
    lo1, L1 = arc(n_before + 1, p_first)
    lo2, L2 = arc(p_last - K + 1, n_after - K)
    # intersect two arcs: take lo = lo2 offset relative to lo1
    d = (lo2 - lo1) % N
    if d < L1:
        lo, L = lo2, min(L2, L1 - d)
    else:
        d2 = (lo1 - lo2) % N
        lo, L = lo1, min(L1, L2 - d2)
    s_hat = (lo + max(L, 1) // 2) % N
    return int(((a_te - s_hat) % N) < K)

def quantum_accuracy(N, m, trials, seed):
    rng = np.random.default_rng(seed); K = (N - 1) // 2; c = 0
    for _ in range(trials):
        s = int(rng.integers(N)); a_tr = rng.integers(0, N, m); a_te = int(rng.integers(N))
        y_tr = (((a_tr - s) % N) < K).astype(int); y = int(((a_te - s) % N) < K)
        c += predict_quantum(N, K, a_tr, y_tr, a_te, rng) == y
    return c / trials

def bsgs_learner_accuracy(N, q, trials, seed):
    """Generic learner with q group operations: baby steps a+j (j<b) and giant steps -i*b (i<q-b); handed s."""
    rng = np.random.default_rng(seed); K = (N - 1) // 2; c = 0
    b = q // 2; gsteps = q - b
    for _ in range(trials):
        s = int(rng.integers(N)); a = int(rng.integers(N)); y = int(((a - s) % N) < K)
        # equality pattern reveals a iff a in {i*b - j}: covered set size <= b*gsteps
        # direct check: exists i<gsteps, j<b with a + j == i*b (mod N)  <=> a mod N in {i*b - j}
        r = a % b; i = (a + (b - r) % b) // b  # smallest i with i*b >= a
        j = i * b - a
        found = (i < gsteps) and (0 <= j < b)
        if found:
            c += 1
        else:
            c += (0 == y)  # not found: predict the more likely label 0 (P(y=1)=K/N<1/2)
    return c / trials

if __name__ == "__main__":
    from analysis_paths import output_parser, prepare_output
    args = output_parser(__doc__, "gg_midpoint_historical.json").parse_args()
    OUT = prepare_output(args.out)
    out = {}
    N = 2**61 - 1  # Mersenne prime
    out["quantum"] = []
    for m in (10, 30, 100, 300, 1000):
        acc = quantum_accuracy(N, m, 20000, 7 + m)
        out["quantum"].append(dict(N=N, m=m, trials=20000, accuracy=acc))
        print("quantum", m, acc, flush=True)
    out["bsgs"] = []
    Ns = 1000003
    for q in (200, 600, 1000, 2000):
        acc = bsgs_learner_accuracy(Ns, q, 200000, 3 + q)
        B = 0.5 + (1 + (q + 2) * (q + 1)) / (2 * Ns)
        out["bsgs"].append(dict(N=Ns, q=q, trials=200000, accuracy=acc, bound_known_logs=B))
        print("bsgs", q, acc, B, flush=True)
    json.dump(out, open(OUT, "w"), indent=1)
