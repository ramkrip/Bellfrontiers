"""Reanalysis of the ad hoc quantum-kernel benchmark.

1. Re-implements the Qiskit zz_feature_map (2 qubits, reps=2, full entanglement) in numpy and
   checks that the stored latent scores g(u) are reproduced exactly (same seed / random unitary).
2. Evaluates the *exact classical* fidelity kernel K(u,u') = |<Phi(u)|Phi(u')>|^2 with training-only
   hyper-parameter selection (as the referee did) on the released train/test split.
3. Monte Carlo over the task ensemble (random generator unitary V, same sampling protocol) to obtain a
   confidence lower bound on the learner-class optimum S_0 for this benchmark family.
4. Shot-noise-only simulation of the kernel estimate (1024 shots) to show how much of the hardware
   deficit is finite-sampling.
"""
import sys, json
import numpy as np
import pandas as pd
from scipy.linalg import qr
from sklearn.svm import SVC
from sklearn.model_selection import StratifiedKFold, GridSearchCV
from scipy.stats import beta

from pathlib import Path
from analysis_paths import DATA_DIR, output_parser, prepare_output
parser = output_parser(__doc__, "qml_reanalysis_3000.json")
parser.add_argument("--data", type=Path, default=DATA_DIR / "raw_qml" / "adhoc_hardware_selected_dataset_with_latent_variables (1).csv")
parser.add_argument("--hardware-train", type=Path, default=DATA_DIR / "raw_qml" / "adhoc_hardware_K_train (1).npy")
parser.add_argument("--hardware-test", type=Path, default=DATA_DIR / "raw_qml" / "adhoc_hardware_K_test (1).npy")
parser.add_argument("--paired-predictions", type=Path, default=DATA_DIR / "raw_qml" / "adhoc_hardware_paired_predictions (1).csv")
parser.add_argument("--tasks", type=int, default=3000)
parser.add_argument("--shot-repetitions", type=int, default=200)
args = parser.parse_args()
DATA = args.data
OUT = str(prepare_output(args.out))
C_GRID = [0.1, 1, 10, 100]

H = np.array([[1, 1], [1, -1]]) / np.sqrt(2)


def apply_1q(psi, U, q):
    psi = psi.reshape(2, 2)  # index [b1, b0]; qubit 0 = least-significant bit
    if q == 0:
        psi = psi @ U.T
    else:
        psi = U @ psi
    return psi.reshape(4)


def zz_state(x, reps=2):
    psi = np.zeros(4, complex); psi[0] = 1
    bits = np.array([[(k >> 0) & 1, (k >> 1) & 1] for k in range(4)])
    for _ in range(reps):
        psi = apply_1q(psi, H, 0); psi = apply_1q(psi, H, 1)
        for i in range(2):
            psi = psi * np.exp(1j * 2.0 * x[i] * bits[:, i])
        phi = 2.0 * (np.pi - x[0]) * (np.pi - x[1])
        psi = psi * np.exp(1j * phi * (bits[:, 0] ^ bits[:, 1]))
    return psi


def random_unitary(dim, rng):
    z = (rng.normal(size=(dim, dim)) + 1j * rng.normal(size=(dim, dim))) / np.sqrt(2)
    q, r = qr(z)
    d = np.diag(r)
    return q * (d / np.abs(d))


ZPROD = np.diag([1.0, -1.0, -1.0, 1.0])


def observable(seed):
    V = random_unitary(4, np.random.default_rng(seed))
    return V.conj().T @ ZPROD @ V


def gscore(O, x):
    s = zz_state(x)
    return float(np.real(np.vdot(s, O @ s)))


def kernel(XA, XB):
    SA = np.array([zz_state(x) for x in XA]); SB = np.array([zz_state(x) for x in XB])
    return np.abs(SA.conj() @ SB.T) ** 2


def fit_predict(Ktr, ytr, Kte, seed=0):
    nmin = int(np.min(np.bincount(ytr)))
    cv = StratifiedKFold(n_splits=max(2, min(3, nmin)), shuffle=True, random_state=seed)
    gs = GridSearchCV(SVC(kernel="precomputed"), {"C": C_GRID}, cv=cv, scoring="balanced_accuracy")
    gs.fit(Ktr, ytr)
    return gs.predict(Kte), gs.best_params_["C"]


res = {"protocol": {"released_cv_seed": 0, "generator_reconstruction_seed": 123, "ensemble_seed_base": 10000, "shot_seed": 7, "shot_repetitions": args.shot_repetitions, "ensemble_candidates": args.tasks, "C_grid": C_GRID, "train_per_class": 15, "test_per_class": 20, "margin": 0.25, "grid_size_per_axis": 45}}
df = pd.read_csv(DATA)
tr = df[df.split == "train"].reset_index(drop=True); te = df[df.split == "test"].reset_index(drop=True)
Xtr, ytr = tr[["x0", "x1"]].values, tr.y.astype(int).values
Xte, yte = te[["x0", "x1"]].values, te.y.astype(int).values

# --- 1. reproduce generator ---
O = observable(123)
g_re = np.array([gscore(O, x) for x in df[["x0", "x1"]].values])
res["max_abs_g_mismatch"] = float(np.max(np.abs(g_re - df.g.values)))

# --- 2. exact classical kernel on released split ---
Ktr, Kte = kernel(Xtr, Xtr), kernel(Xte, Xtr)
pred, Cbest = fit_predict(Ktr, ytr, Kte)
k_ok = int((pred == yte).sum())
res["exact_classical_kernel_correct"] = k_ok
res["exact_classical_kernel_n"] = int(len(yte))
res["exact_classical_kernel_C"] = Cbest
res["exact_classical_kernel_CP95_lower"] = float(beta.ppf(0.05, k_ok, len(yte) - k_ok + 1)) if k_ok < len(yte) else float(0.05 ** (1 / len(yte)))
# Hardware matrices and archived held-out predictions are required inputs in this package.
Kh_tr = np.load(args.hardware_train); Kh_te = np.load(args.hardware_test)
assert Kh_tr.shape == Ktr.shape and Kh_te.shape == Kte.shape
res["hw_vs_exact_kernel_mean_abs_dev_train"] = float(np.mean(np.abs(Kh_tr - Ktr)[~np.eye(len(Ktr), dtype=bool)]))
res["hw_vs_exact_kernel_mean_abs_dev_test"] = float(np.mean(np.abs(Kh_te - Kte)))
ph, Ch = fit_predict(Kh_tr, ytr, Kh_te)
res["hardware_kernel_refit_correct"] = int((ph == yte).sum())
res["hardware_kernel_refit_C"] = Ch
paired = pd.read_csv(args.paired_predictions)
assert np.array_equal(paired.y_true.to_numpy(), yte)
res["hardware_archived_correct"] = int((paired.y_pred_q.to_numpy() == yte).sum())
res["restricted_classical_archived_correct"] = int((paired.y_pred_cl.to_numpy() == yte).sum())
res["hardware_refit_matches_archived_predictions"] = bool(np.array_equal(ph, paired.y_pred_q.to_numpy()))
pd.DataFrame({"y_true": yte, "exact_prediction": pred, "hardware_refit_prediction": ph,
              "hardware_archived_prediction": paired.y_pred_q,
              "restricted_classical_archived_prediction": paired.y_pred_cl}).to_csv(
    OUT.replace(".json", "_predictions.csv"), index=False)

# Linear separability in the 15-dim Bloch (Pauli) feature space: g is linear in rho(u)
res["note_linear"] = "fidelity kernel = linear kernel on rho(u); labels = sign of a linear functional of rho(u)"

# --- 3. shot-noise-only kernel (1024 shots) on released split ---
rng = np.random.default_rng(7)
acc_shot = []
for rep in range(args.shot_repetitions):
    Ktr_s = rng.binomial(1024, np.clip(Ktr, 0, 1)) / 1024.0
    Ktr_s = (Ktr_s + Ktr_s.T) / 2; np.fill_diagonal(Ktr_s, 1.0)
    Kte_s = rng.binomial(1024, np.clip(Kte, 0, 1)) / 1024.0
    p_s, _ = fit_predict(Ktr_s, ytr, Kte_s, seed=rep)
    acc_shot.append(float(np.mean(p_s == yte)))
res["shot_noise_1024_mean_acc"] = float(np.mean(acc_shot))
res["shot_noise_1024_min_acc"] = float(np.min(acc_shot))

# --- 4. Monte Carlo over task ensemble ---
GRID = np.linspace(0, 2 * np.pi, 45, endpoint=False)
XG = np.array(np.meshgrid(GRID, GRID, indexing="ij")).reshape(2, -1).T
SG = np.array([zz_state(x) for x in XG])
KG = np.abs(SG.conj() @ SG.T) ** 2
NT = args.tasks
accs, used = [], 0
for t in range(NT):
    seed = 10_000 + t
    Ot = observable(seed)
    g = np.real(np.einsum("ni,ij,nj->n", SG.conj(), Ot, SG))
    pos, neg = np.where(g > 0.25)[0], np.where(g < -0.25)[0]
    if len(pos) < 35 or len(neg) < 35:
        continue
    r = np.random.default_rng(seed)
    ip, ineg = r.choice(pos, 35, replace=False), r.choice(neg, 35, replace=False)
    tr_idx = np.r_[ip[:15], ineg[:15]]; te_idx = np.r_[ip[15:], ineg[15:]]
    ytr_t = np.r_[np.ones(15, int), np.zeros(15, int)]; yte_t = np.r_[np.ones(20, int), np.zeros(20, int)]
    p_t, _ = fit_predict(KG[np.ix_(tr_idx, tr_idx)], ytr_t, KG[np.ix_(te_idx, tr_idx)], seed=t)
    accs.append(float(np.mean(p_t == yte_t))); used += 1
    if (t + 1) % 500 == 0:
        print(f"ensemble candidates processed: {t + 1}/{NT}", flush=True)
accs = np.array(accs)
np.save(OUT.replace(".json", "_mc_accs.npy"), accs)
res["mc_tasks_used"] = used
res["mc_tasks_skipped"] = NT - used
res["mc_mean_acc"] = float(accs.mean())
res["mc_frac_perfect"] = float(np.mean(accs == 1.0))
res["mc_min_acc"] = float(accs.min())
res["mc_hoeffding95_lower"] = float(accs.mean() - np.sqrt(np.log(1 / 0.05) / (2 * used)))
json.dump(res, open(OUT, "w"), indent=2)
print(json.dumps(res, indent=2))
