"""Numerical verification of the theory results used in the revision.

Games are reduced to the set of distinct win vectors of deterministic local strategies
(coarse-graining lambda to its win vector is WLOG for TV- and MI-type dependence measures,
by data processing, and leaves the score unchanged).
"""
import itertools, json, sys
import numpy as np
from scipy.optimize import linprog
from scipy import sparse

res = {}

# ------------------------------------------------------------------ games
def chsh():
    Z = [(x, y) for x in (0, 1) for y in (0, 1)]
    W = set()
    for a in itertools.product((0, 1), repeat=2):
        for b in itertools.product((0, 1), repeat=2):
            W.add(tuple(int((a[x] ^ b[y]) == (x & y)) for x, y in Z))
    return np.array(sorted(W)), Z


def mermin(n):
    Z = [x for x in itertools.product((0, 1), repeat=n) if sum(x) % 2 == 0]
    W = set()
    for A in (0, 1):
        for beta in itertools.product((0, 1), repeat=n):
            W.add(tuple(int((A + sum(b * xi for b, xi in zip(beta, x))) % 2 == (sum(x) // 2) % 2) for x in Z))
    return np.array(sorted(W)), Z


def magic_square():
    Z = [(x, y) for x in range(3) for y in range(3)]
    rows = [r for r in itertools.product((0, 1), repeat=3) if sum(r) % 2 == 0]
    cols = [c for c in itertools.product((0, 1), repeat=3) if sum(c) % 2 == 1]
    W = set()
    for A in itertools.product(rows, repeat=3):      # A[x] = Alice's row x
        for B in itertools.product(cols, repeat=3):  # B[y] = Bob's column y
            W.add(tuple(int(A[x][y] == B[y][x]) for x, y in Z))
    return np.array(sorted(W)), Z


def omega_c(W, q):
    return float(np.max(W @ q))

# ------------------------------------------------------------------ LPs
def lp_S_eta(W, q, eta, kind="bm"):
    """max score s.t. worst-case posterior TV <= eta (kind='bm', w.r.t. marginal)
    or pairwise TV <= eta (kind='pair'). Variables: P[l,z] = p(l|z), t[...] >= 0."""
    L, m = W.shape
    nP = L * m
    idx = lambda l, z: l * m + z
    rows, cols, vals, b = [], [], [], []
    r = 0
    tv_blocks = []
    if kind == "bm":
        pairs = [(z, None) for z in range(m)]
    else:
        pairs = [(z, zp) for z in range(m) for zp in range(m) if z != zp]
    nT = len(pairs) * L
    nv = nP + nT
    for k, (z, zp) in enumerate(pairs):
        for l in range(L):
            # t_{k,l} >= P[l,z] - ref_l   ->  P[l,z] - ref_l - t <= 0
            rows += [r]; cols += [idx(l, z)]; vals += [1.0]
            if zp is None:
                for zz in range(m):
                    rows += [r]; cols += [idx(l, zz)]; vals += [-q[zz]]
            else:
                rows += [r]; cols += [idx(l, zp)]; vals += [-1.0]
            rows += [r]; cols += [nP + k * L + l]; vals += [-1.0]
            b.append(0.0); r += 1
        for l in range(L):
            rows += [r]; cols += [nP + k * L + l]; vals += [1.0]
        b.append(eta); r += 1
    A_ub = sparse.csr_matrix((vals, (rows, cols)), shape=(r, nv))
    A_eq = sparse.lil_matrix((m, nv))
    for z in range(m):
        for l in range(L):
            A_eq[z, idx(l, z)] = 1.0
    c = np.zeros(nv)
    for l in range(L):
        for z in range(m):
            c[idx(l, z)] = -q[z] * W[l, z]
    sol = linprog(c, A_ub=A_ub, b_ub=b, A_eq=A_eq.tocsr(), b_eq=np.ones(m), bounds=(0, None), method="highs")
    assert sol.status == 0, sol.message
    return -sol.fun


def lp_eta_req(W, q, s, kind="bm"):
    """min eta s.t. some model reaches score >= s (direct LP, eta is a variable)."""
    lo, hi = 0.0, 1.0
    if lp_S_eta(W, q, 0.0, kind) >= s - 1e-12:
        return 0.0
    for _ in range(40):
        mid = (lo + hi) / 2
        if lp_S_eta(W, q, mid, kind) >= s - 1e-12:
            hi = mid
        else:
            lo = mid
    return hi


def lp_S_mdl(W, q, l_lo, h_hi):
    """max score over joint P(l,z) with marginal q and l_lo*pbar(l) <= P(l,z) <= h_hi*pbar(l)."""
    L, m = W.shape
    nv = L * m
    idx = lambda l, z: l * m + z
    rows, cols, vals, b = [], [], [], []
    r = 0
    for l in range(L):
        for z in range(m):
            # l_lo*sum_z' P(l,z') - P(l,z) <= 0
            for zz in range(m):
                rows += [r]; cols += [idx(l, zz)]; vals += [l_lo - (1.0 if zz == z else 0.0)]
            b.append(0.0); r += 1
            for zz in range(m):
                rows += [r]; cols += [idx(l, zz)]; vals += [(1.0 if zz == z else 0.0) - h_hi]
            b.append(0.0); r += 1
    A_ub = sparse.csr_matrix((vals, (rows, cols)), shape=(r, nv))
    A_eq = sparse.lil_matrix((m, nv))
    for z in range(m):
        for l in range(L):
            A_eq[z, idx(l, z)] = 1.0
    c = np.array([-W[l, z] for l in range(L) for z in range(m)], float)
    sol = linprog(c, A_ub=A_ub, b_ub=b, A_eq=A_eq.tocsr(), b_eq=q, bounds=(0, None), method="highs")
    assert sol.status == 0, sol.message
    return -sol.fun


def mdl_lmax(W, q, s):
    lo, hi = 0.0, float(np.min(q))
    if lp_S_mdl(W, q, 0.0, 1.0) < s - 1e-12:
        return None
    for _ in range(40):
        mid = (lo + hi) / 2
        if lp_S_mdl(W, q, mid, 1.0) >= s - 1e-12:
            lo = mid
        else:
            hi = mid
    return lo

# ------------------------------------------------------------------ rate-distortion
def rate_distortion(W, q, s_target, iters=20000):
    """min I(Lambda;Z) s.t. score >= s_target via Blahut-Arimoto with slope search.
    Distortion d(z,l) = 1 - W[l,z]. Returns bits."""
    d = 1.0 - W.T  # m x L
    L = W.shape[0]

    def ba(beta):
        r = np.full(L, 1.0 / L)
        for _ in range(iters):
            A = r[None, :] * np.exp(-beta * d)
            Qc = A / A.sum(1, keepdims=True)
            r_new = q @ Qc
            if np.max(np.abs(r_new - r)) < 1e-13:
                r = r_new
                break
            r = r_new
        A = r[None, :] * np.exp(-beta * d)
        Qc = A / A.sum(1, keepdims=True)
        D = float(np.sum(q[:, None] * Qc * d))
        with np.errstate(divide="ignore", invalid="ignore"):
            I = float(np.nansum(q[:, None] * Qc * np.log2(np.where(Qc > 0, Qc / r[None, :], 1))))
        return D, I

    D_target = 1.0 - s_target
    if D_target >= 1.0 - omega_c(W, q) - 1e-12:
        return 0.0
    lo, hi = 0.0, 200.0
    for _ in range(80):
        mid = (lo + hi) / 2
        D, I = ba(mid)
        if D > D_target:
            lo = mid
        else:
            hi = mid
    return ba(hi)[1]


def chsh_hall_branciard_IR(S_corr):
    h = lambda p: 0 if p in (0, 1) else -p * np.log2(p) - (1 - p) * np.log2(1 - p)
    return 2 - h((4 - S_corr) / 8) - ((4 + S_corr) / 8) * np.log2(3)

# ------------------------------------------------------------------ run
if __name__ == "__main__":
    from analysis_paths import output_parser, prepare_output
    args = output_parser(__doc__, "theory.json").parse_args()
    OUT = prepare_output(args.out)

    games = {"CHSH": chsh(), "GHZ3": mermin(3), "MagicSquare": magic_square()}
    Q_TARGET = {"CHSH": np.cos(np.pi / 8) ** 2, "GHZ3": 1.0, "MagicSquare": 1.0}
    etas = [0.0, 0.02, 0.05, 0.08, 0.1036, 0.15, 0.2, 0.25, 0.3]
    res["tightness"] = {}
    for name, (W, Z) in games.items():
        m = len(Z); q = np.full(m, 1 / m)
        w = omega_c(W, q)
        row = {"omega_c": w, "n_winvectors": int(W.shape[0]), "m": m}
        row["S_eta_bm"] = {f"{e:.4f}": lp_S_eta(W, q, e, "bm") for e in etas}
        row["max_dev_from_min(1,w+eta)"] = max(abs(row["S_eta_bm"][f"{e:.4f}"] - min(1, w + e)) for e in etas)
        row["S_pair"] = {f"{e:.4f}": lp_S_eta(W, q, e, "pair") for e in etas[:6]}
        row["max_dev_pair_from_min(1,w+(1-1/m)mu)"] = max(abs(row["S_pair"][f"{e:.4f}"] - min(1, w + (1 - 1 / m) * e)) for e in etas[:6])
        # loss profile structure: number of losses of optimal deterministic strategies
        opt = W[(W @ q) >= w - 1e-12]
        row["losses_of_optimal_strategies"] = sorted(set(int(m - r.sum()) for r in opt))
        res["tightness"][name] = row
        print(name, "w_c=", w, "dev_bm", row["max_dev_from_min(1,w+eta)"], "dev_pair", row["max_dev_pair_from_min(1,w+(1-1/m)mu)"], "losses", row["losses_of_optimal_strategies"])

    # matched comparison at quantum-optimal target and at hardware certified lower bounds
    targets = {"CHSH": [np.cos(np.pi / 8) ** 2, 0.75 + 0.08474], "GHZ3": [1.0, 0.75 + 0.21358], "MagicSquare": [1.0]}
    res["matched"] = []
    for name, (W, Z) in games.items():
        m = len(Z); q = np.full(m, 1 / m)
        for s in targets[name]:
            e_bm = lp_eta_req(W, q, s, "bm")
            e_pair = lp_eta_req(W, q, s, "pair")
            lmax = mdl_lmax(W, q, s)
            I = rate_distortion(W, q, s)
            entry = dict(game=name, target=float(s), eta_bm=e_bm, hall_M=2 * e_pair, F_retained=1 - e_pair,
                         mdl_lmax=lmax, I_bits=I)
            if name == "CHSH":
                entry["hall_branciard_IR"] = float(chsh_hall_branciard_IR(8 * s - 4))
                entry["hall_2011_M_from_2+3M"] = float((8 * s - 4 - 2) / 3)
                entry["hall_branciard_pmin_(4-S)/8"] = float((4 - (8 * s - 4)) / 8)
            res["matched"].append(entry)
            print(entry)

    # biased CHSH: product bias b = q_x(0) = q_y(0); target: isotropic Tsirelson behaviour (win prob cos^2(pi/8) in every context)
    W, Z = chsh()
    res["biased_chsh"] = []
    for bias in [0.5, 0.6, 0.7, 0.8, 0.9]:
        qx = np.array([bias, 1 - bias]); q = np.array([qx[x] * qx[y] for x, y in Z])
        w = omega_c(W, q)
        s = np.cos(np.pi / 8) ** 2
        e_exact = lp_eta_req(W, q, s, "bm")
        slope0 = (lp_S_eta(W, q, 0.01, "bm") - w) / 0.01
        I = rate_distortion(W, q, s) if s > w else 0.0
        ent = dict(bias=bias, q_min=float(q.min()), omega_c=w, target=s, naive_eta=max(0, s - w), exact_eta_req=e_exact,
                   ratio=(e_exact / (s - w)) if s > w else None, initial_slope=slope0, I_bits=I)
        res["biased_chsh"].append(ent)
        print(ent)

    # Mermin n-party: score-level eta_bm tightness and pairwise counting bound vs Alai's faithful values
    alai = {3: 1/3, 4: 1/3, 5: 2/5, 6: 2/5}
    res["mermin"] = []
    for n in [3, 4, 5]:
        W, Z = mermin(n); m = len(Z); q = np.full(m, 1 / m); w = omega_c(W, q)
        e_req = lp_eta_req(W, q, 1.0, "bm")
        count_bound = (1 - w) / (1 - 1 / m)
        mu_req = lp_eta_req(W, q, 1.0, "pair") if n <= 4 else None
        ent = dict(n=n, m=m, omega_c=w, theory_1_over_2_plus=0.5 + 2 ** (-int(np.ceil(n / 2))), eta_bm_req_perfect=e_req,
                   pairwise_counting_bound=count_bound, pairwise_exact_scorelevel=mu_req, alai_faithful=alai.get(n))
        res["mermin"].append(ent)
        print(ent)

    json.dump(res, open(OUT, "w"), indent=2, default=float)
