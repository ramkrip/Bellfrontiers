#!/usr/bin/env python3
"""Audit fresh outputs against retained v5 records and emit reviewable tables.

This script never edits the manuscript. Fresh-computation status is taken from
the execution manifest, not inferred from the mere presence of an output file.
"""
import argparse
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import beta
from analysis_paths import PACKAGE_ROOT, DEFAULT_RESULTS


def read_json(path):
    return json.loads(Path(path).read_text())


def rounded(value, digits=4):
    return str(Decimal(str(value)).quantize(Decimal(1).scaleb(-digits), rounding=ROUND_HALF_UP))


def miss_upper(misses, total):
    return 1.0 if misses == total else float(beta.ppf(.95, misses + 1, total - misses))


def compare_numeric_frames(fresh, old):
    assert list(fresh.columns) == list(old.columns), "CSV column mismatch"
    assert fresh.shape == old.shape, "CSV shape mismatch"
    deviations = {c: float(np.max(np.abs(fresh[c].to_numpy() - old[c].to_numpy())))
                  for c in fresh.select_dtypes(include="number").columns}
    return max(deviations.values(), default=0.0)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results-dir", type=Path, default=DEFAULT_RESULTS)
    args = parser.parse_args()
    results = args.results_dir.resolve()
    tables = results / "tables"
    tables.mkdir(exist_ok=True)
    reference = PACKAGE_ROOT / "analysis_scripts"
    manifest = read_json(results / "run_manifest.json")
    commands = manifest.get("previous_commands", []) + manifest["commands"]
    latest = {row["name"]: row for row in commands}
    summary = {"execution_status": {name: row["status"] for name, row in latest.items()},
               "fresh_results_directory": str(results), "hardware_execution": False,
               "archived_source_data": read_json(PACKAGE_ROOT / "data" / "source_manifest.json")}
    checks = []

    def check(name, value, expected=True):
        passed = bool(value == expected)
        checks.append({"name": name, "passed": passed})
        if not passed:
            raise AssertionError(name)

    raw = pd.read_csv(results / "hw_certificates.csv")
    pooled = pd.read_csv(results / "table3_consistent.csv")
    mitigated = pd.read_csv(results / "mitigated_fixed.csv")
    hw_deviation = compare_numeric_frames(raw, pd.read_csv(reference / "hw_certificates.csv"))
    check("54 hardware runs", len(raw), 54)
    check("raw and fractional-mitigated per-run reproduction", hw_deviation < 1e-12)
    check("mitigated backend excesses match v5", compare_numeric_frames(
        mitigated, pd.read_csv(reference / "mitigated_fixed.csv")) < 1e-12)
    check("pooled backend table matches v5", compare_numeric_frames(
        pooled, pd.read_csv(reference / "table3_consistent.csv")) < 1e-12)
    check("Bonferroni average dominates product", bool((raw.eta_avg_bonf >= raw.eta_prod - 1e-13).all()))
    hardware = pooled.merge(mitigated, on=["game", "backend"])
    hardware.to_csv(tables / "hardware_backend_table.csv", index=False)
    best_run = {}
    for game, sub in raw.groupby("game"):
        omega = .75 if game != "magic_square" else 8 / 9
        vals = []
        for row in sub.itertuples(index=False):
            nc = np.array(json.loads(row.ctx_N))
            radius = np.sqrt(np.log(len(sub) / .05) * np.sum((1 / len(nc)) ** 2 / nc) / 2)
            vals.append((max(0., row.S_hat - radius - omega), row.backend, row.shots))
        value, backend, shots = max(vals)
        best_run[game] = {"eta": value, "backend": backend, "shots_per_context": shots,
                          "family_size": len(sub)}
    summary["hardware"] = {"runs": len(raw), "max_absolute_reference_deviation": hw_deviation,
                           "max_Bonferroni_average_minus_cycle_product": float((raw.eta_avg_bonf - raw.eta_prod).max()),
                           "backend_table": hardware.to_dict(orient="records"),
                           "selection_corrected_best_runs": best_run}
    order = {"chsh": 0, "mermin_ghz": 1, "magic_square": 2}
    labels = {"chsh": "CHSH", "mermin_ghz": "Mermin--GHZ", "magic_square": "Magic sq."}
    rows = []
    for row in raw.assign(game_order=raw.game.map(order)).sort_values(["game_order", "backend", "shots"]).itertuples(index=False):
        rows.append(f"{labels[row.game]} & {row.backend.title()} & {row.shots} & {row.S_hat:.4f} & {row.p_min_ctx:.3f} & "
                    f"{row.eta_prod:.4f} & {row.eta_avg_bonf:.4f} & {row.eta_pool:.4f} & {row.eta_hoef:.4f} & {row.S_mit:.4f}\\\\")
    (tables / "sm_runs_table.tex").write_text("\n".join(rows) + "\n")

    qml = read_json(results / "qml_reanalysis_3000.json")
    accuracies = np.load(results / "qml_reanalysis_3000_mc_accs.npy")
    reference_accuracies = np.load(reference / "qml_reanalysis_3000_mc_accs.npy")
    qml["matches_archived_3000_accuracy_array"] = bool(np.array_equal(accuracies, reference_accuracies))
    check("QML generator scores reproduced", qml["max_abs_g_mismatch"] < 1e-12)
    check("exact classical released kernel correct count", qml["exact_classical_kernel_correct"], 40)
    check("hardware refit reproduces archived predictions", qml["hardware_refit_matches_archived_predictions"])
    check("3,000-generator accuracy array reproduced", qml["matches_archived_3000_accuracy_array"])
    summary["qml"] = qml

    random_rows = read_json(results / "premium_random_perinstance.json")
    reference_random = read_json(reference / "premium_random_perinstance.json")
    derived = []
    max_random_deviation = 0.0
    for row, old in zip(random_rows, reference_random):
        per = row["per_instance"]
        n = len(per)
        hits = np.array([p["phi"] == p["cv_pick"] for p in per])
        differences = np.array([p["oracle"] - p["cv"] for p in per])
        misses = int((~hits).sum())
        check(f"random-map coupling ({row['family_size']},{row['train_per_class']})",
              bool(np.all(np.abs(differences[hits]) <= 1e-12)))
        check(f"random-map per-instance records ({row['family_size']},{row['train_per_class']})",
              per == old["per_instance"])
        for key in ("oracle", "cv", "rbf", "premium", "miss", "recovery"):
            max_random_deviation = max(max_random_deviation, abs(row[key] - old[key]))
        exact_means = {key: Decimal(sum(int(round(40 * rec[key])) for rec in per)) / Decimal(40 * n)
                       for key in ("oracle", "cv", "rbf")}
        derived.append({"oracle_display_3dp": rounded(exact_means["oracle"], 3),
                        "cv_display_3dp": rounded(exact_means["cv"], 3),
                        "premium_display_3dp": rounded(exact_means["oracle"] - exact_means["cv"], 3),
                        "generic_display_3dp": rounded(exact_means["rbf"], 3),
                        "family_size": row["family_size"], "train_per_class": row["train_per_class"],
                        "tasks": n, "oracle": row["oracle"], "cv": row["cv"],
                        "premium": float(differences.mean()), "premium_ci95": row["premium_ci95"],
                        "misses": misses, "miss_fraction": misses / n,
                        "miss_CP95_upper": miss_upper(misses, n), "generic_rbf": row["rbf"],
                        "maximum_abs_score_difference_given_map_recovery": float(np.max(np.abs(differences[hits])))})
    check("10 randomized design rows", len(random_rows), 10)
    check("randomized design summary reproduced", max_random_deviation < 1e-12)
    pd.DataFrame(derived).to_csv(tables / "randomized_design_table.csv", index=False)
    summary["randomized_design"] = {"reference_max_absolute_deviation": max_random_deviation, "rows": derived}
    fixed = read_json(results / "premium_fixed.json")
    for row in fixed:
        denominator = 40 * row["tasks"]
        for key in ("oracle", "prereg", "rbf", "premium"):
            exact_mean = Decimal(round(row[key] * denominator)) / Decimal(denominator)
            row[key + "_display_3dp"] = rounded(exact_mean, 3)
        recovered = round(row["correct_pick"] * row["tasks"])
        row["recovery_percent_exact"] = str(Decimal(100 * recovered) / Decimal(row["tasks"]))
    pd.DataFrame(fixed).to_csv(tables / "fixed_map_design_table.csv", index=False)
    summary["fixed_map_design"] = fixed
    summary["feature_map_comparison"] = read_json(results / "featuremap_dependence.json")

    generic = read_json(results / "gg_v5.json")
    old_generic = read_json(reference / "gg_v5.json")
    for row, old in zip(generic["quantum_nearest_preceding"], old_generic["quantum_nearest_preceding"]):
        check(f"predecessor learner m={row['m']}", row["accuracy"], old["accuracy"])
        row["display_accuracy_four_decimals"] = rounded(row["accuracy"])
    check("randomized leave-one-out checks", all(row["worst_loo_errors"] <= 2 for row in generic["loo_worst"]))
    pd.DataFrame(generic["quantum_nearest_preceding"]).to_csv(tables / "generic_predecessor_table.csv", index=False)
    summary["generic_group"] = generic

    theory = read_json(results / "theory.json")
    frontier = read_json(results / "frontier_checks.json")
    max_frontier_error = max(abs(row[key] - row[key + "_formula"])
                             for rows in frontier.values() for row in rows for key in ("wc_free", "avg_free"))
    check("resource-relative LP formulas", max_frontier_error < 1e-7)
    check("single-loss marginal frontier", all(
        row["max_dev_from_min(1,w+eta)"] < 1e-7 for row in theory["tightness"].values()))
    repetition = read_json(results / "repetition.json")
    check("parallel CHSH2 value", repetition["parallel_CHSH2_value"], .625)
    check("sequential shared-memory CHSH2 value", repetition["sequential_memory_CHSH2_value_bruteforce"], .75 ** 2)
    summary["mathematical_checks"] = {"max_resource_relative_frontier_error": max_frontier_error,
                                      "theory": theory, "extra": read_json(results / "extra_checks.json"),
                                      "repetition": repetition, "bucket": read_json(results / "bucket_check.json"),
                                      "matched": read_json(results / "matched_and_curves.json"),
                                      "rac": read_json(results / "rac_theory.json"),
                                      "rac_threat": read_json(results / "rac_threat.json")}
    rac_rows = []
    for run in sorted((results / "rac").glob("rac*")):
        meta = read_json(run / "meta.json")
        analysis = read_json(run / "analysis.json")
        digest = hashlib.sha256((run / "settings.csv").read_bytes()).hexdigest()
        check(f"RAC settings checksum {run.name}", digest, meta["settings_sha256"])
        rac_rows.append({"scenario": run.name, "n": analysis["n"], "rounds": analysis["rounds"],
                         "S_hat": analysis["S_hat"], "eta_cert_sequential": analysis["eta_cert_sequential"],
                         "lag1_autocorrelation": analysis["lag1_autocorrelation"],
                         "iid_reference_sd_approx": analysis["lag1_autocorr_null_sd"],
                         "noise_parameters": meta["noise"], "settings_sha256": digest})
    check("four fully specified RAC simulation scenarios", len(rac_rows), 4)
    summary["rac_simulations"] = rac_rows
    pd.DataFrame(rac_rows).to_csv(tables / "rac_simulation_table.csv", index=False)
    for filename in ("math_checks.json", "rac_restricted_endpoints.json"):
        extra_path = PACKAGE_ROOT / "verification" / filename
        if extra_path.exists():
            summary.setdefault("independent_mathematical_audit", {})[filename] = read_json(extra_path)
    summary["checks"] = checks
    summary["all_checks_passed"] = all(row["passed"] for row in checks)
    summary["scope_notes"] = [
        "All included hardware data are archived: no new hardware job or experiment was run.",
        "The released restricted classical SVM score is verified from archived predictions; the v6 QML script refits the exact and hardware kernels.",
        "RAC simulations are fresh v6 runs with fully recorded parameters; the precise v5 drift/burst parameters and original shot files were not supplied.",
        "RAC lag-1 autocorrelation is descriptive; 1/sqrt(N) is an approximate iid reference scale, not a test robust to arbitrary dependence.",
        "The optional historical BSGS diagnostic does not count equality queries and does not verify the theorem's total-query bound.",
        "The earlier fixed-map and midpoint outputs are historical comparisons, not the current randomized-map or certified-predecessor results.",
        "Historical fill_* utilities are quarantined and are not executed; numerical analyses do not rewrite manuscript prose.",
    ]
    (results / "audit_results.json").write_text(json.dumps(summary, indent=2) + "\n")
    lines = ["v6 numerical and data reproducibility audit", "=" * 43, "",
             "Execution scope: offline numerical reanalysis and fresh software simulations only.",
             "See run_manifest.json for exact commands, elapsed times, versions and process exit codes.",
             "A saved result by itself is not evidence of a fresh rerun.", "",
             f"Hardware: {len(raw)} runs reproduced; max reference deviation {hw_deviation:.3g}.",
             f"Maximum Bonferroni-average minus product certificate: {(raw.eta_avg_bonf - raw.eta_prod).max():.15g}.",
             "The literal upper bound 7e-4 in v5 must be rounded upward to 7.2e-4.", "",
             "Backend hardware table:", hardware[["game", "backend", "N", "K", "S_pooled", "eta_CP", "eta_H", "mit_excess"]].to_string(index=False), "",
             "Quantum-kernel reproduction:", json.dumps(qml, indent=2), "",
             "Randomized design study:", pd.DataFrame(derived).to_string(index=False), "",
             "Certified predecessor simulation:", pd.DataFrame(generic["quantum_nearest_preceding"]).to_string(index=False), "",
             "RAC software simulations (fresh v6 records):",
             pd.DataFrame(rac_rows)[["scenario", "n", "rounds", "S_hat", "eta_cert_sequential", "lag1_autocorrelation"]].to_string(index=False), "",
             "Scope and limitations:", *["- " + note for note in summary["scope_notes"]], "",
             f"Audit checks passed: {sum(row['passed'] for row in checks)}/{len(checks)}."]
    report = "\n".join(lines) + "\n"
    (results / "data_audit.txt").write_text(report)
    if results == DEFAULT_RESULTS.resolve():
        (PACKAGE_ROOT / "verification" / "data_audit.txt").write_text(report)
        (PACKAGE_ROOT / "verification" / "data_audit.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(f"Audit passed: {len(checks)} checks; results and table artifacts written to {results}.")


if __name__ == "__main__":
    main()
