#!/usr/bin/env python3
"""Reproduce the v6 numerical analyses offline; never submit hardware jobs.

Run from any directory:
  python /path/to/QU10323A_PRA_final_v6/analysis_scripts/reproduce.py
Selected stages can be run with --stages hardware,math (see --help).
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import threading
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "analysis_scripts"
STAGES = ("hardware", "math", "qml", "design-random", "design-fixed",
          "featuremaps", "generic", "rac", "figures", "audit")


def verify_data():
    manifest = json.loads((ROOT / "data" / "source_manifest.json").read_text())
    checked = 0
    for name, entry in manifest["archives"].items():
        archive = ROOT / "data" / name
        if hashlib.sha256(archive.read_bytes()).hexdigest() != entry["sha256"]:
            raise ValueError(f"Archive checksum mismatch: {archive}")
        destination = ROOT / "data" / ("raw_games" if name.startswith("Quantum") else "raw_qml")
        # Restore missing extracted files only from the checksum-verified archive.
        with zipfile.ZipFile(archive) as source:
            for relative, digest in entry["extracted_files"].items():
                target = ROOT / relative
                if not target.exists():
                    member = str(target.relative_to(destination))
                    if Path(member).is_absolute() or ".." in Path(member).parts:
                        raise ValueError(f"Unsafe archive member: {member}")
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(source.read(member))
                if hashlib.sha256(target.read_bytes()).hexdigest() != digest:
                    raise ValueError(f"Extracted-file checksum mismatch: {relative}")
                checked += 1
    print(f"Verified two source archives and {checked} extracted files.", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", type=Path, default=ROOT / "verification" / "reproduced")
    parser.add_argument("--stages", default=",".join(STAGES),
                        help="Comma-separated stages: " + ",".join(STAGES))
    parser.add_argument("--jobs", type=int, default=3, help="Concurrent independent analysis processes")
    parser.add_argument("--qml-tasks", type=int, default=3000)
    parser.add_argument("--design-tasks", type=int, default=200)
    args = parser.parse_args()
    selected = set(args.stages.split(","))
    unknown = selected.difference(STAGES)
    if unknown:
        parser.error(f"Unknown stages: {sorted(unknown)}")
    if args.jobs < 1 or args.qml_tasks < 1 or args.design_tasks < 1:
        parser.error("Jobs and task counts must be positive")
    out = args.out_dir.expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    logs = out / "logs"
    logs.mkdir(exist_ok=True)
    cache = out / "matplotlib_cache"
    cache.mkdir(exist_ok=True)
    env = os.environ.copy()
    env.update(OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1",
               NUMEXPR_NUM_THREADS="1", MPLCONFIGDIR=str(cache), PYTHONHASHSEED="0")
    manifest = {"started_utc": datetime.now(timezone.utc).isoformat(),
                "python": platform.python_version(), "platform": platform.platform(),
                "versions": {name: importlib.metadata.version(name) for name in
                             ("numpy", "scipy", "pandas", "scikit-learn", "matplotlib")},
                "stages": sorted(selected), "qml_candidate_tasks": args.qml_tasks,
                "design_candidate_tasks_per_row": args.design_tasks,
                "thread_environment": {key: env[key] for key in
                                       ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "PYTHONHASHSEED")},
                "hardware_execution": False, "commands": []}
    lock = threading.Lock()
    manifest_path = out / "run_manifest.json"
    if manifest_path.exists():
        previous = json.loads(manifest_path.read_text())
        manifest["previous_commands"] = previous.get("previous_commands", []) + previous.get("commands", [])

    def save_manifest():
        manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")

    def run(name, script, *arguments):
        command = [sys.executable, str(script), *map(str, arguments)]
        record = {"name": name, "command": command,
                  "started_utc": datetime.now(timezone.utc).isoformat(),
                  "log": str((logs / (name + ".log")).relative_to(out))}
        start = time.monotonic()
        print(f"Starting {name}", flush=True)
        with (logs / (name + ".log")).open("w") as stream:
            completed = subprocess.run(command, cwd=ROOT, env=env, stdout=stream,
                                       stderr=subprocess.STDOUT, check=False)
        record.update(returncode=completed.returncode, elapsed_seconds=time.monotonic() - start,
                      status="passed" if completed.returncode == 0 else "failed")
        with lock:
            manifest["commands"].append(record)
            save_manifest()
        print(f"{record['status'].upper()}: {name} ({record['elapsed_seconds']:.1f} s)", flush=True)
        if completed.returncode:
            raise RuntimeError(f"{name} failed; see {logs / (name + '.log')}")

    def script(name, filename, *arguments):
        run(name, SCRIPTS / filename, *arguments)

    verify_data()
    save_manifest()
    if "hardware" in selected:
        script("hardware", "hw_analysis.py", "--out", out / "hw_certificates.csv")
        script("mitigated", "mitigated_fix.py", "--out", out / "mitigated_fixed.csv")
        script("hardware_table", "table3_consistent.py", "--hardware", out / "hw_certificates.csv",
               "--out", out / "table3_consistent.csv")
    independent = []
    if "math" in selected:
        independent += [("theory", "theory.py", "--out", out / "theory.json"),
                        ("extra_checks", "extra_checks.py", "--out", out / "extra_checks.json"),
                        ("repetition", "repetition.py", "--out", out / "repetition.json"),
                        ("bucket", "bucket_formula_check.py", "--out", out / "bucket_check.json"),
                        ("frontier", "frontier_checks.py", "--out", out / "frontier_checks.json"),
                        ("biased_frontier", "biased_frontier_check.py", "--out", out / "biased_frontier_check.json"),
                        ("thm1", "thm1_check.py", "--out", out / "thm1_check.json"),
                        ("biased_examples", "biased_examples.py", "--out", out / "biased_examples.json"),
                        ("mdl_contrast", "mdl_contrast_check.py", "--out", out / "mdl_contrast_check.json"),
                        ("label_leakage", "label_leakage.py", "--out", out / "label_leakage.json"),
                        ("rac_restricted", "rac_restricted_proofs.py", "--out", out / "rac_restricted_proofs.json"),
                        ("oracle_side_info", "oracle_side_info_check.py", "--out", out / "oracle_side_info_check.json"),
                        ("rac_theory", "rac_symmetric.py", "--out", out / "rac_theory.json"),
                        ("rac_threat", "rac_threat_models.py", "--out", out / "rac_threat.json")]
    if "qml" in selected:
        independent.append(("qml", "qml_reanalysis.py", "--tasks", args.qml_tasks,
                            "--out", out / "qml_reanalysis_3000.json"))
    if "design-random" in selected:
        independent.append(("design_random", "design_premium_random.py", "--tasks", args.design_tasks,
                            "--out", out / "premium_random_perinstance.json"))
    if "design-fixed" in selected:
        independent.append(("design_fixed", "design_premium_fam.py", "--tasks", args.design_tasks,
                            "--out", out / "premium_fixed.json"))
    if "featuremaps" in selected:
        independent.append(("featuremaps", "featuremap_dependence.py", "--tasks", args.design_tasks,
                            "--out", out / "featuremap_dependence.json"))
    if "generic" in selected:
        independent.append(("generic", "generic_group_v5.py", "--out", out / "gg_v5.json"))
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        futures = [pool.submit(script, *job) for job in independent]
        for future in futures:
            future.result()
    if "math" in selected:
        script("matched_curves", "matched_and_curves.py", "--hardware-table", out / "table3_consistent.csv",
               "--out", out / "matched_and_curves.json")
    if "rac" in selected:
        scenarios = [
            ("rac31_noiseless", 3, 40000, ["--p-dep", 0, "--e01", 0, "--e10", 0]),
            ("rac31_noisy", 3, 20000, ["--p-dep", .01, "--e01", .01, "--e10", .025]),
            ("rac31_drift_bursts", 3, 20000, ["--p-dep", .01, "--e01", .01, "--e10", .025,
                                           "--eps0", .10, "--drift-period", 5000,
                                           "--r-burst", .002, "--L-burst", 50, "--p-burst", .6]),
            ("rac21_noisy", 2, 20000, ["--p-dep", .01, "--e01", .01, "--e10", .025]),
        ]
        for name, n, rounds, noise in scenarios:
            destination = out / "rac" / name
            run(name, ROOT / "RAC_experiment" / "rac_simulate.py", "--n", n, "--rounds", rounds,
                "--seed", 2026, "--noise-seed", 7, "--out", destination, *noise)
            run(name + "_analysis", ROOT / "RAC_experiment" / "rac_analyze.py", destination,
                "--theory", out / "rac_theory.json")
    if "figures" in selected:
        script("figures", "figures.py", "--results-dir", out, "--out-dir", out / "figures")
    if "audit" in selected:
        script("audit", "audit_results.py", "--results-dir", out)
    manifest["completed_utc"] = datetime.now(timezone.utc).isoformat()
    manifest["status"] = "passed"
    save_manifest()
    print(f"Reproduction complete. Results: {out}", flush=True)


if __name__ == "__main__":
    main()
