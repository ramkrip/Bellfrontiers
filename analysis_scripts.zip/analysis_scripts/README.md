# Offline numerical reproduction for v6

The package includes the two source data archives, their extracted contents,
the analysis programs, and the outputs of a fresh v6 reproduction. No IBM
account, Qiskit installation, network access, or new hardware job is needed.

## One-command reproduction

Use Python 3.12 and the dependencies in `requirements.txt`. From the package
directory:

```bash
python -m pip install -r analysis_scripts/requirements.txt
python analysis_scripts/reproduce.py --jobs 3
```

The second command is the offline reproduction. The first command is only
needed when the listed dependencies are not already installed. It uses the
ordinary package installer and may require network access. The versions pinned
in `requirements.txt` are the versions actually used for the v6 audit.

The driver also works from a different directory:

```bash
python /path/to/QU10323A_PRA_final_v6/analysis_scripts/reproduce.py --out-dir /path/to/results --jobs 3
```

The default output is `verification/reproduced/`. `--out-dir` selects another
writable location. All script and source-data paths derive from `__file__` or
explicit command-line arguments. `--jobs 1` reduces simultaneous memory use.
Numerical worker processes use one BLAS thread each. A complete run includes
the 3,000-generator kernel study and both 200-instance-per-row design studies,
so it takes longer than a simple check of archived summaries.

Individual stages can be rerun:

```bash
python analysis_scripts/reproduce.py --stages hardware,math
python analysis_scripts/reproduce.py --stages qml
python analysis_scripts/reproduce.py --stages design-random,design-fixed,featuremaps
python analysis_scripts/reproduce.py --stages generic,rac
python analysis_scripts/reproduce.py --stages figures,audit
```

The `math` stage uses the pooled hardware table; the `rac` stage uses the RAC
theory output; `figures` and `audit` use the previous analysis outputs. Run the
complete command once before selectively rerunning dependent stages. The
driver preserves previous command records when rerunning selected stages.
Changing `--qml-tasks` or `--design-tasks` is useful for a smoke run, but the
archived-result audit deliberately requires the full manuscript sample sizes.

## Outputs and evidence

`run_manifest.json` records every command, package version, start time,
elapsed time, exit status, and log location. A file's presence alone is not
treated as evidence that it was recomputed. Each program's stdout and stderr
are retained under `logs/`.

`audit_results.json` and `data_audit.txt` distinguish freshly recomputed
results from the preserved v5 comparison records. `tables/` contains CSV
tables for hardware, randomized design, fixed-map design, the predecessor
learner, and the RAC simulations. `tables/sm_runs_table.tex` is a generated
standalone table fragment. `figures/` contains PDF and PNG figures generated
from the result files. The analysis does not rewrite `main.tex` or
`supplement.tex`; manuscript inclusion is a separate reviewable step.

The final v6 source includes the verified figure PDFs and per-run table.

## Source-data integrity

`data/source_manifest.json` gives the SHA-256 of each original archive and
every extracted input file. Both original archives were also verified against
their exact bytes in the recorded repository commit:

| Source | Identifier |
|---|---|
| Repository | https://github.com/ramkrip/quantadvantage |
| Commit | `7e9b046ed1c3b40eec1df2b2e28e8f01257d4aa6` |
| `Quantum_Nonlocal_Games.zip` | `5dc5831ed53ab376f27327c36d5f16fdd6eb3996c1ce589d6d14f398da51aba3` |
| `Ad_hoc_new_15_20.zip` | `75e044837ec7d654eb2253d669b12dc8bcb6311447916bbc4fddf93f25eb5beb` |

The driver verifies the archives and all 226 extracted data files before
running an analysis. If an extracted file is absent, it restores that file
from its verified archive. It rejects any checksum mismatch. Platform
metadata files in the archives are not extracted.

The nonlocal-game input consists of 54 runs: three games, three backends,
and six per-context shot budgets. The analysis checks integer raw counts,
equal per-context totals, and the expected number of contexts. Fractional
readout-mitigated counts are retained as floating-point values. Mitigated
scores are plug-in sensitivity estimates and are not assigned binomial
confidence bounds.

The quantum-kernel input includes all 70 released points, the 30-by-30
hardware training matrix, the 40-by-30 hardware test matrix, and the archived
40 paired predictions. Exact and hardware kernels are refitted with
training-only selection. The original restricted-comparator score is checked
directly from its archived predictions; that conventional-model fit is not
silently represented as a fresh v6 refit.

## Fixed algorithms, parameters, and seeds

| Study | Reproduction protocol |
|---|---|
| Released exact-kernel instance | Two-qubit ZZ map, two repetitions, scaling 2; generator reconstruction seed 123; `C=[0.1,1,10,100]`; three-fold stratified CV with shuffle and seed 0; balanced-accuracy scoring; first grid value wins a tie. |
| Kernel shot-noise study | 200 repetitions; 1,024 shots per entry; NumPy seed 7; CV seed equals repetition index; training matrix symmetrized and diagonal fixed to one. |
| Fresh kernel ensemble | 3,000 candidate generators; seed `10000+t`; 45-by-45 input grid; margin `abs(g)>0.25`; 15 train and 20 test points per class; CV seed `t`. All 3,000 candidates were retained in the audited run. |
| Randomized hidden-map design | Families of 6 and 12 maps; train/class 3, 5, 8, 15, 30; 200 candidates per row; instance seed `90000+t`; 20 test/class; same kernel-SVM grid and CV seed `t`; map ties follow declared family order. |
| Fixed-map comparison | Generating map `(2,2)`; seed `50000+t`; 200 unitaries per row; otherwise the documented design pipeline. This is a historical model-selection comparison. |
| Individual-map comparison | 200 instances, seed `20000+t`, 15 train/class; six candidate maps and Gaussian-kernel baseline. |
| Gaussian baseline | Bandwidth grid `[0.1,0.3,1,3,10]`, selected by the same training-only CV; entries computed only for the required submatrices. This gives the same entries as the original full matrix. |
| Design intervals | 4,000 paired bootstrap resamples, seed 1; miss-probability upper bound is one-sided 95% Clopper–Pearson. Seeds are reused across study rows; intervals concern each row separately. |
| Certified predecessor learner | `N=2**61-1`; `m=[10,30,100,300,1000]`; 100,000 trials per size; seed `7+m`; labels predicted by the cyclic predecessor. Four-decimal table values use decimal half-up rounding, so 0.99805 is displayed as 0.9981. |
| Leave-one-out check | 3,000 sampled concepts/sample sets for each `(N,m)=(11,5),(31,10),(101,20),(101,60)`; seed `N+m`; leave each example out in turn. This is a randomized check of the lemma, not enumeration of every sample set. |
| Other numerical checks | LPs use SciPy HiGHS; the prior-to-posterior randomized check uses seed 1; bucket partitions use seed 0 and exhaustive input enumeration for each selected partition. |
| RAC simulations | Settings seed 2026 and noise seed 7; explicit complete scenario definitions in `reproduce.py`; 4,096 calibration shots. The noiseless 3-to-1 case uses 40,000 rounds; other scenarios use 20,000. |

For the RAC drift/burst scenario, preparation-angle modulation is
`eps0=0.10` with period 5,000 rounds; a burst starts with probability 0.002
per eligible round, lasts 50 rounds, and raises depolarization to 0.6.
The stationary noise case and the baseline outside bursts use
`p_dep=0.01`, `e01=0.01`, and `e10=0.025`.
Every RAC run saves the exact arguments, settings digest, ordered settings,
ordered outcomes, and analysis. These are fresh v6 runs: the original v5
drift/burst command, shot-level files, and complete noise configuration were
not provided. Parameters were specified once, without tuning to recreate
the earlier displayed values.

## Scope of the checks

Additional bounded mathematical checks, including all relevant pooled-CP
critical boundaries and restricted-RAC saturation endpoints, are reproducible
with `python verification/math_checks.py`. Their outputs are
`verification/math_checks.json` and `verification/rac_restricted_endpoints.json`.

The numerical programs check finite models and simulations. They do not
replace mathematical proofs or validate hardware assumptions such as
locality, independent shots, or sequential revelation of settings. The RAC
lag-1 statistic is descriptive; `1/sqrt(N)` is only an approximate iid
reference scale.

The historical BSGS demonstration counts group operations and treats
equality comparisons as free. It is excluded from the default reproduction
and from the certified-learner table because it does not implement the
theorem's total-query accounting. It remains available with the explicitly
named `--include-auxiliary-bsgs` option in `generic_group_v5.py`.

`generic_group_task.py` and `gg.json` retain the earlier midpoint learner
for provenance. The current learner is `generic_group_v5.py` and the current
generated output is `verification/reproduced/gg_v5.json`.

The `fill_v3.py` and `fill_resource_sm.py` authoring utilities have been
renamed to `.py.disabled` under `historical_not_for_execution/`. Their old
absolute paths and manuscript replacements are preserved only as historical
source. Neither file is imported or executed. The preserved v5 JSON, CSV,
and NPY files alongside the scripts serve as comparison records; fresh v6
outputs are written under the selected results directory.
