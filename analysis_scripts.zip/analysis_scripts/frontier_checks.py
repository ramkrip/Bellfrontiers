"""Checks of the resource-relative frontier theorem against direct LPs.
Modes: worst-case ('wc') or instance-averaged ('avg') TV; reference = induced marginal ('marg') or free ('free').
Free-reference formulas to verify:
  S_wc_free(eta)  = max_w sum_z q_z min{ f_w(z) + eta, rmax(z) }
  S_avg_free(eta) = min{ S0 + eta, Smax }
"""
import json, sys, itertools
import numpy as np
from analysis_paths import output_parser, prepare_output
ARGS = output_parser(__doc__, "frontier_checks.json").parse_args()
OUT = prepare_output(ARGS.out)
from scipy.optimize import linprog
from scipy import sparse

def chsh():
    Z = [(x, y) for x in (0, 1) for y in (0, 1)]
    W = set()
    for a in itertools.product((0, 1), repeat=2):
        for b in itertools.product((0, 1), repeat=2):
            W.add(tuple(int((a[x] ^ b[y]) == (x & y)) for x, y in Z))
    return np.array(sorted(W), float), Z

def lp(W, q, eta, mode="wc", ref="marg"):
    L, m = W.shape
    nP, nT = L * m, L * m
    nv = nP + nT + L                       # P[l,z], T[l,z], Q[l]
    P = lambda l, z: l * m + z; T = lambda l, z: nP + l * m + z; Qi = lambda l: nP + nT + l
    R, C, V, b = [], [], [], []; r = 0
    for z in range(m):
        for l in range(L):
            for sgn in (1, -1):
                R += [r, r, r]; C += [P(l, z), Qi(l), T(l, z)]; V += [sgn, -sgn, -1]; b.append(0); r += 1
    if mode == "wc":
        for z in range(m):
            for l in range(L):
                R.append(r); C.append(T(l, z)); V.append(1)
            b.append(2 * eta); r += 1
    else:
        for z in range(m):
            for l in range(L):
                R.append(r); C.append(T(l, z)); V.append(q[z])
        b.append(2 * eta); r += 1
    Aub = sparse.csr_matrix((V, (R, C)), shape=(r, nv))
    Aeq = sparse.lil_matrix((m + 1 + (L if ref == "marg" else 0), nv)); beq = []
    for z in range(m):
        for l in range(L):
            Aeq[z, P(l, z)] = 1
        beq.append(1)
    for l in range(L):
        Aeq[m, Qi(l)] = 1
    beq.append(1)
    if ref == "marg":
        for l in range(L):
            for z in range(m):
                Aeq[m + 1 + l, P(l, z)] = q[z]
            Aeq[m + 1 + l, Qi(l)] = -1; beq.append(0)
    c = np.zeros(nv)
    for l in range(L):
        for z in range(m):
            c[P(l, z)] = -q[z] * W[l, z]
    s = linprog(c, A_ub=Aub, b_ub=b, A_eq=Aeq.tocsr(), b_eq=beq, bounds=(0, None), method="highs")
    assert s.status == 0, s.message
    return -s.fun

def formula_wc_free(W, q, eta):
    L, m = W.shape; rmax = W.max(axis=0)
    # variables w (L), u (m): max sum q u, u_z <= sum_l w_l W[l,z] + eta, u_z <= rmax_z
    nv = L + m; c = np.zeros(nv); c[L:] = -q
    A = np.zeros((m, nv)); bb = np.zeros(m)
    for z in range(m):
        A[z, :L] = -W[:, z]; A[z, L + z] = 1; bb[z] = eta
    Aeq = np.zeros((1, nv)); Aeq[0, :L] = 1
    bounds = [(0, None)] * L + [(None, rmax[z]) for z in range(m)]
    s = linprog(c, A_ub=A, b_ub=bb, A_eq=Aeq, b_eq=[1], bounds=bounds, method="highs")
    return -s.fun

def formula_avg_free(W, q, eta):
    S0 = float((W @ q).max()); Smax = float(q @ W.max(axis=0))
    return min(S0 + eta, Smax)

games = {}
W, Z = chsh(); games["CHSH uniform"] = (W, np.full(4, .25))
b = 0.6; games["CHSH biased b=0.6"] = (W, np.array([(b if x == 0 else 1 - b) * (b if y == 0 else 1 - b) for x, y in Z]))
games["single-loss, q=(0.6,0.3,0.1)"] = (np.array([[0, 1, 1], [1, 0, 1], [1, 1, 0]], float), np.array([.6, .3, .1]))
games["reviewer avg example"] = (np.array([[1, 0, 1], [0, 1, 1]], float), np.array([.25, .25, .5]))
games["with unwinnable input"] = (np.array([[1, 0, 0], [0, 1, 0]], float), np.array([.4, .4, .2]))
out = {}
for name, (W, q) in games.items():
    rows = []
    for eta in (0.0, 0.02, 0.05, 0.1, 0.2, 0.3, 0.5):
        r = dict(eta=eta,
                 wc_marg=lp(W, q, eta, "wc", "marg"), wc_free=lp(W, q, eta, "wc", "free"),
                 wc_free_formula=formula_wc_free(W, q, eta),
                 avg_marg=lp(W, q, eta, "avg", "marg"), avg_free=lp(W, q, eta, "avg", "free"),
                 avg_free_formula=formula_avg_free(W, q, eta))
        rows.append(r)
        assert abs(r["wc_free"] - r["wc_free_formula"]) < 1e-7, (name, r)
        assert abs(r["avg_free"] - r["avg_free_formula"]) < 1e-7, (name, r)
    out[name] = rows
    print(name)
    for r in rows:
        print("  " + "  ".join(f"{k}={v:.5f}" for k, v in r.items()))
json.dump(out, open(OUT, "w"), indent=1)
print("all free-reference formulas verified")
