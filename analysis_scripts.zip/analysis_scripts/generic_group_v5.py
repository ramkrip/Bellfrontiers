"""Generic-group interval task, v5.
(1) Certified quantum learner: after computing all discrete logarithms, predict the label of the nearest
    preceding training coordinate in the cyclic order of Z_N (ties: equal coordinate -> its label).
    Theorem: error <= 2/(m+1) + delta (leave-one-out over m+1 exchangeable examples, <= 2 label transitions).
    Simulated here by reading exponents (delta = 0).
(2) Randomized check of the leave-one-out lemma on small N: for sampled concepts and samples,
    the number of LOO errors among m+1 points is <= 2.
(3) Optional historical BSGS diagnostic handed s, q group operations, with equality comparisons free.
    This does not verify the manuscript theorem under its total-query accounting.
"""
import json, sys
import numpy as np

def predict_prev(N, K, a_tr, y_tr, a_te):
    d = (a_te - a_tr) % N                     # distance from training coordinate forward to test
    i = int(np.argmin(d))                     # d = 0 means equal coordinate
    return int(y_tr[i])

def quantum_accuracy(N, m, trials, seed):
    rng = np.random.default_rng(seed); K = (N - 1) // 2; c = 0
    for _ in range(trials):
        s = int(rng.integers(N)); a_tr = rng.integers(0, N, m); a_te = int(rng.integers(N))
        y_tr = (((a_tr - s) % N) < K).astype(int); y = int(((a_te - s) % N) < K)
        c += predict_prev(N, K, a_tr, y_tr, a_te) == y
    return c / trials

def loo_check(N, m, trials, seed):
    rng = np.random.default_rng(seed); K = (N - 1) // 2; worst = 0
    for _ in range(trials):
        s = int(rng.integers(N)); a = rng.integers(0, N, m + 1); y = (((a - s) % N) < K).astype(int)
        errs = 0
        for i in range(m + 1):
            mask = np.ones(m + 1, bool); mask[i] = False
            errs += predict_prev(N, K, a[mask], y[mask], int(a[i])) != y[i]
        worst = max(worst, errs)
    return worst

def bsgs_accuracy(N, q, trials, seed):
    rng = np.random.default_rng(seed); K = (N - 1) // 2; c = 0; b = q // 2; gsteps = q - b
    for _ in range(trials):
        s = int(rng.integers(N)); a = int(rng.integers(N)); y = int(((a - s) % N) < K)
        r = a % b; i = (a + (b - r) % b) // b; j = i * b - a
        found = (i < gsteps) and (0 <= j < b)
        c += 1 if found else int(y == 0)
    return c / trials

if __name__ == "__main__":
    from analysis_paths import output_parser, prepare_output
    parser = output_parser(__doc__, "gg_v5.json")
    parser.add_argument("--include-auxiliary-bsgs", action="store_true",
                        help="Historical group-operation-only diagnostic; not a theorem-budget verification")
    args = parser.parse_args()
    OUT = prepare_output(args.out)
    out = {"quantum_nearest_preceding": [], "loo_worst": [], "auxiliary_bsgs_group_operations_only": [], "bsgs_note": "Equality comparisons are free in this optional diagnostic; not a verification of the total-query theorem."}
    N = 2**61 - 1
    for m in (10, 30, 100, 300, 1000):
        acc = quantum_accuracy(N, m, 100000, 7 + m)
        out["quantum_nearest_preceding"].append(dict(N=N, m=m, trials=100000, correct=round(acc * 100000), accuracy=acc, bound=1 - 2 / (m + 1)))
        print("quantum", m, acc, 1 - 2 / (m + 1), flush=True)
    for (Ns, m) in ((11, 5), (31, 10), (101, 20), (101, 60)):
        w = loo_check(Ns, m, 3000, Ns + m)
        out["loo_worst"].append(dict(N=Ns, m=m, trials=3000, worst_loo_errors=int(w))); print("loo", Ns, m, w)
    Ns = 1000003
    for q in ((200, 600, 1000, 2000) if args.include_auxiliary_bsgs else ()):

        acc = bsgs_accuracy(Ns, q, 200000, 3 + q)
        B = 0.5 + (1 + (q + 2) * (q + 1)) / (2 * Ns)
        out["auxiliary_bsgs_group_operations_only"].append(dict(N=Ns, q=q, trials=200000, accuracy=acc, B=B)); print("bsgs", q, acc, B)
    json.dump(out, open(OUT, "w"), indent=1)
