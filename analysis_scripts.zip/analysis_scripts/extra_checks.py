"""Extra checks: (1) 2->1 random access code (prepare-and-measure, single sender) exact S_eta;
(2) prior (MDL) -> posterior TV conversion inequality and its tightness; (3) single-loss biased formula."""
import itertools, json, sys
import numpy as np
from analysis_paths import output_parser, prepare_output
ARGS = output_parser(__doc__, "extra_checks.json").parse_args()
OUT = prepare_output(ARGS.out)
from theory import lp_S_eta, omega_c, chsh, rate_distortion, lp_eta_req  # noqa: E402

res = {}
# (1) RAC: z=(x0,x1,y); sender e:(x0,x1)->m in {0,1}; receiver d:(m,y)->bit
Z = [(x0, x1, y) for x0 in (0, 1) for x1 in (0, 1) for y in (0, 1)]
W = set()
for e in itertools.product((0, 1), repeat=4):
    for d in itertools.product((0, 1), repeat=4):
        W.add(tuple(int(d[2 * e[2 * x0 + x1] + y] == (x0, x1)[y]) for x0, x1, y in Z))
W = np.array(sorted(W)); q = np.full(8, 1 / 8)
w = omega_c(W, q)
etas = [0, 0.05, 0.1, 0.1036, 0.15, 0.2, 0.25]
S = {e: lp_S_eta(W, q, e, "bm") for e in etas}
res["rac"] = dict(omega_c=w, S_eta={f"{e:.4f}": v for e, v in S.items()},
                  max_dev=max(abs(S[e] - min(1, w + e)) for e in etas),
                  losses_opt=sorted(set(int(8 - r.sum()) for r in W[(W @ q) >= w - 1e-12])),
                  eta_req_tsirelson=lp_eta_req(W, q, np.cos(np.pi / 8) ** 2, "bm"),
                  I_bits_tsirelson=rate_distortion(W, q, np.cos(np.pi / 8) ** 2))

# (2) conversion: for channels with l <= p(z|lam) <= h and fixed q, TV(p(.|z), p(.)) <= (h-q)(q-l)/(q(h-l))
rng = np.random.default_rng(1)
worst = 0
for trial in range(20000):
    m = 4; qz = np.full(m, 1 / m)
    l, h = sorted(rng.uniform(0, 1 / m, 1).tolist() + rng.uniform(1 / m, 1, 1).tolist())
    # random prior over K lambdas and random p(z|lam) within [l,h] matching q in expectation: rejection-free via mixing
    K = 6
    pl = rng.dirichlet(np.ones(K))
    P = rng.uniform(l, h, size=(K, m)); P = P / P.sum(1, keepdims=True)
    P = np.clip(P, l, h)
    P = P / P.sum(1, keepdims=True)
    if (P < l - 1e-12).any() or (P > h + 1e-12).any():
        continue
    qz = pl @ P
    post = (pl[:, None] * P) / qz[None, :]  # p(lam|z)
    tv = 0.5 * np.abs(post - pl[:, None]).sum(0)
    bound = (h - qz) * (qz - l) / (qz * (h - l))
    worst = max(worst, float(np.max(tv - bound)))
res["mdl_to_tv_max_violation"] = worst  # should be <= 0
# tightness: two-point prior achieving equality
qz0, l, h = 0.25, 0.1, 0.6
a = (qz0 - l) / (h - l)  # weight on lambda with p(z|lam)=h
tv_two = a * (h / qz0 - 1)
res["mdl_two_point_tv"] = tv_two
res["mdl_bound_value"] = (h - qz0) * (qz0 - l) / (qz0 * (h - l))

# (3) single-loss biased formula S_eta = min(1, 1 - q_min (1 - m eta)) for q_max <= 1/2
W, Zc = chsh()
dev = 0
for b in [0.5, 0.55, 0.6, 0.65, 0.7]:
    qx = np.array([b, 1 - b]); qq = np.array([qx[x] * qx[y] for x, y in Zc])
    for e in [0.0, 0.03, 0.07, 0.12, 0.2, 0.25]:
        dev = max(dev, abs(lp_S_eta(W, qq, e, "bm") - min(1, 1 - qq.min() * (1 - 4 * e))))
res["single_loss_formula_max_dev_(qmax<=1/2)"] = dev
print(json.dumps(res, indent=2, default=float))
json.dump(res, open(OUT, "w"), indent=2, default=float)
