#!/usr/bin/env python3
"""Likelihood-ratio (scale-free MDL) frontier for single-loss games, and the
contrast with the own-marginal measure under unequal setting probabilities.

Constraint: p(z|lambda) >= l q(z) for all z, lambda (equivalently
p(lambda|z) >= l p(lambda)). Reported value S^w = sum_z w(z) Pr[win|z].
Claim (Proposition 3):
  S^w_l = 1 - sum_z min{ l q(z) min_{z'!=z} w(z'),  w(z) [1 - l (1 - q(z))] },
so for uniform w, S^w_l = 1 - l/m for every setting law q.
"""
import json, sys
import numpy as np
from scipy.optimize import linprog
from biased_frontier_check import chsh_wins, ghz3_wins, ms_wins, random_single_loss

def lp_mdl(W, q, w, l):
    W = np.unique(np.asarray(W, int), axis=0); L, Z = W.shape; n = L * Z
    idx = lambda a, z: a * Z + z                      # joint P(lambda=a, z)
    c = np.zeros(n)
    for a in range(L):
        for z in range(Z):
            c[idx(a, z)] = -w[z] * W[a, z] / q[z]
    Aeq = np.zeros((Z, n))
    for z in range(Z):
        for a in range(L):
            Aeq[z, idx(a, z)] = 1
    Aub = np.zeros((L * Z, n))
    for a in range(L):
        for z in range(Z):
            r = a * Z + z
            Aub[r, [idx(a, zp) for zp in range(Z)]] += l * q[z]
            Aub[r, idx(a, z)] -= 1
    res = linprog(c, A_ub=Aub, b_ub=np.zeros(L * Z), A_eq=Aeq, b_eq=q, bounds=(0, None), method="highs")
    assert res.status == 0, res.message
    return -res.fun

def lp_mdl_abs(W, q, w, labs):
    """Absolute MDL lower bound p(z|lambda) >= l_abs (no upper bound)."""
    qq = np.asarray(q, float)
    return lp_mdl(W, qq, w, 1.0) if False else _lp_abs(W, qq, w, labs)

def _lp_abs(W, q, w, labs):
    W = np.unique(np.asarray(W, int), axis=0); L, Z = W.shape; n = L * Z
    idx = lambda a, z: a * Z + z
    c = np.zeros(n)
    for a in range(L):
        for z in range(Z):
            c[idx(a, z)] = -w[z] * W[a, z] / q[z]
    Aeq = np.zeros((Z, n))
    for z in range(Z):
        for a in range(L):
            Aeq[z, idx(a, z)] = 1
    Aub = np.zeros((L * Z, n))
    for a in range(L):
        for z in range(Z):
            r = a * Z + z
            Aub[r, [idx(a, zp) for zp in range(Z)]] += labs
            Aub[r, idx(a, z)] -= 1
    res = linprog(c, A_ub=Aub, b_ub=np.zeros(L * Z), A_eq=Aeq, b_eq=q, bounds=(0, None), method="highs")
    return -res.fun if res.status == 0 else -np.inf

def formula_mdl(q, w, l):
    q = np.asarray(q, float); w = np.asarray(w, float); m = len(q); loss = 0.0
    for z in range(m):
        other = min(w[zp] for zp in range(m) if zp != z)
        loss += min(l * q[z] * other, w[z] * (1 - l * (1 - q[z])))
    return 1 - loss

def meff(q):
    q = np.asarray(q, float); return len(q) - 2 + min(2.0, 1.0 / q.max())

def main():
    rng = np.random.default_rng(20261025)
    out = {}; dev = 0.0; n = 0
    games = [("CHSH", chsh_wins()), ("GHZ3", ghz3_wins()), ("magic square", ms_wins())]
    for t in range(90):
        if t % 5 < 3:
            name, W = games[t % 5]; m = len(W[0])
        else:
            m = int(rng.integers(2, 7)); W = random_single_loss(m, rng); name = "random m=%d" % m
        q = rng.dirichlet(np.ones(m) * rng.uniform(.3, 2))
        w = np.ones(m) / m if t % 2 == 0 else rng.dirichlet(np.ones(m) * rng.uniform(.3, 2))
        for l in [0.0, 0.2, 0.5, 0.8, 1.0]:
            v = lp_mdl(W, q, w, l); f = formula_mdl(q, w, l)
            dev = max(dev, abs(v - f)); n += 1
    out["proposition3_lp"] = dict(n_lp=n, max_dev=dev)
    # contrast table: conditional-frequency CHSH at the Tsirelson value
    s = np.cos(np.pi / 8) ** 2; W = chsh_wins(); w = np.ones(4) / 4
    rows = []
    laws = [("uniform", np.ones(4) / 4)]
    laws += [("preferred pair Q=%.2f" % Q, np.array([Q] + [(1 - Q) / 3] * 3)) for Q in (0.4, 0.55, 0.7, 0.85, 0.95)]
    laws += [("product b=%.2f" % b, np.array([b * b, b * (1 - b), (1 - b) * b, (1 - b) ** 2])) for b in (0.6, 0.7, 0.8, 0.9)]
    for name, q in laws:
        lo, hi = 0.0, 1.0                              # largest l reaching s, by LP bisection
        for _ in range(45):
            mid = (lo + hi) / 2
            if lp_mdl(W, q, w, mid) >= s - 1e-12: lo = mid
            else: hi = mid
        lo2, hi2 = 0.0, float(q.min())
        for _ in range(45):
            mid = (lo2 + hi2) / 2
            if _lp_abs(W, q, w, mid) >= s - 1e-12: lo2 = mid
            else: hi2 = mid
        rows.append(dict(law=name, q=q.tolist(), q_max=float(q.max()), q_min=float(q.min()), l_abs_lp=lo2,
                         l_ratio_lp=lo, l_ratio_formula=4 * (1 - s), l_abs_cap=float(q.min()),
                         m_eff=meff(q), eta_req=4 * (s - 0.75) / meff(q)))
    out["contrast_chsh_tsirelson"] = rows
    out["max_l_dev"] = max(abs(r["l_ratio_lp"] - r["l_ratio_formula"]) for r in rows)
    args = sys.argv[1:]
    path = args[args.index("--out") + 1] if "--out" in args else (args[0] if args else "mdl_contrast_check.json")
    json.dump(out, open(path, "w"), indent=1)
    print(out["proposition3_lp"], "l dev", out["max_l_dev"])
    for r in rows:
        print("%-24s qmax %.4f l_ratio %.4f l_abs %.4f (cap %.4f) eta_req %.4f" % (r["law"], r["q_max"], r["l_ratio_lp"], r["l_abs_lp"], r["l_abs_cap"], r["eta_req"]))

if __name__ == "__main__":
    main()
