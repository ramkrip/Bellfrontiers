"""Is the generating feature map inferable from public training data?
Ensemble: random generator unitary V; data generated with the ZZ map (reps=2, alpha=2) as in the paper.
Learners: exact fidelity kernel for each map in a family; plus training-only CV selection over the family;
plus classical RBF SVM (no feature-map knowledge)."""
import sys, json, numpy as np
from scipy.linalg import qr
from sklearn.svm import SVC
from sklearn.model_selection import StratifiedKFold, GridSearchCV, cross_val_score
H=np.array([[1,1],[1,-1]])/np.sqrt(2)
bits=np.array([[(k>>0)&1,(k>>1)&1] for k in range(4)])
def a1(psi,U,q):
    psi=psi.reshape(2,2); psi = psi@U.T if q==0 else U@psi; return psi.reshape(4)
def state(x,reps,alpha):
    psi=np.zeros(4,complex); psi[0]=1
    for _ in range(reps):
        psi=a1(psi,H,0); psi=a1(psi,H,1)
        for i in range(2): psi=psi*np.exp(1j*alpha*x[i]*bits[:,i])
        psi=psi*np.exp(1j*alpha*(np.pi-x[0])*(np.pi-x[1])*(bits[:,0]^bits[:,1]))
    return psi
def ru(rng):
    z=(rng.normal(size=(4,4))+1j*rng.normal(size=(4,4)))/np.sqrt(2); q,r=qr(z); d=np.diag(r); return q*(d/abs(d))
FAM=[(1,2.0),(2,2.0),(3,2.0),(4,2.0),(2,1.0),(2,3.0)]
TRUE=(2,2.0)
G=np.linspace(0,2*np.pi,45,endpoint=False); XG=np.array(np.meshgrid(G,G,indexing='ij')).reshape(2,-1).T
S={f:np.array([state(x,*f) for x in XG]) for f in FAM}
K={f:np.abs(S[f].conj()@S[f].T)**2 for f in FAM}
D=np.sqrt(((XG[:,None,:]-XG[None,:,:])**2).sum(-1))
def svm(Ktr,ytr,Kte,seed):
    cv=StratifiedKFold(3,shuffle=True,random_state=seed)
    g=GridSearchCV(SVC(kernel='precomputed'),{'C':[0.1,1,10,100]},cv=cv,scoring='balanced_accuracy').fit(Ktr,ytr)
    return g.predict(Kte), g.best_score_
ZP=np.diag([1.,-1,-1,1])
from analysis_paths import output_parser, prepare_output
parser=output_parser(__doc__, "featuremap_dependence.json")
parser.add_argument("--tasks", type=int, default=200)
args=parser.parse_args()
OUT=prepare_output(args.out)
NT=args.tasks; acc={str(f):[] for f in FAM}; acc['cv_selected']=[]; acc['rbf']=[]; picks=[]
for t in range(NT):
    rng=np.random.default_rng(20000+t); V=ru(rng); O=V.conj().T@ZP@V
    g=np.real(np.einsum('ni,ij,nj->n',S[TRUE].conj(),O,S[TRUE]))
    pos,neg=np.where(g>0.25)[0],np.where(g<-0.25)[0]
    if len(pos)<35 or len(neg)<35: continue
    ip,ineg=rng.choice(pos,35,replace=False),rng.choice(neg,35,replace=False)
    tr=np.r_[ip[:15],ineg[:15]]; te=np.r_[ip[15:],ineg[15:]]
    ytr=np.r_[np.ones(15,int),np.zeros(15,int)]; yte=np.r_[np.ones(20,int),np.zeros(20,int)]
    best=(-1,None,None)
    for f in FAM:
        p,cvs=svm(K[f][np.ix_(tr,tr)],ytr,K[f][np.ix_(te,tr)],t)
        a=np.mean(p==yte); acc[str(f)].append(a)
        if cvs>best[0]+1e-12: best=(cvs,f,a)
    acc['cv_selected'].append(best[2]); picks.append(str(best[1]))
    # classical RBF with gamma grid, no feature-map knowledge
    bestr=(-1,None)
    for gam in [0.1,0.3,1,3,10]:
        Kr_tr=np.exp(-gam*D[np.ix_(tr,tr)]**2)
        Kr_te=np.exp(-gam*D[np.ix_(te,tr)]**2)
        p,cvs=svm(Kr_tr,ytr,Kr_te,t)
        if cvs>bestr[0]: bestr=(cvs,np.mean(p==yte))
    acc['rbf'].append(bestr[1])
out={k:{'mean':float(np.mean(v)),'n':len(v)} for k,v in acc.items()}
from collections import Counter; out['cv_pick_freq']=dict(Counter(picks))
print(json.dumps(out,indent=1)); json.dump(out,open(OUT,'w'),indent=1)
