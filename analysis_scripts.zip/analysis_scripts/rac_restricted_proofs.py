#!/usr/bin/env python3
"""Analytic restricted-RAC frontiers and their checks.

Sender-only  (p(lambda|x)):  S <= 1 - 1/n + (1/n)(2/2^n + eta), attained for n = 2, 3.
Question-only (p(lambda|y)): for n = 3, every one-bit strategy has question profile v with
    pi.v <= max{3/4, (1 + max(pi))/2} for all question laws pi,
giving S <= 3/4 + 3 eta / 8; attained by revealing y with probability 3 eta / 2.
The envelope is proved analytically (SM S12): weighted success = 1/2 + E|sum_{j in D} pi_j R_j|/2,
with E|pi_1 R_1 + pi_2 R_2 + pi_3 R_3| = max{1/2, max(pi)}; checked here by exact enumeration.
Free reference: symmetrised p(.|y=1) = (c, d, e, e) over {majority, send bit 1, 2, 3},
G = (a, b, b, b); inf_G TV = (2/3)(d - e) and S - 3/4 = (d - 2e)/4 <= 3 eta / 8; checked here.
Recomputes the restricted LPs through saturation (eta up to 0.8) with the induced marginal
AND with a freely chosen reference (free=True); both must equal the closed forms.
"""
import itertools, json, sys
import numpy as np
from scipy.optimize import linprog
from rac_threat_models import solve

def question_profiles(n):
    X = list(itertools.product([0, 1], repeat=n)); prof = set()
    for e in itertools.product([0, 1], repeat=len(X)):
        for g in itertools.product([0, 1], repeat=2 * n):
            v = tuple(sum(g[2 * y + e[ix]] == x[y] for ix, x in enumerate(X)) / len(X) for y in range(n))
            prof.add(v)
    return sorted(prof)

def hull_violation(v, n):
    """max over pi of pi.v - max{3/4, (1+pi_max)/2}; LP in (pi, t)."""
    A = [np.r_[np.zeros(n), -1.0]]                              # 3/4 <= t
    b = [-0.75]
    for k in range(n):                                          # (1+pi_k)/2 <= t
        row = np.zeros(n + 1); row[k] = 0.5; row[-1] = -1; A.append(row); b.append(-0.5)
    c = np.r_[-np.asarray(v), 1.0]
    res = linprog(c, A_ub=np.array(A), b_ub=b, A_eq=[np.r_[np.ones(n), 0.0]], b_eq=[1], bounds=[(0, None)] * n + [(None, None)], method="highs")
    return -res.fun

def rademacher_identity(trials=2000, seed=0):
    """max |E|sum pi_j R_j| - max{1/2, max pi}| over random question laws (exact average over R)."""
    r = np.random.default_rng(seed); dev = 0.0
    signs = np.array(list(itertools.product([-1, 1], repeat=3)))
    for _ in range(trials):
        pi = r.dirichlet(np.ones(3) * r.choice([0.3, 1.0, 3.0]))
        dev = max(dev, abs(np.mean(np.abs(signs @ pi)) - max(0.5, pi.max())))
    return dev

def free_reference_tv(trials=2000, seed=1):
    """Check inf_G TV((c,d,e,e),(a,b,b,b)) = (2/3)(d-e) for d >= e.  TV is piecewise linear and
    convex in b on [0, 1/3], so its minimum is at an endpoint or a breakpoint (e, d, (d+2e)/3)."""
    r = np.random.default_rng(seed); dev = 0.0
    for _ in range(trials):
        d, e = sorted(r.dirichlet(np.ones(3))[:2], reverse=True)
        e = min(e, (1 - d) / 2); c = 1 - d - 2 * e
        bs = np.clip(np.array([0.0, 1 / 3, e, d, (d + 2 * e) / 3]), 0, 1 / 3)
        tv = 0.5 * (np.abs(c - (1 - 3 * bs)) + np.abs(d - bs) + 2 * np.abs(e - bs))
        dev = max(dev, abs(tv.min() - 2 * (d - e) / 3))
    return dev

def main():
    out = {}
    out["rademacher_identity_max_dev"] = rademacher_identity()
    out["free_reference_tv_max_dev"] = free_reference_tv()
    prof = question_profiles(3)
    out["n3_question_profiles"] = len(prof)
    out["n3_max_hull_violation"] = max(hull_violation(v, 3) for v in prof)
    etas = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 2 / 3, 0.7, 0.75, 0.8]
    rows, dev = [], 0.0
    for n in (2, 3):
        for model in ("question", "sender"):
          for free in (False, True):
            for eta in etas:
                lp = solve(n, eta, model, free=free)
                if model == "sender":
                    f = min(1.0, 1 - 1 / n + (2 / 2 ** n + eta) / n)
                else:
                    f = min(1.0, 0.75 + (eta / 2 if n == 2 else 3 * eta / 8))
                dev = max(dev, abs(lp - f)); rows.append(dict(n=n, model=model, reference="free" if free else "marginal", eta=eta, lp=lp, formula=f))
    out["lp_vs_formula_max_dev"] = dev; out["rows"] = rows
    args = sys.argv[1:]
    path = args[args.index("--out") + 1] if "--out" in args else "rac_restricted_proofs.json"
    json.dump(out, open(path, "w"), indent=1)
    print({k: v for k, v in out.items() if k != "rows"})

if __name__ == "__main__":
    main()
