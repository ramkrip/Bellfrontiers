#!/usr/bin/env python3
"""Exhaustive check that side information preserved by Theorem S6(a) need not give zero benefit.
N = 11, K = 5, m = 1 training point, q = 0 oracle calls. With a fresh random encoding the
learner sees only the equality pattern of (1, a1, a) and the training label; adding the
training logarithm a1 changes the optimal accuracy. Both values stay below B(0) = 9/11."""
import json, sys
from fractions import Fraction
from collections import defaultdict
from math import comb
N, K = 11, 5
f = lambda s, t: int((t - s) % N < K)
def bayes(obs):
    D = defaultdict(lambda: [0, 0])
    for s in range(N):
        for a1 in range(N):
            for a in range(N):
                D[obs(s, a1, a)][f(s, a)] += 1
    return Fraction(sum(max(v) for v in D.values()), N ** 3)
without = bayes(lambda s, a1, a: (a1 == 1, a == 1, a == a1, f(s, a1)))
with_log = bayes(lambda s, a1, a: (a1, a == 1, a == a1, f(s, a1)))
B0 = Fraction(N + 1, 2 * N) + Fraction(comb(1 + 2, 2), N)
out = dict(N=N, m=1, q=0, without=str(without), with_training_log=str(with_log), B0=str(B0),
           without_float=float(without), with_float=float(with_log), B0_float=float(B0))
args = sys.argv[1:]
json.dump(out, open(args[args.index("--out") + 1] if "--out" in args else "oracle_side_info_check.json", "w"), indent=1)
print(out)
