#!/usr/bin/env python3
"""Exact own-marginal frontier for biased single-loss games (Theorem 2, all q).

Claim: S_eta = min{1, 1 - q_min (1 - m_eff eta)}, m_eff = m - 2 + min{2, 1/q_max}.
Checks (i) the LP optimum over the full deterministic-strategy set against the
closed form, and (ii) the explicit attaining construction (nonnegativity,
normalization, own-marginal consistency, TV <= eta, score).
"""
import itertools, json, sys
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import lil_matrix, csr_matrix

def lp_value(W, q, eta):
    """Own-marginal worst-case relaxed value. W: (rules x instances) 0/1 wins."""
    W = np.unique(np.asarray(W, int), axis=0)
    L, Z = W.shape; n = Z * L; nv = 2 * n
    idx = lambda z, l: z * L + l
    c = np.zeros(nv)
    for z in range(Z):
        for l in range(L):
            c[idx(z, l)] = -q[z] * W[l, z]
    A = lil_matrix((n + Z, nv)); b = np.zeros(n + Z)
    r = 0
    for z in range(Z):
        for l in range(L):          # p(l|z) - sum_z' q(z') p(l|z') - t(z,l) <= 0
            for zp in range(Z):
                A[r, idx(zp, l)] -= q[zp]
            A[r, idx(z, l)] += 1; A[r, n + idx(z, l)] = -1; r += 1
    for z in range(Z):               # sum_l t(z,l) <= eta
        for l in range(L):
            A[r, n + idx(z, l)] = 1
        b[r] = eta; r += 1
    Aeq = lil_matrix((Z, nv))
    for z in range(Z):
        for l in range(L):
            Aeq[z, idx(z, l)] = 1
    res = linprog(c, A_ub=csr_matrix(A), b_ub=b, A_eq=csr_matrix(Aeq), b_eq=np.ones(Z),
                  bounds=(0, None), method="highs")
    assert res.status == 0, res.message
    return -res.fun

def formula(q, eta):
    q = np.asarray(q, float); m = len(q)
    meff = m - 2 + min(2.0, 1.0 / q.max())
    return min(1.0, 1.0 - q.min() * (1.0 - meff * eta)), meff

def construction(q, eta):
    """Attaining law on the single-loss rules s_z (label j = rule losing only on j)."""
    q = np.asarray(q, float); m = len(q)
    z0 = int(np.argmax(q)); q0 = q[z0]
    meff = m - 2 + min(2.0, 1.0 / q0)
    eta = min(eta, 1.0 / meff)
    zs = int(np.argmin(q)) if q.argmin() != z0 else int(np.argsort(q)[1])
    if q0 <= 0.5:
        # Theorem 2 (stationary redistribution): kappa with zero diagonal, q kappa = q
        from scipy.optimize import linprog as lp
        # find F >= 0, zero diagonal, row sums q, column sums q
        nv = m * m; Aeq = []; beq = []
        for i in range(m):
            row = np.zeros(nv); row[i*m:(i+1)*m] = 1; Aeq.append(row); beq.append(q[i])
            col = np.zeros(nv); col[i::m] = 1; Aeq.append(col); beq.append(q[i])
        bounds = [(0, 0) if i == j else (0, None) for i in range(m) for j in range(m)]
        F = lp(np.zeros(nv), A_eq=np.array(Aeq), b_eq=beq, bounds=bounds, method="highs").x.reshape(m, m)
        kappa = F / q[:, None]
        zstar = int(np.argmin(q))
        pi = np.full(m, eta); pi[zstar] = 1 - (m - 1) * eta
        P = np.array([pi - eta * np.eye(m)[z] + eta * kappa[z] for z in range(m)])
    else:
        r0 = (1 - q0) * eta / q0
        zstar = int(np.argmin(q))
        pi = np.full(m, eta); pi[z0] = r0; pi[zstar] = 1 - r0 - (m - 2) * eta
        P = np.zeros((m, m))
        others = [z for z in range(m) if z != z0]
        for z in others:             # move eta from own rule to s_{z0}
            P[z] = pi.copy(); P[z, z] -= eta; P[z, z0] += eta
        P[z0] = pi.copy(); P[z0, z0] -= r0
        for z in others:             # spread r0 over the others in proportion q_z/(1-q0)
            P[z0, z] += r0 * q[z] / (1 - q0)
    marg = q @ P
    tv = 0.5 * np.abs(P - marg).sum(axis=1).max()
    score = 1 - float(np.sum(q * np.diag(P)))
    return dict(min_entry=float(P.min()), row_sum_err=float(np.abs(P.sum(1) - 1).max()),
                marg_err=float(np.abs(marg - pi).max()), tv=float(tv), eta=float(eta), score=score)

# ---------------------------------------------------------------- games
def chsh_wins():
    out = []
    for a0, a1, b0, b1 in itertools.product([0, 1], repeat=4):
        out.append([int(((a0, a1)[x] ^ (b0, b1)[y]) == (x & y)) for x in (0, 1) for y in (0, 1)])
    return out

def ghz3_wins():
    inputs = [(0, 0, 0), (0, 1, 1), (1, 0, 1), (1, 1, 0)]
    out = []
    for f in itertools.product(itertools.product([0, 1], repeat=2), repeat=3):
        out.append([int((f[0][x] ^ f[1][y] ^ f[2][w]) == ((x + y + w) // 2) % 2) for x, y, w in inputs])
    return out

def ms_wins():
    rows = [r for r in itertools.product([0, 1], repeat=3) if sum(r) % 2 == 0]
    cols = [c for c in itertools.product([0, 1], repeat=3) if sum(c) % 2 == 1]
    out = set()
    for A in itertools.product(rows, repeat=3):
        for B in itertools.product(cols, repeat=3):
            out.add(tuple(int(A[x][y] == B[y][x]) for x in range(3) for y in range(3)))
    return [list(v) for v in out]

def random_single_loss(m, rng, extra=6):
    W = [[0 if z == j else 1 for z in range(m)] for j in range(m)]
    for _ in range(extra):
        lose = rng.random(m) < rng.uniform(0.2, 0.8)
        if not lose.any():
            lose[rng.integers(m)] = True
        W.append([0 if lose[z] else 1 for z in range(m)])
    return W

def random_q(m, rng, heavy):
    if heavy:
        q0 = rng.uniform(0.5, 0.97); rest = rng.dirichlet(np.ones(m - 1)) * (1 - q0)
        q = np.insert(rest, rng.integers(m), q0)
    else:
        while True:
            q = rng.dirichlet(np.ones(m))
            if q.max() <= 0.5: break
    return q

def main():
    rng = np.random.default_rng(20261024)
    etas = [0.0, 0.01, 0.02, 0.05, 0.1, 0.2, 0.3, 0.5]
    rec = {"lp_vs_formula": [], "construction": []}
    cases = []
    W_chsh, W_ghz, W_ms = chsh_wins(), ghz3_wins(), ms_wins()
    for b in [0.5, 0.6, 0.65, 0.7, 0.72, 0.8, 0.9, 0.95]:
        cases.append(("CHSH product b=%.2f" % b, W_chsh, np.array([(b if x == 0 else 1 - b) * (b if y == 0 else 1 - b) for x in (0, 1) for y in (0, 1)])))
    for t in range(6):
        cases.append(("CHSH random q #%d" % t, W_chsh, random_q(4, rng, heavy=t % 2 == 0)))
        cases.append(("GHZ3 random q #%d" % t, W_ghz, random_q(4, rng, heavy=t % 2 == 0)))
    for t in range(4):
        cases.append(("magic square random q #%d" % t, W_ms, random_q(9, rng, heavy=t % 2 == 0)))
    for m in range(2, 8):
        for t in range(4):
            cases.append(("random single-loss m=%d #%d" % (m, t), random_single_loss(m, rng), random_q(m, rng, heavy=(t % 2 == 0) or m == 2)))
    maxdev = 0.0
    for name, W, q in cases:
        for eta in etas:
            v = lp_value(W, q, eta); f, meff = formula(q, eta)
            maxdev = max(maxdev, abs(v - f))
            rec["lp_vs_formula"].append(dict(task=name, q=[float(x) for x in q], q_max=float(q.max()), m_eff=meff, eta=eta, lp=v, formula=f, dev=abs(v - f)))
        for eta in [0.01, 0.05, 0.1]:
            c = construction(q, eta); f, _ = formula(q, c["eta"])
            c.update(task=name, score_dev=abs(c["score"] - f)); rec["construction"].append(c)
    cons = rec["construction"]
    summary = dict(n_tasks=len(cases), n_lp=len(rec["lp_vs_formula"]),
                   n_heavy=sum(1 for _, _, q in cases if q.max() > 0.5),
                   max_lp_formula_dev=maxdev,
                   construction_min_entry=min(c["min_entry"] for c in cons),
                   construction_max_marg_err=max(c["marg_err"] for c in cons),
                   construction_max_row_err=max(c["row_sum_err"] for c in cons),
                   construction_max_tv_excess=max(c["tv"] - c["eta"] for c in cons),
                   construction_max_score_dev=max(c["score_dev"] for c in cons),
                   ms_win_vectors=len(np.unique(np.array(W_ms), axis=0)))
    rec["summary"] = summary
    args = sys.argv[1:]
    out = args[args.index("--out") + 1] if "--out" in args else (args[0] if args else "biased_frontier_check.json")
    json.dump(rec, open(out, "w"), indent=1)
    print(json.dumps(summary, indent=1))

if __name__ == "__main__":
    main()
