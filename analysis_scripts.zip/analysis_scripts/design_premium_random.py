"""Construction knowledge as an instance-dependent resource: the generating feature map is drawn at random.

Ensemble (one instance z): Phi ~ Uniform(Theta) [hidden], V ~ Haar(U(4)) [hidden],
training/test points sampled from the margin-filtered grid; labels sign <psi_Phi(x)|V^dag Z Z V|psi_Phi(x)>.
Public information C = (training inputs, training labels, test inputs); the declared family Theta and the
uniform prior over it are fixed before instances are drawn.
Designs (both followed by an exact fidelity-kernel SVM with training-only CV over C):
  oracle : uses Phi                      -> resource Theta_hat = Phi depends on the hidden part of z;
  CV     : picks a map in Theta by training-only cross-validation (a function of C only).
Coupling bound (Theorem C3 with the CV map as efficient reference):  S[oracle] - S[CV] <= P(CV map != Phi).
"""
import sys, json
import numpy as np
from design_premium_fam import S, K, D2, ZP, FAM6, FAM12, haar, fit

def run(ntr, family, NT):
    rec = {k: [] for k in ("oracle", "cv", "rbf", "hit", "diff_given_hit")}; per = []
    for t in range(NT):
        rng = np.random.default_rng(90000 + t)
        Phi = family[rng.integers(len(family))]
        V = haar(rng); O = V.conj().T @ ZP @ V
        g = np.real(np.einsum('ni,ij,nj->n', S[Phi].conj(), O, S[Phi]))
        pos, neg = np.where(g > 0.25)[0], np.where(g < -0.25)[0]
        if len(pos) < ntr + 20 or len(neg) < ntr + 20:
            continue
        ip, ineg = rng.choice(pos, ntr + 20, replace=False), rng.choice(neg, ntr + 20, replace=False)
        tr = np.r_[ip[:ntr], ineg[:ntr]]; te = np.r_[ip[ntr:], ineg[ntr:]]
        ytr = np.r_[np.ones(ntr, int), np.zeros(ntr, int)]; yte = np.r_[np.ones(20, int), np.zeros(20, int)]
        po, _ = fit(K[Phi][np.ix_(tr, tr)], ytr, K[Phi][np.ix_(te, tr)], t)
        acc_o = np.mean(po == yte)
        best = (-1, None, None)
        for f in family:
            p, cvs = fit(K[f][np.ix_(tr, tr)], ytr, K[f][np.ix_(te, tr)], t)
            if cvs > best[0] + 1e-12:
                best = (cvs, f, np.mean(p == yte))
        hit = best[1] == Phi
        rec["oracle"].append(acc_o); rec["cv"].append(best[2]); rec["hit"].append(float(hit))
        if hit:
            rec["diff_given_hit"].append(acc_o - best[2])
        bestr = (-1, None)
        for gam in (0.1, 0.3, 1, 3, 10):
            Kr_tr = np.exp(-gam * D2[np.ix_(tr, tr)])
            Kr_te = np.exp(-gam * D2[np.ix_(te, tr)])
            p, cvs = fit(Kr_tr, ytr, Kr_te, t)
            if cvs > bestr[0]:
                bestr = (cvs, np.mean(p == yte))
        rec["rbf"].append(bestr[1])
        per.append(dict(seed=90000 + t, family_size=len(family), train_per_class=ntr, phi=list(Phi), cv_pick=list(best[1]), oracle=float(acc_o), cv=float(best[2]), rbf=float(bestr[1])))
    o, c = np.array(rec["oracle"]), np.array(rec["cv"]); d = o - c; h = np.array(rec["hit"])
    rng = np.random.default_rng(1); n = len(d)
    bi = [rng.integers(0, n, n) for _ in range(4000)]
    bd = [d[i].mean() for i in bi]; bm = [1 - h[i].mean() for i in bi]
    return dict(train_per_class=ntr, family_size=len(family), tasks=n,
                oracle=float(o.mean()), cv=float(c.mean()), rbf=float(np.mean(rec["rbf"])),
                recovery=float(h.mean()), miss=float(1 - h.mean()),
                premium=float(d.mean()), premium_ci95=[float(np.quantile(bd, .025)), float(np.quantile(bd, .975))],
                miss_ci95=[float(np.quantile(bm, .025)), float(np.quantile(bm, .975))],
                max_abs_diff_given_hit=float(np.max(np.abs(rec["diff_given_hit"]))) if rec["diff_given_hit"] else None,
                bound_holds=bool(d.mean() <= 1 - h.mean() + 1e-12), per_instance=per)

if __name__ == "__main__":
    from analysis_paths import output_parser, prepare_output
    parser = output_parser(__doc__, "premium_random_perinstance.json")
    parser.add_argument("--tasks", type=int, default=200)
    parser.add_argument("--families", default="6,12")
    parser.add_argument("--train-sizes", default="3,5,8,15,30")
    args = parser.parse_args()
    OUT = prepare_output(args.out)
    NT = args.tasks; out = []
    for fam in [{"6": FAM6, "12": FAM12}[key] for key in args.families.split(",")]:
        for ntr in map(int, args.train_sizes.split(",")):
            r = run(ntr, fam, NT); out.append(r); print(json.dumps({k: v for k, v in r.items() if k != "per_instance"}), flush=True)
            json.dump(out, open(OUT, "w"), indent=1)
