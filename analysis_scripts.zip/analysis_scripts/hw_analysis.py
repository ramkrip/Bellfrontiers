"""Reanalysis of IBM nonlocal-game hardware data.

Computes, for every backend / game / shot budget:
  * per-context wins K_c and shots N_c (raw counts)
  * original 'cycle-product' certificate (Bonferroni CP, product, m-th root) -- to reproduce the paper
  * valid average-score certificates:
      (a) Bonferroni-CP average:  (1/m) sum_c L_c(alpha/m) - omega_c
      (b) pooled CP on independent shots (finite-count dominance conditions checked in the supplement) - omega_c
      (c) stratified Hoeffding: S_hat - sqrt(log(1/alpha) * sum_c (q_c^2/N_c) / 2) - omega_c
  * readout-mitigated plug-in average and its excess over omega_c
Outputs a CSV and prints summary tables.
"""
import sys, os, glob, re, json
import numpy as np
import pandas as pd
from scipy.stats import beta

from analysis_paths import DATA_DIR, output_parser, prepare_output
parser = output_parser(__doc__, "hw_certificates.csv")
parser.add_argument("--raw-root", type=__import__("pathlib").Path, default=DATA_DIR / "raw_games" / "Quantum_Nonlocal_Games")
args = parser.parse_args()
ROOT = str(args.raw_root.resolve())
OUT = str(prepare_output(args.out))
ALPHA = 0.05
OMEGA = {"chsh": 0.75, "mermin_ghz": 0.75, "magic_square": 8 / 9}
NCTX = {"chsh": 4, "mermin_ghz": 4, "magic_square": 9}


def cp_lower(k, n, a):
    return 0.0 if k == 0 else float(beta.ppf(a, k, n - k + 1))


def ctx_cols(df):
    for cols in (["Setting_X", "Setting_Y"], ["Set_X", "Set_Y", "Set_Z"], ["Row", "Col"]):
        if all(c in df.columns for c in cols):
            return cols
    raise ValueError(df.columns)


def load(path):
    df = pd.read_csv(path)
    cols = ctx_cols(df)
    g = df.groupby(cols)
    K = g.apply(lambda d: float(d.loc[d.Win == 1, "Count"].sum()), include_groups=False)  # float: mitigated counts are fractional
    N = g["Count"].sum()
    return K.values.astype(float), N.values.astype(float), list(K.index)


rows = []
for d in sorted(glob.glob(os.path.join(ROOT, "ibm_*_*"))):
    name = os.path.basename(d)
    m = re.match(r"ibm_(fez|kingston|marrakesh)_(chsh|mermin_ghz|magic_square)$", name)
    if not m:
        continue
    backend, game = m.groups()
    for sd in sorted(glob.glob(os.path.join(d, "*"))):
        sh = re.search(r"(\d+)", os.path.basename(sd))
        if not sh:
            continue
        shots = int(sh.group(1))
        raw = glob.glob(os.path.join(sd, "*raw_counts*.csv"))
        mit = glob.glob(os.path.join(sd, "*mitigated_counts*.csv"))
        if not raw:
            continue
        K, N, idx = load(raw[0])
        assert np.all(K == np.rint(K)) and np.all(N == np.rint(N)), "Raw counts must be integers"
        assert np.all((0 <= K) & (K <= N)) and np.all(N == shots), (raw[0], K, N)
        m_ = len(K)
        assert m_ == NCTX[game], (name, sd, m_)
        om = OMEGA[game]
        q = np.full(m_, 1.0 / m_)
        p_hat = K / N
        S_hat = float(np.dot(q, p_hat))
        Lc = np.array([cp_lower(k, n, ALPHA / m_) for k, n in zip(K, N)])
        L_block = float(np.prod(Lc))
        eta_prod = max(0.0, L_block ** (1.0 / m_) - om)
        L_avg_bonf = float(np.dot(q, Lc))
        eta_avg_bonf = max(0.0, L_avg_bonf - om)
        L_pool = cp_lower(int(K.sum()), int(N.sum()), ALPHA)
        eta_pool = max(0.0, L_pool - om)
        rad = np.sqrt(np.log(1 / ALPHA) * np.sum(q ** 2 / N) / 2.0)
        L_hoef = S_hat - rad
        eta_hoef = max(0.0, L_hoef - om)
        S_mit = np.nan
        p_mit = None
        if mit:
            Km, Nm, _ = load(mit[0])
            p_mit = Km / Nm
            S_mit = float(np.dot(q, p_mit))
        rows.append(dict(game=game, backend=backend, shots=shots, m=m_,
                         N_total=int(N.sum()), S_hat=S_hat,
                         p_min_ctx=float(p_hat.min()), p_max_ctx=float(p_hat.max()),
                         L_block=L_block, eta_prod=eta_prod,
                         L_avg_bonf=L_avg_bonf, eta_avg_bonf=eta_avg_bonf,
                         L_pool=L_pool, eta_pool=eta_pool,
                         L_hoef=L_hoef, eta_hoef=eta_hoef,
                         S_mit=S_mit, excess_mit=(S_mit - om) if mit else np.nan,
                         geo_mean_Lc=float(L_block ** (1.0 / m_)),
                         ctx_p_hat=json.dumps([round(x, 6) for x in p_hat]),
                         ctx_K=json.dumps([int(x) for x in K]), ctx_N=json.dumps([int(x) for x in N])))

if len(rows) != 54:
    raise ValueError(f"Expected 54 released hardware runs; found {len(rows)} in {ROOT}")
df = pd.DataFrame(rows).sort_values(["game", "backend", "shots"]).reset_index(drop=True)
df.to_csv(OUT, index=False)
pd.set_option("display.width", 250)
pd.set_option("display.max_columns", 30)
print(df[["game", "backend", "shots", "S_hat", "p_min_ctx", "eta_prod", "eta_avg_bonf", "eta_pool", "eta_hoef", "S_mit", "excess_mit"]].to_string())
print()
for g in df.game.unique():
    sub = df[df.game == g]
    for col in ["eta_prod", "eta_avg_bonf", "eta_pool", "eta_hoef", "excess_mit"]:
        i = sub[col].idxmax()
        print(f"{g:13s} max {col:13s} = {sub.loc[i, col]:.5f}  ({sub.loc[i,'backend']}, {sub.loc[i,'shots']})")
    print()

# ---------------- selection-aware summaries ----------------
print("\n=== Selection-aware certificates ===")
summ = []
for g in df.game.unique():
    om = OMEGA[g]
    for b in sorted(df.backend.unique()):
        sub = df[(df.game == g) & (df.backend == b)]
        K = sum(np.array(json.loads(k)).sum() for k in sub.ctx_K)
        N = sum(np.array(json.loads(n)).sum() for n in sub.ctx_N)
        # pooled across all six runs on this backend; equal shots per context within each run
        # stratified Hoeffding across all runs: weights q_c / R per run (R runs), each shot weight q_c/(R*N_c)
        Ns = [np.array(json.loads(n)) for n in sub.ctx_N]
        Ks = [np.array(json.loads(k)) for k in sub.ctx_K]
        R = len(Ns); m_ = len(Ns[0]); q = 1.0 / m_
        S_runavg = float(np.mean([np.dot(np.full(m_, q), k / n) for k, n in zip(Ks, Ns)]))
        rad = np.sqrt(np.log(1 / ALPHA) * sum(np.sum((q / R) ** 2 / n) for n in Ns) / 2)
        L_pool = cp_lower(int(K), int(N), ALPHA)
        summ.append(dict(game=g, backend=b, runs=R, shots_total=int(N), S_pooled=K / N, S_runavg=S_runavg,
                         eta_pooledCP=max(0, L_pool - om), eta_hoef_allruns=max(0, S_runavg - rad - om)))
    # Bonferroni over the 18 runs for the 'best run' report (stratified Hoeffding at alpha/18)
    sub = df[df.game == g]
    best = 0; arg = None
    for _, r in sub.iterrows():
        N_c = np.array(json.loads(r.ctx_N)); m_ = len(N_c)
        rad = np.sqrt(np.log(len(sub) / ALPHA) * np.sum((1 / m_) ** 2 / N_c) / 2)
        e = max(0, r.S_hat - rad - om)
        if e > best:
            best, arg = e, (r.backend, r.shots)
    print(f"{g:13s} best-run stratified-Hoeffding certificate with Bonferroni over {len(sub)} runs: {best:.5f} at {arg}")
S = pd.DataFrame(summ)
print(S.to_string())
S.to_csv(OUT.replace(".csv", "_backend_pooled.csv"), index=False)
