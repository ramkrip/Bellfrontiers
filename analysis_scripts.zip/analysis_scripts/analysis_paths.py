"""Shared, working-directory-independent paths for the offline analyses."""
import argparse
from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PACKAGE_ROOT / "data"
DEFAULT_RESULTS = PACKAGE_ROOT / "verification" / "reproduced"


def output_parser(description, filename):
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("--out", type=Path, default=DEFAULT_RESULTS / filename,
                        help="Output file (default: package verification/reproduced directory)")
    return parser


def prepare_output(path):
    path = Path(path).expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    return path
