"""Matched comparison at the final hardware certified lower bounds + curves for the analytic figure."""
import json, sys
import numpy as np
from theory import chsh, mermin, magic_square, omega_c, lp_S_eta, lp_eta_req, mdl_lmax, rate_distortion  # noqa

from pathlib import Path
import pandas as pd
from analysis_paths import DEFAULT_RESULTS, output_parser, prepare_output
parser = output_parser(__doc__, "matched_and_curves.json")
parser.add_argument("--hardware-table", type=Path, default=DEFAULT_RESULTS / "table3_consistent.csv")
args = parser.parse_args()
OUT = prepare_output(args.out)
hardware = pd.read_csv(args.hardware_table)
out = {}
hw = {name: float(hardware.loc[hardware.game == game, "L_CP"].max())
      for name, game in (("CHSH", "chsh"), ("GHZ3", "mermin_ghz"))}
G = {"CHSH": chsh(), "GHZ3": mermin(3), "MagicSquare": magic_square()}
out["matched_hw"] = []
for name, s in hw.items():
    W, Z = G[name]; q = np.full(len(Z), 1 / len(Z))
    out["matched_hw"].append(dict(game=name, target=s, eta_bm=lp_eta_req(W, q, s, "bm"),
                                  hall_M=2 * lp_eta_req(W, q, s, "pair"), mdl_lmax=mdl_lmax(W, q, s),
                                  I_bits=rate_distortion(W, q, s)))

# closed form check of RD for single-loss transitive games
def rd_closed(m, s):
    D = 1 - s
    h = 0 if D in (0, 1) else -D * np.log2(D) - (1 - D) * np.log2(1 - D)
    return np.log2(m) - h - (1 - D) * np.log2(m - 1)

dev = 0
for name, m in [("CHSH", 4), ("GHZ3", 4), ("MagicSquare", 9)]:
    W, Z = G[name]; q = np.full(m, 1 / m); w = omega_c(W, q)
    for s in np.linspace(w + 0.01, 0.999, 6):
        dev = max(dev, abs(rate_distortion(W, q, s) - rd_closed(m, s)))
out["rd_closed_form_max_dev"] = dev

# curves
W, Z = chsh()
excess = np.linspace(0, 0.25, 26)
curves = {}
for b in [0.5, 0.6, 0.65]:
    qx = np.array([b, 1 - b]); q = np.array([qx[x] * qx[y] for x, y in Z])
    w = omega_c(W, q)
    curves[f"chsh_b{b}"] = dict(eta=excess.tolist(), excess=[lp_S_eta(W, q, e, "bm") - w for e in excess],
                                q_min=float(q.min()), omega_c=w)
ex = np.linspace(0, 0.25, 51)
curves["rd_m4"] = dict(excess=ex.tolist(), I=[rd_closed(4, 0.75 + e) for e in ex])
ex9 = np.linspace(0, 1 / 9, 41)
curves["rd_m9"] = dict(excess=ex9.tolist(), I=[rd_closed(9, 8 / 9 + e) for e in ex9])
curves["pinsker"] = dict(excess=ex.tolist(), I=[2 * e ** 2 / np.log(2) for e in ex])  # I >= 2 eta^2 nats
out["curves"] = curves
json.dump(out, open(OUT, "w"), indent=2, default=float)
print(json.dumps({k: v for k, v in out.items() if k != "curves"}, indent=2, default=float))
