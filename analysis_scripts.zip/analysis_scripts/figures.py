"""Figures for the revised manuscript (static, print, light surface).
Palette: validated categorical slots 1-3 (#2a78d6, #eb6834, #1baf7a) + neutral gray for references.
Identity is never color-alone: distinct markers/linestyles + legend + direct labels.
"""
import json, sys, os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from pathlib import Path
import argparse
from analysis_paths import DEFAULT_RESULTS
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--results-dir", type=Path, default=DEFAULT_RESULTS)
parser.add_argument("--out-dir", type=Path, default=DEFAULT_RESULTS / "figures")
args = parser.parse_args()
RESULTS = args.results_dir.resolve()
OUTDIR = args.out_dir.resolve()
OUTDIR.mkdir(parents=True, exist_ok=True)
C1, C2, C3 = "#2a78d6", "#eb6834", "#1baf7a"
GRAY, INK, INK2 = "#8a8986", "#0b0b0b", "#52514e"
plt.rcParams.update({
    "font.family": "serif", "font.size": 8.5, "axes.labelsize": 8.5, "axes.titlesize": 8.5,
    "legend.fontsize": 7.2, "xtick.labelsize": 7.5, "ytick.labelsize": 7.5,
    "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
    "axes.grid": True, "grid.color": "#e6e5e1", "grid.linewidth": 0.6, "axes.axisbelow": True,
    "lines.linewidth": 1.6, "lines.markersize": 4.5, "savefig.dpi": 300, "figure.dpi": 150,
    "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
    "mathtext.fontset": "dejavuserif",
})

def save(fig, name):
    for ext in ("pdf", "png"):
        fig.savefig(os.path.join(OUTDIR, f"{name}.{ext}"), bbox_inches="tight")
    plt.close(fig)

# ---------------------------------------------------------------- Fig: analytic results
matched = json.load(open(RESULTS / "matched_and_curves.json"))
mc = matched["curves"]
fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.55))
a = ax[0]
e = np.array(mc["chsh_b0.5"]["eta"])
a.plot(e, e, color=GRAY, ls="--", lw=1.2, label=r"universal gain bound $\eta$")
styles = [("chsh_b0.5", C1, "o", r"$b=0.5$ (uniform)"), ("chsh_b0.6", C2, "s", r"$b=0.6$"), ("chsh_b0.65", C3, "^", r"$b=0.65$")]
for key, col, mk, lab in styles:
    d = mc[key]
    a.plot(d["eta"], d["excess"], color=col, marker=mk, markevery=5, label=lab + rf", $mq_{{\min}}={4*d['q_min']:.2f}$")
a.set_xlabel(r"benchmark dependence $\eta$")
a.set_ylabel(r"exact gain $S_\eta-S_0$")
a.set_xlim(0, 0.25); a.set_ylim(0, 0.27)
a.legend(loc="upper left", handlelength=1.8)
a.set_title("(a) CHSH with biased inputs (exact LP)", loc="left")

b = ax[1]
ex = np.array(mc["rd_m4"]["excess"])
b.plot(mc["pinsker"]["excess"], mc["pinsker"]["I"], color=GRAY, ls="--", lw=1.2, label="Pinsker bound")
b.plot(ex, mc["rd_m4"]["I"], color=C1, marker="o", markevery=10, label="CHSH = Mermin–GHZ$_3$ = RAC")
b.plot(mc["rd_m9"]["excess"], mc["rd_m9"]["I"], color=C2, marker="s", markevery=8, label="magic square")
# certified hardware points (pooled exact CP, 95%) on the m=4 curve
from math import log2
def rd(m, s):
    D = 1 - s; h = 0 if D in (0, 1) else -D*log2(D)-(1-D)*log2(1-D)
    return log2(m) - h - (1 - D) * log2(m - 1)
for point in matched["matched_hw"]:
    exc = point["target"] - 0.75
    lab = "CHSH (IBM)" if point["game"] == "CHSH" else "GHZ (IBM)"
    b.plot([exc], [rd(4, 0.75 + exc)], marker="D", color=INK, ms=4.5, ls="none")
    b.annotate(lab, (exc, rd(4, 0.75 + exc)), textcoords="offset points", xytext=(-48, 6) if 'CHSH' in lab else (5, -3), fontsize=7, color=INK2)
b.axvline(np.cos(np.pi/8)**2 - 0.75, color=GRAY, lw=0.8, ls=":")
b.text(np.cos(np.pi/8)**2 - 0.75 + 0.004, 0.235, "Tsirelson", fontsize=6.8, color=INK2)
b.set_xlabel(r"score excess $s-S_0$")
b.set_ylabel(r"minimal $I(\Lambda;Z)$ (bits)")
b.set_xlim(0, 0.25); b.set_ylim(0, 0.43)
b.legend(loc="upper left", handlelength=1.8)
b.set_title("(b) rate–distortion cost of a classical explanation", loc="left")
fig.tight_layout(w_pad=2.0)
save(fig, "fig_analytic")

# ---------------------------------------------------------------- Fig: hardware certificates
df = pd.read_csv(RESULTS / "hw_certificates.csv")
fig, ax = plt.subplots(1, 3, figsize=(7.0, 2.45))
bk = [("fez", C1, "o", "Fez"), ("kingston", C2, "s", "Kingston"), ("marrakesh", C3, "^", "Marrakesh")]
for i, (game, ideal, title) in enumerate([("chsh", np.cos(np.pi/8)**2 - 0.75, "(a) CHSH"), ("mermin_ghz", 0.25, "(b) Mermin–GHZ")]):
    a = ax[i]
    for key, col, mk, lab in bk:
        s = df[(df.game == game) & (df.backend == key)].sort_values("shots")
        a.plot(s.shots, s.eta_pool, color=col, marker=mk, label=f"{lab}, raw (95% LCB)")
        a.plot(s.shots, s.excess_mit, color=col, marker=mk, mfc="white", ls=":", lw=1.1, label=f"{lab}, mitigated plug-in")
    a.axhline(ideal, color=GRAY, ls="--", lw=1.0, label="ideal-quantum threshold" if i == 0 else None)
    a.set_xscale("log", base=2); a.set_xticks([128, 256, 512, 1024, 2048, 4096]); a.set_xticklabels(["128", "256", "512", "1k", "2k", "4k"])
    a.set_xlabel("shots per context")
    a.set_title(title, loc="left")
ax[0].set_ylabel("score excess\n(raw 95% lower bound)"); ax[1].set_ylabel("score excess\n(raw 95% lower bound)")
ax[0].set_ylim(0, 0.14); ax[1].set_ylim(0.15, 0.27)
a = ax[2]
for key, col, mk, lab in bk:
    s = df[(df.game == "magic_square") & (df.backend == key)].sort_values("shots")
    a.plot(s.shots, s.S_hat, color=col, marker=mk, label=lab)
a.axhline(8/9, color=GRAY, ls="--", lw=1.0)
a.text(130, 8/9 + 0.004, r"classical value $S_0=8/9$", fontsize=6.6, color=INK2)
a.set_xscale("log", base=2); a.set_xticks([128, 256, 512, 1024, 2048, 4096]); a.set_xticklabels(["128", "256", "512", "1k", "2k", "4k"])
a.set_ylim(0.74, 0.92); a.set_xlabel("shots per context"); a.set_ylabel("raw average score")
a.set_title("(c) magic square", loc="left")
h, l = ax[0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=4, bbox_to_anchor=(0.5, -0.14), handlelength=2.2, columnspacing=1.4)
fig.tight_layout(w_pad=1.6)
save(fig, "fig_hardware")
print("ok")

# ---------------------------------------------------------------- Fig: quantum-kernel audit
if (RESULTS / "qml_reanalysis_3000.json").exists():
    qml = json.load(open(RESULTS / "qml_reanalysis_3000.json"))
    accs = np.load(RESULTS / "qml_reanalysis_3000_mc_accs.npy")
    fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.35), gridspec_kw={"width_ratios": [1.15, 1]})
    a = ax[0]
    labels = ["restricted SVM (original comparator)", "hardware quantum kernel", "shot-noise-only quantum kernel (sim.)", "exact classical fidelity kernel"]
    ntest = qml["exact_classical_kernel_n"]
    vals = [qml["restricted_classical_archived_correct"] / ntest,
            qml["hardware_archived_correct"] / ntest, qml["shot_noise_1024_mean_acc"],
            qml["exact_classical_kernel_correct"] / ntest]
    cols = [C1, C2, C2, C1]
    ypos = np.arange(4)[::-1]
    bars = a.barh(ypos, vals, color=cols, height=0.62, edgecolor="white", linewidth=0.8)
    bars[2].set_hatch("////"); bars[2].set_facecolor("white"); bars[2].set_edgecolor(C2)
    for y, v in zip(ypos, vals):
        a.text(v + 0.015, y, f"{v:.3f}", va="center", fontsize=7.2, color=INK)
    a.set_yticks(ypos); a.set_yticklabels(labels, fontsize=7.0)
    a.set_xlim(0, 1.15); a.set_xlabel("held-out accuracy (40 test points)")
    a.grid(axis="y", visible=False)
    a.set_title("(a) released instance", loc="left")
    b = ax[1]
    bins = np.arange(-0.0125, 1.0126, 0.025)
    b.hist(accs, bins=bins, color=C1, edgecolor="white", linewidth=0.8)
    lcb = accs.mean() - np.sqrt(np.log(20) / (2 * len(accs)))
    b.axvline(accs.mean(), color=INK, lw=1.1, label=f"mean {accs.mean():.3f}")
    b.axvline(lcb, color=INK, lw=1.1, ls="--", label=f"95% LCB {lcb:.3f}")
    b.axvline(vals[1], color=C2, lw=1.6, ls=":", label=f"hardware instance {vals[1]:.3f}")
    b.set_xlabel("exact-classical-kernel accuracy"); b.set_ylabel(f"task instances (of {len(accs)})")
    b.set_xlim(0.55, 1.02)
    b.legend(loc="upper left", handlelength=1.8, frameon=True, facecolor="white", framealpha=0.95, edgecolor="none")
    b.set_title("(b) random generator unitaries", loc="left")
    fig.tight_layout(w_pad=1.8)
    save(fig, "fig_qml")
    print("qml ok")
