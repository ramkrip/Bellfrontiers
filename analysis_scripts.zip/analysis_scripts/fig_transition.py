#!/usr/bin/env python3
"""Main-text figure: the q_max = 1/2 transition of the own-marginal frontier (Theorem 2)
and its consequence for conditional-frequency CHSH values (Corollary 2, Proposition 3).
Usage: python3 fig_transition.py --results ../verification/reproduced --out ../manuscript"""
import json, os, sys
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
args = sys.argv[1:]
RES = args[args.index("--results") + 1] if "--results" in args else "../verification/reproduced"
OUT = args[args.index("--out") + 1] if "--out" in args else "."
C1, C2, C3 = "#2a78d6", "#eb6834", "#1baf7a"
GRAY, INK, INK2 = "#8a8986", "#0b0b0b", "#52514e"
plt.rcParams.update({
    "font.family": "serif", "font.size": 8.5, "axes.labelsize": 8.5, "axes.titlesize": 8.5,
    "legend.fontsize": 7.2, "xtick.labelsize": 7.5, "ytick.labelsize": 7.5,
    "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
    "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
    "axes.linewidth": 0.8, "lines.linewidth": 1.6, "mathtext.fontset": "dejavuserif",
    "pdf.fonttype": 42})
meff = lambda m, qmax: m - 2 + np.minimum(2.0, 1.0 / qmax)
fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.5))
a = ax[0]
a.axhline(1.0, color=GRAY, ls="--", lw=1.2)
a.text(0.985, 1.012, "free reference (all $m$)", ha="right", va="bottom", fontsize=7, color=INK2)
for m, col, mk in [(2, C2, "s"), (4, C1, "o"), (9, C3, "^")]:
    q = np.linspace(max(1.0 / m, 0.02), 0.995, 400)
    a.plot(q, meff(m, q) / m, color=col, marker=mk, markevery=50, ms=4.5, label=rf"$m={m}$")
a.axvline(0.5, color=GRAY, lw=0.8, ls=":")
a.text(0.505, 0.53, r"$q_{\max}=1/2$", fontsize=7, color=INK2)
a.set_xlim(0, 1); a.set_ylim(0.45, 1.08)
a.set_xlabel(r"largest instance probability $q_{\max}$")
a.set_ylabel(r"own-marginal slope / free slope, $m_{\rm eff}/m$")
a.legend(loc="lower left", handlelength=1.8)
a.set_title("(a) single-loss frontier, Theorem 2", loc="left")
b = ax[1]
d = json.load(open(os.path.join(RES, "mdl_contrast_check.json")))
rows = d["contrast_chsh_tsirelson"]; e0 = rows[0]["eta_req"]; l0 = rows[0]["l_ratio_lp"]
q = np.linspace(0.25, 0.995, 400)
b.plot(q, np.ones_like(q), color=C2, ls=(0, (4, 2)), lw=1.6, zorder=2, label="likelihood-ratio MDL $l_{\\rm req}$")
b.plot(q, 4.0 / meff(4, q), color=C1, zorder=3, label="own-marginal $\\eta_{\\rm req}$")
for r in rows:
    mk = "o" if r["law"].startswith("preferred") or r["law"] == "uniform" else "D"
    b.plot([r["q_max"]], [r["l_ratio_lp"] / l0], marker=mk, color=C2, ms=6.5, ls="none", mec="white", mew=0.6, zorder=4)
    b.plot([r["q_max"]], [r["eta_req"] / e0], marker=mk, color=C1, ms=3.8, ls="none", mec="white", mew=0.5, zorder=5)
b.axvline(0.5, color=GRAY, lw=0.8, ls=":")
b.axhline(4 / 3, color=GRAY, lw=0.8, ls="--")
b.text(0.62, 4 / 3 + 0.008, "$4/3$", fontsize=7, color=INK2, va="bottom")
b.set_xlim(0.2, 1); b.set_ylim(0.9, 1.4)
b.set_xlabel(r"largest setting-pair probability $q_{\max}$")
b.set_ylabel("certificate relative to uniform")
b.legend(loc="center left", bbox_to_anchor=(0.0, 0.58), handlelength=2.2)
b.set_title("(b) CHSH from conditional frequencies", loc="left")
fig.tight_layout(w_pad=2.0)
for ext in ("pdf", "png"):
    fig.savefig(os.path.join(OUT, "fig_transition." + ext), bbox_inches="tight", dpi=200)
print("ok")
