#!/usr/bin/env python3
"""Label-leakage frontier for binary classification (own-marginal measure).

At each public input c, binary classification is a two-instance single-loss
game (instances: the two labels; rules: 'predict 0', 'predict 1').
Theorem 2 with m = 2 gives
    S_eta = sum_c q(c) min{1, p_c + (1 - p_c) eta / p_c},   p_c = max_y P(y|c).
(1) Verify against direct LPs with nontrivial public information.
(2) Apply to quantum-generated labels P(y=1|u) = (1+g(u))/2 for the ZZ-feature
    generator of the kernel benchmark (seed 123) and its 3000-seed ensemble.
"""
import itertools, json, sys
import numpy as np
from scipy.optimize import linprog, brentq
from scipy.sparse import lil_matrix, csr_matrix
from scipy.linalg import qr

def lp_public(qc, post, eta):
    """Own-marginal relaxed value with public input c; rules = all maps c -> {0,1}."""
    C = len(qc); rules = list(itertools.product([0, 1], repeat=C)); L = len(rules)
    Z = [(c, y) for c in range(C) for y in (0, 1)]; nz = len(Z)
    qz = np.array([qc[c] * (post[c] if y == 1 else 1 - post[c]) for c, y in Z])
    n = nz * L; nv = 2 * n; idx = lambda zi, l: zi * L + l
    cvec = np.zeros(nv)
    for zi, (c, y) in enumerate(Z):
        for l, h in enumerate(rules):
            cvec[idx(zi, l)] = -qz[zi] * (h[c] == y)
    A = lil_matrix((n + nz, nv)); b = np.zeros(n + nz); r = 0
    for zi, (c, y) in enumerate(Z):
        same = [zj for zj, (cc, yy) in enumerate(Z) if cc == c]
        qsum = sum(qz[zj] for zj in same)
        for l in range(L):
            for zj in same:
                A[r, idx(zj, l)] -= qz[zj] / qsum
            A[r, idx(zi, l)] += 1; A[r, n + idx(zi, l)] = -1; r += 1
    for zi in range(nz):
        for l in range(L):
            A[r, n + idx(zi, l)] = 1
        b[r] = eta; r += 1
    Aeq = lil_matrix((nz, nv))
    for zi in range(nz):
        for l in range(L):
            Aeq[zi, idx(zi, l)] = 1
    res = linprog(cvec, A_ub=csr_matrix(A), b_ub=b, A_eq=csr_matrix(Aeq), b_eq=np.ones(nz), bounds=(0, None), method="highs")
    assert res.status == 0
    return -res.fun

def frontier(qc, p, eta):
    p = np.asarray(p, float); qc = np.asarray(qc, float)
    return float(np.sum(qc * np.minimum(1.0, p + (1 - p) * eta / p)))
def frontier_free(qc, p, eta):
    return float(np.sum(np.asarray(qc) * np.minimum(1.0, np.asarray(p) + 2 * (1 - np.asarray(p)) * eta)))
def eta_req(qc, p, s, fn=frontier):
    S0 = fn(qc, p, 0.0)
    if s <= S0: return 0.0
    if s > fn(qc, p, 1.0) + 1e-12: return float("nan")
    lo, hi = 0.0, 1.0
    for _ in range(80):
        mid = (lo + hi) / 2
        if fn(qc, p, mid) >= s - 1e-13: hi = mid
        else: lo = mid
    return hi

# ---- generator (same conventions as qml_reanalysis.py)
H = np.array([[1, 1], [1, -1]]) / np.sqrt(2)
def apply_1q(psi, U, q):
    psi = psi.reshape(2, 2)
    psi = psi @ U.T if q == 0 else U @ psi
    return psi.reshape(4)
def zz_state(x, reps=2):
    psi = np.zeros(4, complex); psi[0] = 1
    bits = np.array([[(k >> 0) & 1, (k >> 1) & 1] for k in range(4)])
    for _ in range(reps):
        psi = apply_1q(psi, H, 0); psi = apply_1q(psi, H, 1)
        for i in range(2):
            psi = psi * np.exp(1j * 2.0 * x[i] * bits[:, i])
        phi = 2.0 * (np.pi - x[0]) * (np.pi - x[1])
        psi = psi * np.exp(1j * phi * (bits[:, 0] ^ bits[:, 1]))
    return psi
def random_unitary(dim, rng):
    z = (rng.normal(size=(dim, dim)) + 1j * rng.normal(size=(dim, dim))) / np.sqrt(2)
    q, r = qr(z); d = np.diag(r); return q * (d / np.abs(d))
ZPROD = np.diag([1.0, -1.0, -1.0, 1.0])
def observable(seed):
    V = random_unitary(4, np.random.default_rng(seed)); return V.conj().T @ ZPROD @ V

def main():
    out = {}
    rng = np.random.default_rng(20261025); dev = 0.0; n = 0
    for t in range(40):
        C = int(rng.integers(1, 5)); qc = rng.dirichlet(np.ones(C)); post = rng.uniform(0.02, 0.98, C)
        p = np.maximum(post, 1 - post)
        for eta in [0.0, 0.05, 0.1, 0.3, 0.6, 0.9]:
            dev = max(dev, abs(lp_public(qc, post, eta) - frontier(qc, p, eta))); n += 1
    out["lp_check"] = dict(n_lp=n, max_dev=dev)
    grid = np.linspace(0, 2 * np.pi, 45, endpoint=False)
    XG = np.array(np.meshgrid(grid, grid, indexing="ij")).reshape(2, -1).T
    SG = np.array([zz_state(x) for x in XG])
    def task(seed):
        g = np.real(np.einsum("ni,ij,nj->n", SG.conj(), observable(seed), SG))
        return np.ones(len(g)) / len(g), (1 + np.abs(g)) / 2
    qc, p = task(123)
    S0 = frontier(qc, p, 0.0)
    targets = [S0 + 0.02, S0 + 0.05, 0.85, 0.90, 0.95, 0.99, 1.0]
    rows = []
    for s in targets:
        rows.append(dict(target=float(s), elementary=float(max(0.0, s - S0)), free=eta_req(qc, p, s, frontier_free), own=eta_req(qc, p, s)))
    out["released_generator"] = dict(bayes_accuracy=S0, mean_abs_g=float(np.mean(2 * p - 1)), rows=rows,
                                     slope_at_zero=float(np.sum(qc * (1 - p) / p)), free_slope_at_zero=float(np.sum(qc * 2 * (1 - p))))
    # ensemble
    S0s, slopes, e90 = [], [], []
    for t in range(3000):
        qq, pp = task(10_000 + t); s0 = frontier(qq, pp, 0.0)
        S0s.append(s0); slopes.append(float(np.sum(qq * (1 - pp) / pp)))
        e90.append(eta_req(qq, pp, min(1.0, s0 + 0.05)) / max(1e-12, min(1.0, s0 + 0.05) - s0))
    out["ensemble"] = dict(n=3000, bayes_mean=float(np.mean(S0s)), bayes_min=float(np.min(S0s)), bayes_max=float(np.max(S0s)),
                           slope_mean=float(np.mean(slopes)), slope_min=float(np.min(slopes)), slope_max=float(np.max(slopes)),
                           ratio_plus005_mean=float(np.mean(e90)), ratio_plus005_min=float(np.min(e90)), ratio_plus005_max=float(np.max(e90)))
    args = sys.argv[1:]
    path = args[args.index("--out") + 1] if "--out" in args else (args[0] if args else "label_leakage.json")
    json.dump(out, open(path, "w"), indent=1)
    print(json.dumps(out["lp_check"])); r = out["released_generator"]
    print("released: Bayes %.4f  mean|g| %.4f  slope0 own %.4f free %.4f" % (r["bayes_accuracy"], r["mean_abs_g"], r["slope_at_zero"], r["free_slope_at_zero"]))
    for x in r["rows"]: print("  s=%.4f elementary %.4f free %.4f own %.4f" % (x["target"], x["elementary"], x["free"], x["own"]))
    print(json.dumps(out["ensemble"]))

if __name__ == "__main__":
    main()
