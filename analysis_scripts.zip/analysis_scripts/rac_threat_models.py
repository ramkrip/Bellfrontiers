"""Exact classical relaxed values of n->1 RACs under three dependence (threat) models.
Resource lambda = deterministic strategy (encoder e: {0,1}^n -> {0,1}, decoder g: (y, m) -> {0,1}).
Measure: eta_bm = max over conditioning values of TV(p(.|value), induced marginal).
  'joint'   : p(lambda | x, y)   (unrestricted instance dependence)
  'question': p(lambda | y)      (question-only leakage, receiver's index reaches the shared resource)
  'sender'  : p(lambda | x)      (sender-input-only dependence)
Also: 'free' variants with a free (not induced) reference distribution Q.
"""
import itertools, json, sys
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import lil_matrix, csr_matrix, vstack, hstack, identity, eye

from functools import lru_cache

@lru_cache(maxsize=2)
def strategies(n):
    X = list(itertools.product([0, 1], repeat=n))
    encs = list(itertools.product([0, 1], repeat=len(X)))          # e[x_index]
    decs = list(itertools.product([0, 1], repeat=2 * n))            # g[y*2+m]
    # win[x, y, s] for s = (enc, dec)
    W = np.zeros((len(X), n, len(encs) * len(decs)), dtype=np.int8)
    for ie, e in enumerate(encs):
        for idd, g in enumerate(decs):
            s = ie * len(decs) + idd
            for ix, x in enumerate(X):
                m = e[ix]
                for y in range(n):
                    W[ix, y, s] = int(g[2 * y + m] == x[y])
    # remove duplicate win-profiles (only win profile matters)
    prof = W.reshape(len(X) * n, -1).T
    uniq = np.unique(prof, axis=0)
    # Pareto reduction (WLOG: replacing a dominated win profile by a dominating one keeps every TV distance,
    # or lowers it if labels merge, and does not lower the score)
    keep = [i for i, u in enumerate(uniq)
            if not (np.all(uniq >= u, axis=1) & np.any(uniq > u, axis=1)).any()]
    uniq = uniq[keep]
    return X, uniq.T.reshape(len(X), n, -1)

def solve(n, eta, model, free=False):
    X, W = strategies(n)
    nx, ny, L = W.shape
    if model == "joint":
        groups = [(ix, y) for ix in range(nx) for y in range(ny)]      # conditioning values
        members = {g: [g] for g in groups}
        w = {g: 1.0 / (nx * ny) for g in groups}
        win = {g: W[g[0], g[1], :].astype(float) for g in groups}
    elif model == "question":
        groups = list(range(ny)); w = {y: 1.0 / ny for y in groups}
        win = {y: W[:, y, :].mean(axis=0) for y in groups}
    elif model == "sender":
        groups = list(range(nx)); w = {ix: 1.0 / nx for ix in groups}
        win = {ix: W[ix, :, :].mean(axis=0) for ix in groups}
    G = len(groups)
    # variables: p[g, l] (G*L), t[g, l] (G*L) abs-dev aux, Q[l] (L) reference
    nv = 2 * G * L + L
    c = np.zeros(nv)
    for gi, g in enumerate(groups):
        c[gi * L:(gi + 1) * L] = -w[g] * win[g]
    A_eq, b_eq, A_ub, b_ub = [], [], [], []
    rows_eq = lil_matrix((G + 1 + (0 if free else L), nv)); beq = []
    r = 0
    for gi in range(G):
        rows_eq[r, gi * L:(gi + 1) * L] = 1; beq.append(1); r += 1
    rows_eq[r, 2 * G * L:] = 1; beq.append(1); r += 1
    if not free:   # Q equals induced marginal sum_g w_g p_g
        for l in range(L):
            for gi, g in enumerate(groups):
                rows_eq[r, gi * L + l] = w[g]
            rows_eq[r, 2 * G * L + l] = -1; beq.append(0); r += 1
    # t >= p - Q, t >= Q - p ; sum_l t[g,l] <= 2 eta
    ub = lil_matrix((2 * G * L + G, nv)); bub = []
    k = 0
    for gi in range(G):
        for l in range(L):
            ub[k, gi * L + l] = 1; ub[k, G * L + gi * L + l] = -1; ub[k, 2 * G * L + l] = -1; bub.append(0); k += 1
            ub[k, gi * L + l] = -1; ub[k, G * L + gi * L + l] = -1; ub[k, 2 * G * L + l] = 1; bub.append(0); k += 1
        ub[k, G * L + gi * L:G * L + (gi + 1) * L] = 1; bub.append(2 * eta); k += 1
    res = linprog(c, A_ub=csr_matrix(ub), b_ub=bub, A_eq=csr_matrix(rows_eq), b_eq=beq,
                  bounds=(0, None), method="highs")
    assert res.status == 0, res.message
    return -res.fun

if __name__ == "__main__":
    from analysis_paths import output_parser, prepare_output
    args = output_parser(__doc__, "rac_threat.json").parse_args()
    OUT = prepare_output(args.out)
    out = {}
    etas = [0.0, 0.02, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3]
    for n in (2, 3):
        for model in ("joint", "question", "sender"):
            for free in (False, True):
                key = f"{n}->1/{model}/{'free' if free else 'marginal'}"
                out[key] = [solve(n, e, model, free) for e in etas]
                print(key, np.round(out[key], 5), flush=True)
    out["etas"] = etas
    json.dump(out, open(OUT, "w"), indent=1)
