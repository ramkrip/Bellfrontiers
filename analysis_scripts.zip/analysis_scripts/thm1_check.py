#!/usr/bin/env python3
"""Theorem 1 equivalence check: for binary rewards and 0<S0<1,
(ii) S_eta = 1 at eta = 1 - S0   <=>   (iii) some optimal mixture has constant loss profile,
where (iii) is tested as t* = max_{optimal pi} min_z loss_pi(z) == 1 - S0.
Also records that the local condition eta <= t* is necessary but not sufficient."""
import json, sys
import numpy as np
from scipy.optimize import linprog
sys.path.insert(0, ".")
from biased_frontier_check import lp_value

def s0_tstar(W, q):
    W = np.unique(np.asarray(W, int), axis=0); L, Z = W.shape
    sc = W @ q; S0 = sc.max(); opt = np.where(sc >= S0 - 1e-12)[0]; k = len(opt)
    c = np.zeros(k + 1); c[-1] = -1
    A = np.hstack([-(1 - W[opt].T), np.ones((Z, 1))])
    r = linprog(c, A_ub=A, b_ub=np.zeros(Z), A_eq=[np.r_[np.ones(k), 0]], b_eq=[1],
                bounds=[(0, None)] * k + [(None, None)], method="highs")
    return float(S0), float(-r.fun)

def main():
    rng = np.random.default_rng(20261025)
    out = dict(cases=0, const_loss=0, agree=0, disagree=0, local_fail=0, local_ok=0, examples=[])
    for trial in range(30000):
        Z = int(rng.integers(2, 7)); L = int(rng.integers(2, 10))
        W = (rng.random((L, Z)) < rng.uniform(.3, .9)).astype(int)
        if trial % 3 == 0:   # add a cyclic (transitive) block to create constant-loss mixtures
            k = int(rng.integers(1, Z)); base = np.r_[np.zeros(k, int), np.ones(Z - k, int)]
            W = np.vstack([W, [np.roll(base, s) for s in range(Z)]])
        w = rng.integers(1, 4, size=Z).astype(float); q = w / w.sum()
        if trial % 3 == 0: q = np.ones(Z) / Z
        S0, t = s0_tstar(W, q)
        if not (1e-9 < S0 < 1 - 1e-9): continue
        out["cases"] += 1
        const = t >= 1 - S0 - 1e-9
        perfect = lp_value(W, q, 1 - S0) >= 1 - 1e-9
        out["const_loss"] += int(const)
        if const == perfect: out["agree"] += 1
        else:
            out["disagree"] += 1; out["examples"].append(dict(W=W.tolist(), q=q.tolist(), S0=S0, t=t))
        if 1e-6 < t < 1 - S0 - 1e-9:
            if lp_value(W, q, t) < S0 + t - 1e-8: out["local_fail"] += 1
            else: out["local_ok"] += 1
    # documented counterexample to the local converse
    W = [[1, 0, 0, 0], [0, 1, 0, 0]]; q = np.array([3, 3, 1, 1]) / 8
    S0, t = s0_tstar(W, q)
    out["local_counterexample"] = dict(W=W, q=q.tolist(), S0=S0, t_star=t, S_at_t=lp_value(W, q, t), S0_plus_t=S0 + t)
    # documented partial unit-slope example (SM Sec. S1, example 1)
    W = [[0, 0, 0, 1], [0, 1, 1, 0], [1, 1, 0, 0]]; q = np.array([2, 1, 2, 3]) / 8
    S0, t = s0_tstar(W, q)
    def pred(e):  # slopes 1, 3/4, 1/2 with breakpoints 1/2, 5/8; saturation at 11/16
        if e <= 0.5: return 3/8 + e
        if e <= 5/8: return 7/8 + 0.75 * (e - 0.5)
        return min(1.0, 31/32 + 0.5 * (e - 5/8))
    grid = [0.1, 0.25, 0.5, 0.55, 0.6, 0.625, 0.65, 2/3, 0.6875, 0.7, 0.8]
    vals = [lp_value(W, q, e) for e in grid]
    out["partial_slope_example"] = dict(W=W, q=q.tolist(), S0=S0, t_star=t, grid=grid, lp=vals,
                                        max_dev=max(abs(v - pred(e)) for v, e in zip(vals, grid)))
    args = sys.argv[1:]
    path = args[args.index("--out") + 1] if "--out" in args else (args[0] if args else "thm1_check.json")
    json.dump(out, open(path, "w"), indent=1)
    print({k: v for k, v in out.items() if k not in ("examples",)})

if __name__ == "__main__":
    main()
