"""Recompute readout-mitigated scores retaining fractional mitigated counts.
The previous load() summed mitigated win counts with int(), which truncated fractional totals."""
import glob, os, re, json, sys
import numpy as np, pandas as pd
from pathlib import Path
from analysis_paths import DATA_DIR, output_parser, prepare_output
parser = output_parser(__doc__, "mitigated_fixed.csv")
parser.add_argument("--raw-root", type=Path, default=DATA_DIR / "raw_games" / "Quantum_Nonlocal_Games")
args = parser.parse_args()
ROOT = str(args.raw_root.resolve())
OUT = prepare_output(args.out)
OMEGA = {"chsh": 0.75, "mermin_ghz": 0.75, "magic_square": 8 / 9}
def ctx_cols(df):
    for cols in (["Setting_X", "Setting_Y"], ["Set_X", "Set_Y", "Set_Z"], ["Row", "Col"]):
        if all(c in df.columns for c in cols):
            return cols
def load_float(path):
    df = pd.read_csv(path); g = df.groupby(ctx_cols(df))
    K = g.apply(lambda d: float(d.loc[d.Win == 1, "Count"].sum()), include_groups=False)
    return K.values, g["Count"].sum().values.astype(float)
rows = []
for d in sorted(glob.glob(os.path.join(ROOT, "ibm_*_*"))):
    m = re.match(r"ibm_(fez|kingston|marrakesh)_(chsh|mermin_ghz|magic_square)$", os.path.basename(d))
    if not m: continue
    backend, game = m.groups()
    for sd in sorted(glob.glob(os.path.join(d, "*"))):
        sh = re.search(r"(\d+)", os.path.basename(sd))
        mit = glob.glob(os.path.join(sd, "*mitigated_counts*.csv")); raw = glob.glob(os.path.join(sd, "*raw_counts*.csv"))
        if not (sh and mit and raw): continue
        Km, Nm = load_float(mit[0]); _, Nraw = load_float(raw[0])
        rows.append(dict(game=game, backend=backend, shots=int(sh.group(1)), N_raw=float(Nraw.sum()),
                         S_mit=float(np.mean(Km / Nm))))
df = pd.DataFrame(rows)
assert len(df) == 54, f"Expected 54 mitigated runs, found {len(df)}"
out = []
for (g, b), s in df.groupby(["game", "backend"]):
    ex = float(np.average(s.S_mit, weights=s.N_raw)) - OMEGA[g]
    out.append(dict(game=g, backend=b, runs=len(s), mit_excess=ex))
    print(g, b, len(s), f"{ex:.7f}")
pd.DataFrame(out).to_csv(OUT, index=False)
