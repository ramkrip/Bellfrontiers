"""Table III regenerated from one estimand: the shot-pooled score of each backend (all six runs pooled).
Every run allocates equal shots to every context, so the pooled design is context-balanced and the
pooled frequency K/N estimates the shot-averaged success probability (uniform context weights).
CP: one-sided Clopper-Pearson lower bound; independence and the finite-sample
Poisson-binomial/binomial comparison conditions are stated and checked in the supplement.
Hoeffding: stratified, eps = sqrt(ln(1/alpha)/2 * sum_c q_c^2 / N_c) with pooled N_c.
"""
import json, sys
import numpy as np, pandas as pd
from scipy.stats import beta
ALPHA = 0.05
OMEGA = {"chsh": 0.75, "mermin_ghz": 0.75, "magic_square": 8 / 9}
from pathlib import Path
from analysis_paths import DEFAULT_RESULTS, output_parser, prepare_output
parser = output_parser(__doc__, "table3_consistent.csv")
parser.add_argument("--hardware", type=Path, default=DEFAULT_RESULTS / "hw_certificates.csv")
args = parser.parse_args()
OUT = prepare_output(args.out)
df = pd.read_csv(args.hardware)
rows = []
for (g, b), sub in df.groupby(["game", "backend"]):
    Kc = sum(np.array(json.loads(k)) for k in sub.ctx_K); Nc = sum(np.array(json.loads(n)) for n in sub.ctx_N)
    assert len(set(Nc)) == 1
    m = len(Nc); q = np.full(m, 1 / m); K, N = int(Kc.sum()), int(Nc.sum())
    S = K / N; S_strat = float(q @ (Kc / Nc)); assert abs(S - S_strat) < 1e-12
    L_cp = beta.ppf(ALPHA, K, N - K + 1)
    eps = np.sqrt(np.log(1 / ALPHA) / 2 * np.sum(q ** 2 / Nc))
    rows.append(dict(game=g, backend=b, N=N, K=K, S_pooled=S, L_CP=L_cp, eta_CP=max(0, L_cp - OMEGA[g]),
                     eps_H=eps, eta_H=max(0, S - eps - OMEGA[g]), ctx_K=Kc.tolist(), ctx_N=Nc.tolist()))
out = pd.DataFrame(rows)
print(out[["game", "backend", "N", "K", "S_pooled", "eta_CP", "eps_H", "eta_H"]].to_string(float_format=lambda v: f"{v:.5f}"))
out.to_csv(OUT, index=False)
