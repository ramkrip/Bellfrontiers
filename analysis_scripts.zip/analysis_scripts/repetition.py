"""Brute-force checks for repeated CHSH (eta = 0).

parallel:  Alice a(x1,x2) in {0,1}^2, Bob b(y1,y2) in {0,1}^2 (all inputs of the block available at once)
sequential with full shared memory: round-1 outputs depend only on round-1 inputs;
  round-2 outputs may depend on *both* parties' round-1 inputs and outputs and on the own round-2 input.
Quantity: probability of winning both rounds (product/block score), uniform inputs.
"""
import itertools, json, sys
import numpy as np
from analysis_paths import output_parser, prepare_output
ARGS = output_parser(__doc__, "repetition.json").parse_args()
OUT = prepare_output(ARGS.out)

res = {}
X = [(x1, x2) for x1 in (0, 1) for x2 in (0, 1)]

# ---------- parallel repetition ----------
# Alice strategy: map from 4 inputs to 4 outputs (2 bits) -> 4^4 = 256
A = np.array(list(itertools.product(range(4), repeat=4)))  # A[s, xi] = output index (a1 + 2 a2)
win = np.zeros((4, 4, 4, 4), dtype=np.int8)  # win[xi, yi, ao, bo]
for xi, (x1, x2) in enumerate(X):
    for yi, (y1, y2) in enumerate(X):
        for ao in range(4):
            for bo in range(4):
                a1, a2 = ao & 1, ao >> 1; b1, b2 = bo & 1, bo >> 1
                win[xi, yi, ao, bo] = int(((a1 ^ b1) == (x1 & y1)) and ((a2 ^ b2) == (x2 & y2)))
best = 0
for sa in range(256):
    # for each Bob strategy, count wins: sum over xi, yi win[xi,yi,A[sa,xi],B[sb,yi]]
    Wa = win[np.arange(4)[:, None], np.arange(4)[None, :], A[sa][:, None]]  # shape (4 xi, 4 yi, 4 bo)
    # total for Bob strategy sb = sum_{xi,yi} Wa[xi, yi, A[sb, yi]]
    tot = np.zeros(256, int)
    for yi in range(4):
        tot += Wa[:, yi, :].sum(0)[A[:, yi]]
    best = max(best, tot.max())
res["parallel_CHSH2_value"] = best / 16
res["parallel_exceeds_product"] = bool(best / 16 > 0.75 ** 2)

# ---------- sequential repetition with full shared memory ----------
# round 1: a1(x1), b1(y1): 4x4 choices. Given (x1,y1,a1,b1), round 2 is a fresh CHSH game with shared randomness
# -> conditional value <= 3/4 by definition; brute force: for each round-1 strategy pair, best round-2 response
#    may depend on the full round-1 transcript, so P(win both) = sum_{x1,y1} q * win1 * max over round-2 local strategies.
best_seq = 0
chsh_val = 0
for a2 in itertools.product((0, 1), repeat=2):
    for b2 in itertools.product((0, 1), repeat=2):
        chsh_val = max(chsh_val, sum(int((a2[x] ^ b2[y]) == (x & y)) for x in (0, 1) for y in (0, 1)) / 4)
for a1 in itertools.product((0, 1), repeat=2):
    for b1 in itertools.product((0, 1), repeat=2):
        p1 = sum(int((a1[x] ^ b1[y]) == (x & y)) for x in (0, 1) for y in (0, 1)) / 4
        best_seq = max(best_seq, p1 * chsh_val)
res["sequential_memory_CHSH2_value_decomposed"] = best_seq
# genuine brute force: F,G are arbitrary functions of (x1,y1,own x2/y2) -> 2^8 each
F = np.array(list(itertools.product((0,1), repeat=8)))  # index t = x1*4+y1*2+x2
best_bf = 0
for a1 in itertools.product((0,1), repeat=2):
    for b1 in itertools.product((0,1), repeat=2):
        # tot[f,g] = sum over inputs of win1*win2
        tot = np.zeros((256,256), int)
        for x1 in (0,1):
            for y1 in (0,1):
                if (a1[x1]^b1[y1]) != (x1&y1):
                    continue
                for x2 in (0,1):
                    for y2 in (0,1):
                        fa = F[:, x1*4+y1*2+x2]; gb = F[:, x1*4+y1*2+y2]
                        tot += ((fa[:,None]^gb[None,:]) == (x2&y2)).astype(int)
        best_bf = max(best_bf, tot.max())
res["sequential_memory_CHSH2_value_bruteforce"] = best_bf/16
res["note"] = ("sequential: conditional on the full round-1 transcript the round-2 inputs are fresh and independent, "
               "so the best round-2 strategy is a one-shot CHSH strategy (value 3/4) for every transcript")
print(json.dumps(res, indent=2))
json.dump(res, open(OUT, "w"), indent=2, default=float)
