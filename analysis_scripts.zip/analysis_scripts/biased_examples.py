#!/usr/bin/env python3
"""Biased-setting examples for Theorem 2 and Corollary 2.

(1) Corollary 2 check: score weights w differ from the setting law q (dependence
    measured against the q-marginal). LP vs min{1, 1 - w_min (1 - m_eff(q) eta)}.
(2) Biased CHSH games (score weighted by q): product bias b (Lawson, Linden and
    Popescu, closed form checked against numerical optimization) and the
    preferred-pair law P(00)=Q, other pairs (1-Q)/3 (the seed-saving law of
    Pironio et al. 2010). Required own-marginal dependence for the quantum value.
(3) Conditional-frequency CHSH value (uniform weights) under the same laws:
    eta_req = 4 (s - 3/4) / m_eff(q) at the Tsirelson value.
"""
import json, sys
import numpy as np
from scipy.optimize import linprog, minimize
from scipy.sparse import lil_matrix, csr_matrix
from biased_frontier_check import chsh_wins, ghz3_wins, random_single_loss

SIGN = np.array([1, 1, 1, -1.0])

def omega_q(q, starts=40, seed=0):
    """Quantum value of CHSH with input law q over (00,01,10,11); 2D real vectors suffice."""
    q = np.asarray(q, float)
    def neg(th):
        a, b = th[:2], th[2:]
        return -sum(q[2*x+y]*SIGN[2*x+y]*np.cos(a[x]-b[y]) for x in (0, 1) for y in (0, 1))
    rng = np.random.default_rng(seed); best = 0.0
    for _ in range(starts):
        best = max(best, -minimize(neg, rng.uniform(0, 2*np.pi, 4), method="BFGS").fun)
    return 0.5 + 0.5*best

def lawson_product(b):
    return 0.5*(1+np.sqrt(2)*(b*b+(1-b)**2)) if b*b < 0.5 else 1-(1-b)**2

def meff(q):
    q = np.asarray(q, float); return len(q) - 2 + min(2.0, 1.0/q.max())

def lp_wq(W, w, q, eta):
    W = np.unique(np.asarray(W, int), axis=0); L, Z = W.shape; n = Z*L; nv = 2*n
    idx = lambda z, l: z*L + l
    c = np.zeros(nv)
    for z in range(Z):
        for l in range(L):
            c[idx(z, l)] = -w[z]*W[l, z]
    A = lil_matrix((n+Z, nv)); b = np.zeros(n+Z); r = 0
    for z in range(Z):
        for l in range(L):
            for zp in range(Z):
                A[r, idx(zp, l)] -= q[zp]
            A[r, idx(z, l)] += 1; A[r, n+idx(z, l)] = -1; r += 1
    for z in range(Z):
        for l in range(L):
            A[r, n+idx(z, l)] = 1
        b[r] = eta; r += 1
    Aeq = lil_matrix((Z, nv))
    for z in range(Z):
        for l in range(L):
            Aeq[z, idx(z, l)] = 1
    res = linprog(c, A_ub=csr_matrix(A), b_ub=b, A_eq=csr_matrix(Aeq), b_eq=np.ones(Z), bounds=(0, None), method="highs")
    assert res.status == 0
    return -res.fun

def main():
    out = {}
    rng = np.random.default_rng(20261025)
    dev, n = 0.0, 0
    for t in range(60):
        if t % 3 == 0: W, m = chsh_wins(), 4
        elif t % 3 == 1: W, m = ghz3_wins(), 4
        else:
            m = int(rng.integers(2, 7)); W = random_single_loss(m, rng)
        q = rng.dirichlet(np.ones(m)*rng.uniform(.3, 2))
        w = np.ones(m)/m if t % 2 == 0 else rng.dirichlet(np.ones(m))
        for eta in [0, 0.02, 0.05, 0.1, 0.2, 0.4]:
            f = min(1.0, 1 - w.min()*(1 - meff(q)*eta))
            dev = max(dev, abs(lp_wq(W, w, q, eta) - f)); n += 1
    # Pironio law with conditional-frequency weights, explicit LPs
    W = chsh_wins(); w = np.ones(4)/4
    for Q in [0.7, 0.85, 0.97]:
        q = np.array([Q] + [(1-Q)/3]*3)
        for eta in [0.02, 0.05, 0.1]:
            f = min(1.0, 0.75 + meff(q)*eta/4)
            dev = max(dev, abs(lp_wq(W, w, q, eta) - f)); n += 1
    out["corollary3_lp"] = dict(n_lp=n, max_dev=dev)
    tsirelson = np.cos(np.pi/8)**2
    rows = []
    for b in [0.5, 0.55, 0.6, 0.65, 0.7, 0.8]:
        q = np.array([b*b, b*(1-b), (1-b)*b, (1-b)**2]); qmin = q.min(); S0 = 1 - qmin
        wq = omega_q(q); law = lawson_product(b); me = meff(q)
        gap = max(0.0, wq - S0)
        rows.append(dict(family="product", param=b, q_max=float(q.max()), q_min=float(qmin), m_eff=me, S0=float(S0),
                         omega_q=float(wq), lawson=float(law), lawson_dev=float(abs(wq-law)), gap=float(gap),
                         eta_req_game=float(gap/(me*qmin)), factor_game=float(1/(me*qmin)),
                         slope_game=float(me*qmin), eta_req_cond_tsirelson=float((tsirelson-0.75)*4/me)))
    for Q in [0.25, 0.4, 0.55, 0.7, 0.85, 0.95]:
        q = np.array([Q] + [(1-Q)/3]*3); qmin = q.min(); S0 = 1 - qmin
        wq = omega_q(q); me = meff(q); gap = max(0.0, wq - S0)
        rows.append(dict(family="preferred_pair", param=Q, q_max=float(Q), q_min=float(qmin), m_eff=me, S0=float(S0),
                         omega_q=float(wq), gap=float(gap), eta_req_game=float(gap/(me*qmin)),
                         factor_game=float(1/(me*qmin)), slope_game=float(me*qmin),
                         eta_req_cond_tsirelson=float((tsirelson-0.75)*4/me)))
    out["biased_chsh"] = rows
    out["max_lawson_dev"] = max(r["lawson_dev"] for r in rows if r["family"] == "product")
    out["cond_limit_tsirelson"] = float((tsirelson-0.75)*4/3)
    args = sys.argv[1:]
    path = args[args.index("--out")+1] if "--out" in args else (args[0] if args else "biased_examples.json")
    json.dump(out, open(path, "w"), indent=1)
    print(json.dumps(out["corollary3_lp"]), "lawson dev", out["max_lawson_dev"])
    for r in rows:
        print(r["family"], r["param"], "qmax %.4f meff %.4f S0 %.4f wq %.5f gap %.5f eta_game %.5f factor %.3f slope %.4f eta_cond %.4f" %
              (r["q_max"], r["m_eff"], r["S0"], r["omega_q"], r["gap"], r["eta_req_game"], r["factor_game"], r["slope_game"], r["eta_req_cond_tsirelson"]))

if __name__ == "__main__":
    main()
