"""Symmetry-reduced exact LPs for the n->1 RAC (an input-transitive game).
Group: bit flips f in {0,1}^n and index permutations pi, acting on instances (x,y) -> (pi(x) xor f, pi(y)).
An optimal policy can be taken G-invariant, p(g.lam | g.z) = p(lam | z): orbit averaging preserves the
(convex, G-invariant) constraints and the linear objective. Then p(.|z) = g_z . phi with phi invariant under
Stab(z0), and every TV constraint reduces to TV(phi, ref) for a few reference distributions."""
import itertools, json, sys
import numpy as np
from scipy.optimize import linprog
from scipy import sparse
from theory import mdl_lmax, rate_distortion  # noqa: E402

_CACHE = {}


def rac_pareto(n):
    X = list(itertools.product((0, 1), repeat=n)); Z = [(x, y) for x in X for y in range(n)]
    W = set()
    for e in itertools.product((0, 1), repeat=len(X)):
        for d in itertools.product((0, 1), repeat=2 * n):
            W.add(tuple(int(d[2 * y + e[X.index(x)]] == x[y]) for x, y in Z))
    W = np.array(sorted(W)); W = W[np.argsort(-W.sum(1), kind="stable")]
    keep = []
    for i, w in enumerate(W):
        if not any(np.all(W[j] >= w) for j in keep):
            keep.append(i)
    return W[keep], Z


def group(n, Z):
    idx = {z: i for i, z in enumerate(Z)}
    G = []
    for f in itertools.product((0, 1), repeat=n):
        for pi in itertools.permutations(range(n)):
            perm = np.empty(len(Z), int)
            for i, (x, y) in enumerate(Z):
                xn = [0] * n
                for k in range(n):
                    xn[pi[k]] = x[k] ^ f[pi[k]]
                perm[i] = idx[(tuple(xn), pi[y])]
            G.append(perm)
    return G


def induced(W, perm):
    lookup = {tuple(w): k for k, w in enumerate(W)}
    out = np.empty(len(W), int)
    for k, w in enumerate(W):
        wn = np.empty_like(w); wn[perm] = w
        out[k] = lookup[tuple(wn)]   # KeyError would mean the Pareto set is not G-invariant
    return out


def setup(n):
    if n in _CACHE:
        return _CACHE[n]
    W, Z = rac_pareto(n); G = group(n, Z)
    maps = [induced(W, g) for g in G]
    _CACHE[n] = (W, Z, G, maps)
    return _CACHE[n]


def solve(n, s_target, kind):
    W, Z, G, maps = setup(n)
    m, L, z0 = len(Z), len(W), 0
    stab = [k for k, g in enumerate(G) if g[z0] == z0]
    rep = {}
    for k, g in enumerate(G):
        rep.setdefault(int(g[z0]), k)
    Pm = lambda k: sparse.csr_matrix((np.ones(L), (maps[k], np.arange(L))), shape=(L, L))
    Pz = {z: Pm(rep[z]) for z in range(m)}
    pbar = sum(Pz.values()) / m
    I = sparse.identity(L, format="csr")
    refs = [pbar] if kind == "bm" else [Pz[z] for z in range(m) if z != z0]
    K = len(refs); nv = L + K * L + 1
    ub, b_ub = [], []
    for k, Rm in enumerate(refs):
        T = sparse.csr_matrix((-np.ones(L), (np.arange(L), k * L + np.arange(L))), shape=(L, K * L))
        ub.append(sparse.hstack([I - Rm, T, sparse.csr_matrix((L, 1))])); b_ub += [0.0] * L
        row = np.zeros(nv); row[L + k * L:L + (k + 1) * L] = 1.0; row[-1] = -1.0
        ub.append(sparse.csr_matrix(row[None, :])); b_ub.append(0.0)
    sc = np.zeros(nv); sc[:L] = -W[:, z0]
    ub.append(sparse.csr_matrix(sc[None, :])); b_ub.append(-s_target)
    eq = [sparse.hstack([Pm(s) - I, sparse.csr_matrix((L, K * L + 1))]) for s in stab]
    nr = np.zeros(nv); nr[:L] = 1.0
    eq.append(sparse.csr_matrix(nr[None, :]))
    A_eq = sparse.vstack(eq).tocsr(); b_eq = np.r_[np.zeros(A_eq.shape[0] - 1), 1.0]
    c = np.zeros(nv); c[-1] = 1.0
    sol = linprog(c, A_ub=sparse.vstack(ub).tocsr(), b_ub=b_ub, A_eq=A_eq, b_eq=b_eq,
                  bounds=(0, None), method="highs")
    assert sol.status == 0, sol.message
    return float(sol.fun)


if __name__ == "__main__":
    from analysis_paths import output_parser, prepare_output
    args = output_parser(__doc__, "rac_theory.json").parse_args()
    OUT = prepare_output(args.out)
    out = {}
    for n in (2, 3):
        W, Z, G, maps = setup(n)
        q = np.full(len(Z), 1 / len(Z)); w = float((W @ q).max()); sq = 0.5 * (1 + 1 / np.sqrt(n))
        e = dict(n=n, instances=len(Z), pareto=int(len(W)), group_order=len(G), omega_c=w, quantum=sq, gap=sq - w)
        e["eta_req_ideal"] = solve(n, sq, "bm")
        e["hall_M_ideal"] = 2 * solve(n, sq, "pair")
        e["eta_req_perfect"] = solve(n, 1.0, "bm")
        e["hall_M_perfect"] = 2 * solve(n, 1.0, "pair")
        e["mdl_lmax_ideal"] = mdl_lmax(W, q, sq)
        e["I_bits_ideal"] = rate_distortion(W, q, sq)
        e["I_bits_perfect"] = rate_distortion(W, q, 1 - 1e-9)
        grid = np.linspace(w, min(1.0, w + 0.12), 13)
        e["grid"] = dict(s=grid.tolist(), eta=[solve(n, s, "bm") for s in grid],
                         hall_M=[2 * solve(n, s, "pair") for s in grid],
                         I_bits=[rate_distortion(W, q, s) if s > w + 1e-12 else 0.0 for s in grid])
        out[f"rac{n}1"] = e
        print({k: v for k, v in e.items() if k != "grid"}, flush=True)
    json.dump(out, open(OUT, "w"), indent=2, default=float)
