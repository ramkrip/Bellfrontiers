"""Exact Bayes accuracy of predicting f_s(a)=1[(a-s) mod N < K], K=(N-1)/2, from (s, bucket of a),
s and a uniform, buckets = contiguous blocks of {0,...,N-1}. Check against
P = 1 - (1/N^2) sum_j floor(L_j^2/2)."""
import numpy as np, sys, json
from analysis_paths import output_parser, prepare_output
ARGS = output_parser(__doc__, "bucket_check.json").parse_args()
OUT = prepare_output(ARGS.out)
def brute(N, lengths):
    K = (N - 1) // 2
    edges = np.cumsum([0] + list(lengths))
    tot = 0
    a = np.arange(N)
    for s in range(N):
        y = ((a - s) % N) < K
        for j in range(len(lengths)):
            blk = y[edges[j]:edges[j + 1]]
            c = blk.sum(); tot += max(c, len(blk) - c)
    return tot / N**2
def formula(N, lengths):
    return 1 - sum((L * L) // 2 for L in lengths) / N**2
def top_bits(N, b):
    n = int(np.ceil(np.log2(N)))
    idx = np.arange(N) >> (n - b)
    return list(np.bincount(idx))
def balanced(N, b):
    idx = (np.arange(N) * 2**b) // N
    return list(np.bincount(idx))
rng = np.random.default_rng(0); res = []
for N in (769, 101, 97, 211, 1023 + 2):
    if N % 2 == 0: N += 1
    for lengths in (top_bits(N, 1), top_bits(N, 2), balanced(N, 1), balanced(N, 2), balanced(N, 3)):
        lengths = [L for L in lengths if L > 0]
        if len(lengths) < 2: continue
        bb, ff = brute(N, lengths), formula(N, lengths)
        res.append(dict(N=N, lengths=lengths if len(lengths) < 9 else "...", brute=bb, formula=ff))
        assert abs(bb - ff) < 1e-12, (N, lengths, bb, ff)
    for _ in range(5):  # random partitions, including blocks longer than K
        cuts = np.sort(rng.choice(np.arange(1, N), size=rng.integers(1, 6), replace=False))
        lengths = list(np.diff(np.r_[0, cuts, N]))
        bb, ff = brute(N, lengths), formula(N, lengths)
        assert abs(bb - ff) < 1e-12, (N, lengths, bb, ff)
print("formula verified on all cases")
print("N=769 top-bit buckets", top_bits(769, 1), formula(769, top_bits(769, 1)))
print("N=769 balanced b=1", balanced(769, 1), formula(769, balanced(769, 1)))
for b in (1, 2, 3, 4, 8):
    N = 2**61 - 1
    L = [(((j + 1) * N) >> b) - ((j * N) >> b) for j in range(2**b)]  # floor((j+1)N/2^b)-floor(jN/2^b) via shifts approx
    print("balanced", b, formula(N, L), 1 - 2**-(b + 1))
json.dump(res, open(OUT, "w"), indent=1, default=int)
